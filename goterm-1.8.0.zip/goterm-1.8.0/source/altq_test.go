package main

import (
	"fmt"
	"io"
	"net"
	"strings"
	"sync"
	"testing"
	"time"
)

func altQ(a *App) { a.OnKey(KeyEvent{Ch: 'q', Alt: true}) }

func TestAltQQuickConnectAndAudioReply(t *testing.T) {
	setupPlat()
	cfg := newDefaultConfig()
	a := NewApp(cfg)
	a.audio.sinkOpen = nil

	var mu sync.Mutex
	var reply1 string
	closed1 := make(chan struct{})
	h1, p1 := fakeBBS(t, func(c net.Conn) {
		c.Write([]byte("Welcome to BBS one\r\n\x1b_SyncTERM:Q;libsndfile\x1b\\"))
		buf := make([]byte, 64)
		c.SetReadDeadline(time.Now().Add(3 * time.Second))
		n, _ := c.Read(buf)
		mu.Lock()
		reply1 = string(buf[:n])
		mu.Unlock()
		c.SetReadDeadline(time.Time{})
		io.Copy(io.Discard, c) // until the client hangs up
		close(closed1)
	})
	got2 := make(chan string, 1)
	h2, p2 := fakeBBS(t, func(c net.Conn) {
		c.Write([]byte("Welcome to BBS two\r\n"))
		time.Sleep(300 * time.Millisecond)
		got2 <- "connected"
	})

	altQ(a)
	chr(a, fmt.Sprintf("%s %d", h1, p1))
	key(a, KeyEnter)
	waitFor(t, "bbs1 reply", 4*time.Second, func() bool {
		mu.Lock()
		defer mu.Unlock()
		return reply1 != ""
	})
	mu.Lock()
	if reply1 != "\x1b[=7;100;1n" {
		t.Fatalf("libsndfile reply %q", reply1)
	}
	mu.Unlock()

	// Switch to another system from inside the session.
	altQ(a)
	chr(a, fmt.Sprintf("%s:%d", h2, p2))
	key(a, KeyEnter)
	select {
	case <-closed1:
	case <-time.After(3 * time.Second):
		t.Fatal("first connection not dropped")
	}
	select {
	case <-got2:
	case <-time.After(3 * time.Second):
		t.Fatal("second connection never made")
	}
	waitFor(t, "screen text", 2*time.Second, func() bool {
		a.mu.Lock()
		defer a.mu.Unlock()
		return a.parser != nil && strings.Contains(a.term.AllText(), "BBS two")
	})
}
