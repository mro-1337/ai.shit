TrayCorral
==========
Hide running programs and manage them from one control panel in the system tray.

SETUP (one time)
1. Right-click the zip > "Extract All..." (don't run it from inside the zip).
2. Double-click Build-TrayCorral.bat. It builds TrayCorral.exe with the compiler
   that already comes with Windows, then starts it.
   (If Windows shows a "protected your PC" box, click "More info" > "Run anyway".)
3. Look for the blue fence icon in the tray (click the ^ by the clock if hidden).
   You can drag it out onto the taskbar so it's always visible.

USING IT
- Left-click the tray icon: opens the control panel.
    Left side  = open windows. Select one or more, click "Hide selected" (or double-click).
    Right side = hidden programs. "Show again", "Close program", or "Force quit".
- Right-click the tray icon: quick menu listing every hidden program with
  Show / Close / Force quit, plus "Show all hidden" and "Exit".
- Ctrl+Alt+H: hides whatever window you're currently in.
- Closing the control panel just tucks it back into the tray.
- Tick "Start TrayCorral when Windows starts" to have it load at login.
- Programs made of several windows (like WACUP/Winamp: player, playlist,
  equalizer, library) are hidden and shown back as one.
  If a program still leaves a window behind, tick
  "Hide every window of a program together".

GOOD TO KNOW
- Works on both 32-bit and 64-bit Windows (Windows 7 or newer recommended).
  The same TrayCorral.exe runs on either; it automatically uses the right mode.
- "Close program" asks politely, like clicking the X. If the program doesn't
  close (it's asking "Save changes?", or it just minimizes to its own tray icon),
  TrayCorral shows it again so nothing gets stuck invisible.
- "Force quit" ends the whole program immediately (asks first).
- If you exit TrayCorral with programs still hidden, it asks whether to show them.
  Even if it crashes, starting it again finds them.
- Programs running as administrator can only be hidden if TrayCorral is also run
  as administrator (right-click TrayCorral.exe > Run as administrator).
