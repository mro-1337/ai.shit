// TrayCorral - hide running program windows and manage them from one tray control panel.
// Build with Build-TrayCorral.bat (uses the C# compiler that ships with Windows / .NET Framework 4).
// Written in C# 5 syntax so the built-in compiler can handle it.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: System.Reflection.AssemblyTitle("TrayCorral")]
[assembly: System.Reflection.AssemblyProduct("TrayCorral")]
[assembly: System.Reflection.AssemblyVersion("1.0.0.0")]

namespace TrayCorral
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            try { Native.SetProcessDPIAware(); } catch { }
            // Built as AnyCPU: runs as 32-bit on 32-bit Windows and 64-bit on 64-bit Windows.

            bool createdNew;
            using (var mutex = new System.Threading.Mutex(true, "TrayCorral_SingleInstance_Mutex", out createdNew))
            {
                if (!createdNew)
                {
                    MessageBox.Show("TrayCorral is already running.\n\nLook for its icon in the system tray (you may need to click the ^ arrow next to the clock).",
                        "TrayCorral", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);

                var form = new MainForm();
                IntPtr forceHandle = form.Handle; // create the window handle so the hotkey works while hidden
                form.LoadHiddenFromLastTime();
                Application.Run();
                GC.KeepAlive(mutex);
            }
        }
    }

    // ------------------------------------------------------------------ Win32
    static class Native
    {
        public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
        [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lParam);
        [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr hWnd, StringBuilder sb, int max);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowTextLength(IntPtr hWnd);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetClassName(IntPtr hWnd, StringBuilder sb, int max);
        [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
        [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int cmd);
        [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr hWnd, uint msg, IntPtr w, IntPtr l);
        [DllImport("user32.dll")] public static extern IntPtr GetWindow(IntPtr hWnd, uint cmd);
        [DllImport("user32.dll", EntryPoint = "GetWindowLongW")] public static extern int GetWindowLong(IntPtr hWnd, int idx);
        [DllImport("user32.dll")] public static extern IntPtr GetAncestor(IntPtr hWnd, uint flags);
        [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint mods, uint vk);
        [DllImport("user32.dll")] public static extern bool UnregisterHotKey(IntPtr hWnd, int id);
        [DllImport("dwmapi.dll")] public static extern int DwmGetWindowAttribute(IntPtr hWnd, int attr, out int val, int size);
        [DllImport("kernel32.dll")] public static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] public static extern bool QueryFullProcessImageName(IntPtr h, int flags, StringBuilder sb, ref int size);
        [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr h);

        public const int SW_HIDE = 0, SW_SHOWNA = 8, SW_SHOW = 5, SW_RESTORE = 9;
        public const uint WM_CLOSE = 0x0010;
        public const int WM_HOTKEY = 0x0312;
        public const uint GW_OWNER = 4, GA_ROOTOWNER = 3;
        public const int GWL_EXSTYLE = -20, WS_EX_TOOLWINDOW = 0x80;
        public const int DWMWA_CLOAKED = 14;
        public const uint MOD_ALT = 1, MOD_CONTROL = 2, MOD_NOREPEAT = 0x4000;

        public static string GetTitle(IntPtr h)
        {
            int len = GetWindowTextLength(h);
            if (len <= 0) return "";
            var sb = new StringBuilder(len + 2);
            GetWindowText(h, sb, sb.Capacity);
            return sb.ToString();
        }

        public static string GetClass(IntPtr h)
        {
            var sb = new StringBuilder(256);
            GetClassName(h, sb, sb.Capacity);
            return sb.ToString();
        }

        public static uint GetPid(IntPtr h)
        {
            uint pid;
            GetWindowThreadProcessId(h, out pid);
            return pid;
        }

        public static string GetExePath(uint pid)
        {
            try
            {
                IntPtr hp = OpenProcess(0x1000 /* PROCESS_QUERY_LIMITED_INFORMATION */, false, pid);
                if (hp != IntPtr.Zero)
                {
                    try
                    {
                        var sb = new StringBuilder(1024);
                        int size = sb.Capacity;
                        if (QueryFullProcessImageName(hp, 0, sb, ref size)) return sb.ToString();
                    }
                    finally { CloseHandle(hp); }
                }
            }
            catch { } // very old Windows without this API: fall back below
            try { return Process.GetProcessById((int)pid).MainModule.FileName; }
            catch { return null; } // e.g. a 64-bit program viewed from 32-bit, or an admin program
        }
    }

    // ------------------------------------------------------------------ Window info
    class WinItem
    {
        public IntPtr Handle;
        public string Title;
        public string ProcessName;
        public uint Pid;
        public string ExePath;
        // Other windows of the same program hidden together with this one
        // (e.g. a music player's playlist, equalizer and library windows).
        public List<IntPtr> Companions = new List<IntPtr>();

        public static WinItem From(IntPtr h)
        {
            var w = new WinItem();
            w.Handle = h;
            w.Title = Native.GetTitle(h);
            w.Pid = Native.GetPid(h);
            w.ExePath = Native.GetExePath(w.Pid);
            if (!string.IsNullOrEmpty(w.ExePath))
                w.ProcessName = Path.GetFileNameWithoutExtension(w.ExePath);
            else
            {
                try { w.ProcessName = Process.GetProcessById((int)w.Pid).ProcessName; }
                catch { w.ProcessName = "(unknown)"; }
            }
            return w;
        }
    }

    // ------------------------------------------------------------------ Main window + tray
    class MainForm : Form
    {
        const int HOTKEY_ID = 1;
        const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";

        readonly List<WinItem> hidden = new List<WinItem>();
        readonly uint ownPid = (uint)Process.GetCurrentProcess().Id;
        readonly string dataFile;

        NotifyIcon tray;
        ContextMenuStrip trayMenu;
        ListView lvOpen, lvHidden;
        GroupBox grpOpen, grpHidden;
        ImageList images;
        CheckBox chkStartup;
        CheckBox chkWhole;
        const string SettingsKey = @"Software\TrayCorral";
        Label lblTip;
        Timer timer;
        Icon appIcon;
        bool hotkeyOk;
        bool exiting;
        string lastOpenSignature = "";

        public MainForm()
        {
            dataFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "TrayCorral", "hidden.txt");

            Text = "TrayCorral";
            appIcon = MakeAppIcon();
            Icon = appIcon;
            Font = SystemFonts.MessageBoxFont;
            ClientSize = new Size(900, 500);
            MinimumSize = new Size(660, 380);
            StartPosition = FormStartPosition.CenterScreen;

            images = new ImageList();
            images.ColorDepth = ColorDepth.Depth32Bit;
            images.ImageSize = new Size(16, 16);
            images.Images.Add("_default", SystemIcons.Application.ToBitmap());

            BuildLayout();
            BuildTray();

            timer = new Timer();
            timer.Interval = 2000;
            timer.Tick += delegate { Tick(); };
            timer.Start();
        }

        // ---------------- layout
        void BuildLayout()
        {
            lvOpen = MakeListView();
            lvHidden = MakeListView();
            lvOpen.DoubleClick += delegate { HideSelected(); };
            lvHidden.DoubleClick += delegate { ShowSelected(); };
            lvOpen.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) HideSelected(); };
            lvHidden.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) ShowSelected(); };

            grpOpen = MakeGroup("Open windows", lvOpen,
                MakeButton("Hide selected  \u2192", delegate { HideSelected(); }, true),
                MakeButton("Refresh", delegate { RefreshOpen(true); }, false));

            grpHidden = MakeGroup("Hidden programs", lvHidden,
                MakeButton("\u2190  Show again", delegate { ShowSelected(); }, true),
                MakeButton("Close program", delegate { CloseSelected(false); }, false),
                MakeButton("Force quit", delegate { CloseSelected(true); }, false));

            chkStartup = new CheckBox();
            chkStartup.Text = "Start TrayCorral when Windows starts";
            chkStartup.AutoSize = true;
            chkStartup.Margin = new Padding(3, 6, 20, 3);
            chkStartup.Checked = GetStartup();
            chkStartup.CheckedChanged += delegate { SetStartup(chkStartup.Checked); };

            chkWhole = new CheckBox();
            chkWhole.Text = "Hide every window of a program together";
            chkWhole.AutoSize = true;
            chkWhole.Margin = new Padding(3, 6, 20, 3);
            chkWhole.Checked = GetWholeProgram();
            chkWhole.CheckedChanged += delegate { SetWholeProgram(chkWhole.Checked); };

            lblTip = new Label();
            lblTip.AutoSize = true;
            lblTip.Margin = new Padding(3, 7, 3, 3);
            lblTip.ForeColor = SystemColors.GrayText;
            lblTip.Text = "Tip: Ctrl+Alt+H hides whatever window you're in.  Closing this panel keeps TrayCorral running in the tray.";

            var bottom = new FlowLayoutPanel();
            bottom.Dock = DockStyle.Fill;
            bottom.AutoSize = true;
            bottom.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            bottom.WrapContents = true;
            bottom.Controls.Add(chkStartup);
            bottom.Controls.Add(chkWhole);
            bottom.Controls.Add(lblTip);

            var root = new TableLayoutPanel();
            root.Dock = DockStyle.Fill;
            root.Padding = new Padding(8);
            root.ColumnCount = 2;
            root.RowCount = 2;
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.Controls.Add(grpOpen, 0, 0);
            root.Controls.Add(grpHidden, 1, 0);
            root.Controls.Add(bottom, 0, 1);
            root.SetColumnSpan(bottom, 2);
            Controls.Add(root);
        }

        ListView MakeListView()
        {
            var lv = new ListView();
            lv.View = View.Details;
            lv.FullRowSelect = true;
            lv.HideSelection = false;
            lv.MultiSelect = true;
            lv.SmallImageList = images;
            lv.Dock = DockStyle.Fill;
            lv.HeaderStyle = ColumnHeaderStyle.Nonclickable;
            lv.Columns.Add("Window", 260);
            lv.Columns.Add("Program", 120);
            lv.Resize += delegate
            {
                int w = lv.ClientSize.Width - lv.Columns[1].Width - 4;
                if (w > 80) lv.Columns[0].Width = w;
            };
            return lv;
        }

        Button MakeButton(string text, EventHandler onClick, bool bold)
        {
            var b = new Button();
            b.Text = text;
            b.AutoSize = true;
            b.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            b.Padding = new Padding(6, 2, 6, 2);
            if (bold) b.Font = new Font(Font, FontStyle.Bold);
            b.Click += onClick;
            return b;
        }

        GroupBox MakeGroup(string title, ListView lv, params Button[] buttons)
        {
            var g = new GroupBox();
            g.Text = title;
            g.Dock = DockStyle.Fill;
            g.Padding = new Padding(8);

            var flow = new FlowLayoutPanel();
            flow.Dock = DockStyle.Bottom;
            flow.AutoSize = true;
            flow.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            flow.Padding = new Padding(0, 6, 0, 0);
            foreach (var b in buttons) flow.Controls.Add(b);

            g.Controls.Add(lv);
            g.Controls.Add(flow);
            lv.BringToFront(); // make the list fill the space left above the buttons
            return g;
        }

        // ---------------- tray
        void BuildTray()
        {
            trayMenu = new ContextMenuStrip();
            trayMenu.Items.Add("..."); // placeholder so the menu is allowed to open
            trayMenu.Opening += (s, e) => { BuildTrayMenu(); e.Cancel = false; };

            tray = new NotifyIcon();
            tray.Icon = appIcon;
            tray.Text = "TrayCorral";
            tray.ContextMenuStrip = trayMenu;
            tray.MouseClick += (s, e) => { if (e.Button == MouseButtons.Left) ShowPanel(); };
            tray.Visible = true;
        }

        void BuildTrayMenu()
        {
            PruneHidden();
            trayMenu.Items.Clear();

            var open = new ToolStripMenuItem("Open control panel");
            open.Font = new Font(open.Font, FontStyle.Bold);
            open.Click += delegate { ShowPanel(); };
            trayMenu.Items.Add(open);
            trayMenu.Items.Add(new ToolStripSeparator());

            if (hidden.Count == 0)
            {
                var none = new ToolStripMenuItem("(no hidden programs)");
                none.Enabled = false;
                trayMenu.Items.Add(none);
            }
            else
            {
                foreach (var w in hidden.ToArray())
                {
                    var item = w;
                    var mi = new ToolStripMenuItem(Shorten(item.Title, 50));
                    mi.Image = images.Images[IconKeyFor(item)];
                    mi.ToolTipText = item.ProcessName;

                    var show = new ToolStripMenuItem("Show");
                    show.Font = new Font(show.Font, FontStyle.Bold);
                    show.Click += delegate { ShowItem(item, true); };
                    var close = new ToolStripMenuItem("Close program");
                    close.Click += delegate { CloseItem(item, false); };
                    var kill = new ToolStripMenuItem("Force quit");
                    kill.Click += delegate { CloseItem(item, true); };

                    mi.DropDownItems.Add(show);
                    mi.DropDownItems.Add(close);
                    mi.DropDownItems.Add(kill);
                    mi.DoubleClickEnabled = true;
                    mi.DoubleClick += delegate { ShowItem(item, true); };
                    trayMenu.Items.Add(mi);
                }
            }

            trayMenu.Items.Add(new ToolStripSeparator());
            var showAll = new ToolStripMenuItem("Show all hidden");
            showAll.Enabled = hidden.Count > 0;
            showAll.Click += delegate { foreach (var w in hidden.ToArray()) ShowItem(w, false); };
            trayMenu.Items.Add(showAll);

            var exit = new ToolStripMenuItem("Exit TrayCorral");
            exit.Click += delegate { ExitApp(); };
            trayMenu.Items.Add(exit);
        }

        void UpdateTrayText()
        {
            tray.Text = hidden.Count == 0 ? "TrayCorral" : "TrayCorral - " + hidden.Count + " hidden";
        }

        void ShowPanel()
        {
            RefreshOpen(true);
            RefreshHidden();
            Show();
            if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
            Activate();
            BringToFront();
        }

        // ---------------- window discovery
        bool IsCandidate(IntPtr h)
        {
            if (h == IntPtr.Zero || !Native.IsWindowVisible(h)) return false;
            if (Native.GetWindowTextLength(h) == 0) return false;
            if (Native.GetWindow(h, Native.GW_OWNER) != IntPtr.Zero) return false;
            if ((Native.GetWindowLong(h, Native.GWL_EXSTYLE) & Native.WS_EX_TOOLWINDOW) != 0) return false;
            int cloaked;
            try
            {
                if (Native.DwmGetWindowAttribute(h, Native.DWMWA_CLOAKED, out cloaked, 4) == 0 && cloaked != 0) return false;
            }
            catch { }
            string cls = Native.GetClass(h);
            if (cls == "Progman" || cls == "WorkerW" || cls == "Shell_TrayWnd" || cls == "Shell_SecondaryTrayWnd") return false;
            if (Native.GetPid(h) == ownPid) return false;
            return true;
        }

        List<WinItem> EnumOpen()
        {
            var list = new List<WinItem>();
            Native.EnumWindows((h, l) =>
            {
                if (IsCandidate(h)) list.Add(WinItem.From(h));
                return true;
            }, IntPtr.Zero);
            list.Sort((a, b) =>
            {
                int c = string.Compare(a.ProcessName, b.ProcessName, StringComparison.OrdinalIgnoreCase);
                return c != 0 ? c : string.Compare(a.Title, b.Title, StringComparison.OrdinalIgnoreCase);
            });
            return list;
        }

        string IconKeyFor(WinItem w)
        {
            if (string.IsNullOrEmpty(w.ExePath)) return "_default";
            string key = w.ExePath.ToLowerInvariant();
            if (!images.Images.ContainsKey(key))
            {
                try
                {
                    using (var ic = Icon.ExtractAssociatedIcon(w.ExePath))
                        images.Images.Add(key, ic.ToBitmap());
                }
                catch { return "_default"; }
            }
            return key;
        }

        // ---------------- list refresh
        void RefreshOpen(bool force)
        {
            var items = EnumOpen();
            var sig = new StringBuilder();
            foreach (var w in items) sig.Append(w.Handle.ToInt64()).Append('|').Append(w.Title).Append('\n');
            string s = sig.ToString();
            if (!force && s == lastOpenSignature) return;
            lastOpenSignature = s;
            FillList(lvOpen, items);
            grpOpen.Text = "Open windows (" + items.Count + ")";
        }

        void RefreshHidden()
        {
            FillList(lvHidden, hidden);
            grpHidden.Text = "Hidden programs (" + hidden.Count + ")";
            UpdateTrayText();
        }

        void FillList(ListView lv, List<WinItem> items)
        {
            var selected = new HashSet<long>();
            foreach (ListViewItem it in lv.SelectedItems) selected.Add(((WinItem)it.Tag).Handle.ToInt64());
            int top = lv.TopItem != null ? lv.TopItem.Index : 0;

            lv.BeginUpdate();
            lv.Items.Clear();
            foreach (var w in items)
            {
                var it = new ListViewItem(new string[] { w.Title, w.ProcessName });
                it.Tag = w;
                it.ImageKey = IconKeyFor(w);
                it.ToolTipText = w.ExePath ?? "";
                if (selected.Contains(w.Handle.ToInt64())) it.Selected = true;
                lv.Items.Add(it);
            }
            lv.EndUpdate();
            if (lv.Items.Count > 0)
            {
                try { lv.TopItem = lv.Items[Math.Min(top, lv.Items.Count - 1)]; } catch { }
            }
        }

        void Tick()
        {
            bool changed = PruneHidden();
            if (Visible)
            {
                RefreshOpen(false);
                if (changed) RefreshHidden();
            }
            else if (changed) UpdateTrayText();
        }

        // Drops hidden entries whose window is gone, or that the program re-showed itself.
        bool PruneHidden()
        {
            int removed = 0;
            foreach (var w in hidden.ToArray())
            {
                bool gone = !Native.IsWindow(w.Handle);
                if (gone || Native.IsWindowVisible(w.Handle))
                {
                    // If the program brought its main window back by itself, bring its other windows back too.
                    if (!gone) ShowCompanions(w);
                    hidden.Remove(w);
                    removed++;
                }
            }
            if (removed > 0) SaveHidden();
            return removed > 0;
        }

        bool IsHiddenCompanion(IntPtr h)
        {
            foreach (var w in hidden) if (w.Companions.Contains(h)) return true;
            return false;
        }

        static bool IsIgnorableHelperWindow(IntPtr h)
        {
            string cls = Native.GetClass(h);
            return cls == "tooltips_class32" || cls == "IME" || cls == "MSCTFIME UI" || cls.StartsWith("SysShadow");
        }

        // The program's other visible top-level windows that should disappear along with the main one.
        List<IntPtr> FindCompanions(IntPtr main, uint pid)
        {
            bool whole = chkWhole != null && chkWhole.Checked;
            var list = new List<IntPtr>();
            Native.EnumWindows((h, l) =>
            {
                if (h == main || !Native.IsWindowVisible(h) || Native.GetPid(h) != pid) return true;
                if (IsIgnorableHelperWindow(h)) return true;
                // Attached windows (no taskbar button of their own) always go along.
                // Separate full windows of the same program only go along if the checkbox is on.
                if (whole || !IsCandidate(h)) list.Add(h);
                return true;
            }, IntPtr.Zero);
            return list;
        }

        void ShowCompanions(WinItem w)
        {
            foreach (var c in w.Companions)
                if (Native.IsWindow(c) && !Native.IsWindowVisible(c)) Native.ShowWindow(c, Native.SW_SHOWNA);
            w.Companions.Clear();
        }

        // ---------------- actions
        List<WinItem> Selected(ListView lv)
        {
            var list = new List<WinItem>();
            foreach (ListViewItem it in lv.SelectedItems) list.Add((WinItem)it.Tag);
            return list;
        }

        void HideSelected()
        {
            var sel = Selected(lvOpen);
            if (sel.Count == 0) { Hint("Pick one or more windows on the left first."); return; }
            var failed = new List<string>();
            foreach (var w in sel) if (!HideItem(w)) failed.Add(w.Title);
            RefreshOpen(true);
            RefreshHidden();
            if (failed.Count > 0)
                MessageBox.Show(this, "Couldn't hide:\n\n" + string.Join("\n", failed.ToArray()) +
                    "\n\nThis usually means the program is running as administrator. Run TrayCorral as administrator to hide it.",
                    "TrayCorral", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        bool HideItem(WinItem w)
        {
            if (!Native.IsWindow(w.Handle)) return true;
            if (hidden.Exists(x => x.Handle == w.Handle) || IsHiddenCompanion(w.Handle)) return true; // already hidden
            w.Companions = FindCompanions(w.Handle, w.Pid);
            Native.ShowWindow(w.Handle, Native.SW_HIDE);
            if (Native.IsWindowVisible(w.Handle)) { w.Companions.Clear(); return false; }
            foreach (var c in w.Companions) Native.ShowWindow(c, Native.SW_HIDE);
            // Keep only the ones that actually went away (some may have closed or been hidden by the program itself).
            w.Companions.RemoveAll(c => !Native.IsWindow(c) || Native.IsWindowVisible(c));
            hidden.Add(w);
            SaveHidden();
            return true;
        }

        void ShowSelected()
        {
            var sel = Selected(lvHidden);
            if (sel.Count == 0) { Hint("Pick one or more programs on the right first."); return; }
            for (int i = 0; i < sel.Count; i++) ShowItem(sel[i], i == sel.Count - 1);
        }

        void ShowItem(WinItem w, bool bringToFront)
        {
            hidden.RemoveAll(x => x.Handle == w.Handle);
            if (Native.IsWindow(w.Handle))
            {
                Native.ShowWindow(w.Handle, Native.SW_SHOW);
                if (Native.IsIconic(w.Handle)) Native.ShowWindow(w.Handle, Native.SW_RESTORE);
                ShowCompanions(w);
                if (bringToFront) Native.SetForegroundWindow(w.Handle);
            }
            else ShowCompanions(w);
            SaveHidden();
            if (Visible) { RefreshOpen(true); RefreshHidden(); } else UpdateTrayText();
        }

        void CloseSelected(bool force)
        {
            var sel = Selected(lvHidden);
            if (sel.Count == 0) { Hint("Pick one or more programs on the right first."); return; }
            foreach (var w in sel) CloseItem(w, force);
        }

        void CloseItem(WinItem w, bool force)
        {
            if (force)
            {
                var r = MessageBox.Show(Visible ? this : null,
                    "Force quit " + w.ProcessName + "?\n\n\"" + w.Title + "\"\n\n" +
                    "This ends the whole program immediately, including any of its other windows. Unsaved work will be lost.",
                    "TrayCorral", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                if (r != DialogResult.Yes) return;
                try
                {
                    var p = Process.GetProcessById((int)w.Pid);
                    p.Kill();
                    p.WaitForExit(3000);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Couldn't force quit " + w.ProcessName + ":\n" + ex.Message +
                        "\n\nIf it's running as administrator, TrayCorral needs to be too.", "TrayCorral",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                hidden.RemoveAll(x => x.Pid == w.Pid);
                SaveHidden();
                if (Visible) { RefreshOpen(true); RefreshHidden(); } else UpdateTrayText();
                return;
            }

            // Polite close: ask the program to close the same way the X button does.
            Native.PostMessage(w.Handle, Native.WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
            var t = new Timer();
            t.Interval = 1500;
            t.Tick += delegate
            {
                t.Stop();
                t.Dispose();
                if (Native.IsWindow(w.Handle) && hidden.Exists(x => x.Handle == w.Handle))
                {
                    // Still there: it may be asking "Save changes?" or it only minimizes to tray. Show it so nothing gets stuck invisibly.
                    ShowItem(w, true);
                    tray.ShowBalloonTip(6000, "TrayCorral",
                        "\"" + Shorten(w.Title, 40) + "\" didn't close on its own, so it's been shown. " +
                        "It may be asking you something, or it only hides when closed (use Force quit for those).",
                        ToolTipIcon.Info);
                }
                else
                {
                    hidden.RemoveAll(x => x.Handle == w.Handle);
                    SaveHidden();
                    if (Visible) { RefreshOpen(true); RefreshHidden(); } else UpdateTrayText();
                }
            };
            t.Start();
        }

        void HideForegroundWindow()
        {
            IntPtr h = Native.GetForegroundWindow();
            IntPtr root = Native.GetAncestor(h, Native.GA_ROOTOWNER);
            if (root != IntPtr.Zero) h = root;
            if (!IsCandidate(h)) { System.Media.SystemSounds.Beep.Play(); return; }
            var w = WinItem.From(h);
            if (HideItem(w))
            {
                if (Visible) { RefreshOpen(true); RefreshHidden(); } else UpdateTrayText();
                tray.ShowBalloonTip(2500, "Hidden", Shorten(w.Title, 60) + "\nClick the TrayCorral icon to get it back.", ToolTipIcon.None);
            }
            else System.Media.SystemSounds.Beep.Play();
        }

        void Hint(string msg)
        {
            MessageBox.Show(this, msg, "TrayCorral", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // ---------------- persistence (so hidden windows can be recovered if TrayCorral is closed or crashes)
        void SaveHidden()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(dataFile));
                var lines = new List<string>();
                foreach (var w in hidden)
                {
                    var comp = new List<string>();
                    foreach (var c in w.Companions) comp.Add(c.ToInt64().ToString());
                    lines.Add(w.Handle.ToInt64() + "\t" + w.Pid + "\t" +
                        (w.Title ?? "").Replace("\t", " ").Replace("\r", " ").Replace("\n", " ") + "\t" +
                        string.Join(",", comp.ToArray()));
                }
                File.WriteAllLines(dataFile, lines.ToArray(), Encoding.UTF8);
            }
            catch { }
        }

        public void LoadHiddenFromLastTime()
        {
            int recovered = 0;
            try
            {
                if (!File.Exists(dataFile)) return;
                foreach (var line in File.ReadAllLines(dataFile, Encoding.UTF8))
                {
                    var parts = line.Split('\t');
                    if (parts.Length < 2) continue;
                    long hv; uint pid;
                    if (!long.TryParse(parts[0], out hv) || !uint.TryParse(parts[1], out pid)) continue;
                    var h = new IntPtr(hv);
                    // Make sure it's still the same program's window and it's still hidden.
                    if (Native.IsWindow(h) && !Native.IsWindowVisible(h) && Native.GetPid(h) == pid)
                    {
                        var w = WinItem.From(h);
                        if (parts.Length >= 4)
                            foreach (var cs in parts[3].Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                            {
                                long cv;
                                if (!long.TryParse(cs, out cv)) continue;
                                var ch = new IntPtr(cv);
                                if (Native.IsWindow(ch) && !Native.IsWindowVisible(ch) && Native.GetPid(ch) == pid) w.Companions.Add(ch);
                            }
                        hidden.Add(w);
                        recovered++;
                    }
                }
            }
            catch { }
            SaveHidden();
            UpdateTrayText();
            if (recovered > 0)
                tray.ShowBalloonTip(4000, "TrayCorral",
                    "Found " + recovered + " program(s) still hidden from last time. Click the tray icon to manage them.", ToolTipIcon.Info);
        }

        // ---------------- startup with Windows
        static bool GetStartup()
        {
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(RunKey))
                    return k != null && k.GetValue("TrayCorral") != null;
            }
            catch { return false; }
        }

        static void SetStartup(bool on)
        {
            try
            {
                using (var k = Registry.CurrentUser.CreateSubKey(RunKey))
                {
                    if (on) k.SetValue("TrayCorral", "\"" + Application.ExecutablePath + "\"");
                    else k.DeleteValue("TrayCorral", false);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Couldn't change the startup setting:\n" + ex.Message, "TrayCorral");
            }
        }

        static bool GetWholeProgram()
        {
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(SettingsKey))
                    return k != null && Convert.ToInt32(k.GetValue("HideWholeProgram", 0)) != 0;
            }
            catch { return false; }
        }

        static void SetWholeProgram(bool on)
        {
            try
            {
                using (var k = Registry.CurrentUser.CreateSubKey(SettingsKey))
                    k.SetValue("HideWholeProgram", on ? 1 : 0, RegistryValueKind.DWord);
            }
            catch { }
        }

        // ---------------- exit
        void ExitApp()
        {
            PruneHidden();
            if (hidden.Count > 0)
            {
                var r = MessageBox.Show(
                    hidden.Count + " program(s) are still hidden.\n\n" +
                    "Yes: show them all, then exit.\n" +
                    "No: exit and leave them hidden (TrayCorral will find them again next time it starts).\n" +
                    "Cancel: don't exit.",
                    "Exit TrayCorral", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (r == DialogResult.Cancel) return;
                if (r == DialogResult.Yes) foreach (var w in hidden.ToArray()) ShowItem(w, false);
            }
            SaveHidden();
            exiting = true;
            tray.Visible = false;
            Application.Exit();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (!exiting && e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide(); // closing the panel just tucks it back into the tray
                return;
            }
            SaveHidden();
            tray.Visible = false;
            base.OnFormClosing(e);
        }

        // ---------------- hotkey (Ctrl+Alt+H)
        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            hotkeyOk = Native.RegisterHotKey(Handle, HOTKEY_ID, Native.MOD_CONTROL | Native.MOD_ALT | Native.MOD_NOREPEAT, (uint)Keys.H);
            if (!hotkeyOk) // older Windows doesn't know MOD_NOREPEAT
                hotkeyOk = Native.RegisterHotKey(Handle, HOTKEY_ID, Native.MOD_CONTROL | Native.MOD_ALT, (uint)Keys.H);
            if (!hotkeyOk && lblTip != null)
                lblTip.Text = "(Ctrl+Alt+H is taken by another program, so the hide-active-window hotkey is off.)  Closing this panel keeps TrayCorral running in the tray.";
        }

        protected override void OnHandleDestroyed(EventArgs e)
        {
            if (hotkeyOk) Native.UnregisterHotKey(Handle, HOTKEY_ID);
            base.OnHandleDestroyed(e);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == Native.WM_HOTKEY && m.WParam.ToInt32() == HOTKEY_ID) HideForegroundWindow();
            base.WndProc(ref m);
        }

        // ---------------- helpers
        static string Shorten(string s, int max)
        {
            if (string.IsNullOrEmpty(s)) return "(untitled)";
            return s.Length <= max ? s : s.Substring(0, max - 1) + "\u2026";
        }

        static Icon MakeAppIcon()
        {
            var bmp = new Bitmap(32, 32);
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);
                using (var path = new GraphicsPath())
                {
                    var r = new Rectangle(1, 1, 29, 29);
                    int d = 12;
                    path.AddArc(r.X, r.Y, d, d, 180, 90);
                    path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
                    path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
                    path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
                    path.CloseFigure();
                    using (var b = new SolidBrush(Color.FromArgb(255, 34, 104, 170))) g.FillPath(b, path);
                }
                // a little fence (the "corral")
                using (var rail = new Pen(Color.White, 3f))
                {
                    g.DrawLine(rail, 6, 12, 26, 12);
                    g.DrawLine(rail, 6, 20, 26, 20);
                }
                using (var post = new Pen(Color.White, 3.5f))
                {
                    g.DrawLine(post, 8, 7, 8, 25);
                    g.DrawLine(post, 16, 7, 16, 25);
                    g.DrawLine(post, 24, 7, 24, 25);
                }
            }
            return Icon.FromHandle(bmp.GetHicon());
        }
    }
}
