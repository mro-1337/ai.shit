// TrayCorral - keep a saved list of programs; whenever one of them is minimized it is hidden
// into one control panel in the system tray, where you can show it again or close it.
// Build with Build-TrayCorral.bat (uses the C# compiler that ships with Windows / .NET Framework 4).
// Written in C# 5 syntax so the built-in compiler can handle it.
// Built as AnyCPU: runs as 32-bit on 32-bit Windows and 64-bit on 64-bit Windows.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: System.Reflection.AssemblyTitle("TrayCorral")]
[assembly: System.Reflection.AssemblyProduct("TrayCorral")]
[assembly: System.Reflection.AssemblyVersion("2.0.0.0")]

namespace TrayCorral
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            try { Native.SetProcessDPIAware(); } catch { }

            bool createdNew;
            using (var mutex = new System.Threading.Mutex(true, "TrayCorral_SingleInstance_Mutex", out createdNew))
            {
                if (!createdNew)
                {
                    MessageBox.Show("TrayCorral is already running.\n\nLook for its icon in the system tray (you may need to click the ^ arrow next to the clock).",
                        "TrayCorral", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);

                var form = new MainForm();
                IntPtr forceHandle = form.Handle; // create the window handle so the hotkey works while the panel is hidden
                form.LoadHiddenFromLastTime();
                form.Scan(); // hide any listed programs that are already minimized
                Application.Run();
                GC.KeepAlive(mutex);
            }
        }
    }

    // ------------------------------------------------------------------ Win32
    static class Native
    {
        public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
        public delegate void WinEventProc(IntPtr hook, uint evt, IntPtr hwnd, int idObject, int idChild, uint thread, uint time);

        [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
        [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lParam);
        [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr hWnd, StringBuilder sb, int max);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowTextLength(IntPtr hWnd);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetClassName(IntPtr hWnd, StringBuilder sb, int max);
        [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
        [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int cmd);
        [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr hWnd, uint msg, IntPtr w, IntPtr l);
        [DllImport("user32.dll")] public static extern IntPtr GetWindow(IntPtr hWnd, uint cmd);
        [DllImport("user32.dll", EntryPoint = "GetWindowLongW")] public static extern int GetWindowLong(IntPtr hWnd, int idx);
        [DllImport("user32.dll")] public static extern IntPtr GetAncestor(IntPtr hWnd, uint flags);
        [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint mods, uint vk);
        [DllImport("user32.dll")] public static extern bool UnregisterHotKey(IntPtr hWnd, int id);
        [DllImport("user32.dll")] public static extern IntPtr SetWinEventHook(uint evMin, uint evMax, IntPtr hmod, WinEventProc proc, uint pid, uint tid, uint flags);
        [DllImport("user32.dll")] public static extern bool UnhookWinEvent(IntPtr hook);
        [DllImport("dwmapi.dll")] public static extern int DwmGetWindowAttribute(IntPtr hWnd, int attr, out int val, int size);
        [DllImport("kernel32.dll")] public static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] public static extern bool QueryFullProcessImageName(IntPtr h, int flags, StringBuilder sb, ref int size);
        [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr h);

        public const int SW_HIDE = 0, SW_SHOW = 5, SW_SHOWNA = 8, SW_RESTORE = 9;
        public const uint WM_CLOSE = 0x0010;
        public const int WM_HOTKEY = 0x0312;
        public const uint GW_OWNER = 4, GA_ROOTOWNER = 3;
        public const int GWL_EXSTYLE = -20, WS_EX_TOOLWINDOW = 0x80;
        public const int DWMWA_CLOAKED = 14;
        public const uint MOD_ALT = 1, MOD_CONTROL = 2, MOD_NOREPEAT = 0x4000;
        public const uint EVENT_SYSTEM_MINIMIZESTART = 0x0016, WINEVENT_OUTOFCONTEXT = 0, WINEVENT_SKIPOWNPROCESS = 2;

        public static string GetTitle(IntPtr h)
        {
            int len = GetWindowTextLength(h);
            if (len <= 0) return "";
            var sb = new StringBuilder(len + 2);
            GetWindowText(h, sb, sb.Capacity);
            return sb.ToString();
        }

        public static string GetClass(IntPtr h)
        {
            var sb = new StringBuilder(256);
            GetClassName(h, sb, sb.Capacity);
            return sb.ToString();
        }

        public static uint GetPid(IntPtr h)
        {
            uint pid;
            GetWindowThreadProcessId(h, out pid);
            return pid;
        }

        public static string GetExePath(uint pid)
        {
            try
            {
                IntPtr hp = OpenProcess(0x1000 /* PROCESS_QUERY_LIMITED_INFORMATION */, false, pid);
                if (hp != IntPtr.Zero)
                {
                    try
                    {
                        var sb = new StringBuilder(1024);
                        int size = sb.Capacity;
                        if (QueryFullProcessImageName(hp, 0, sb, ref size)) return sb.ToString();
                    }
                    finally { CloseHandle(hp); }
                }
            }
            catch { } // very old Windows without this API: fall back below
            try { return Process.GetProcessById((int)pid).MainModule.FileName; }
            catch { return null; } // e.g. an administrator program
        }
    }

    // ------------------------------------------------------------------ Window info
    class WinItem
    {
        public IntPtr Handle;
        public string Title;
        public string ProcessName;
        public uint Pid;
        public string ExePath;
        // Other windows of the same program hidden together with this one
        // (e.g. a music player's playlist, equalizer and library windows).
        public List<IntPtr> Companions = new List<IntPtr>();

        public static WinItem From(IntPtr h)
        {
            var w = new WinItem();
            w.Handle = h;
            w.Title = Native.GetTitle(h);
            w.Pid = Native.GetPid(h);
            w.ExePath = Native.GetExePath(w.Pid);
            if (!string.IsNullOrEmpty(w.ExePath))
                w.ProcessName = Path.GetFileNameWithoutExtension(w.ExePath);
            else
            {
                try { w.ProcessName = Process.GetProcessById((int)w.Pid).ProcessName; }
                catch { w.ProcessName = "(unknown)"; }
            }
            return w;
        }
    }

    // ------------------------------------------------------------------ Main window + tray
    class MainForm : Form
    {
        const int HOTKEY_ID = 1;
        const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
        const string SettingsKey = @"Software\TrayCorral";

        // The saved list. Each entry is a program's full .exe path (or just "name.exe" if the path couldn't be read).
        readonly List<string> programs = new List<string>();
        // Windows TrayCorral has hidden right now.
        readonly List<WinItem> hidden = new List<WinItem>();
        readonly uint ownPid;
        readonly string dataFile, legacyListFile;

        NotifyIcon tray;
        ContextMenuStrip trayMenu;
        ListView lvOpen, lvProgs;
        GroupBox grpOpen, grpProgs;
        ImageList images;
        CheckBox chkStartup, chkWhole;
        NumericUpDown numInterval;
        Label lblTip;
        Timer uiTimer, scanTimer, minimizeKick;
        Native.WinEventProc winEventProc; // kept in a field so it isn't garbage-collected
        IntPtr winEventHook;
        Icon appIcon;
        bool hotkeyOk, exiting, shownAutoTip;
        string lastOpenSig = "", lastProgSig = "";

        public MainForm()
        {
            ownPid = (uint)Process.GetCurrentProcess().Id;
            string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "TrayCorral");
            dataFile = Path.Combine(dir, "hidden.txt");
            legacyListFile = Path.Combine(dir, "autohide.txt");
            LoadPrograms();

            Text = "TrayCorral";
            appIcon = MakeAppIcon();
            Icon = appIcon;
            Font = SystemFonts.MessageBoxFont;
            ClientSize = new Size(1000, 580);
            MinimumSize = new Size(760, 440);
            StartPosition = FormStartPosition.CenterScreen;

            images = new ImageList();
            images.ColorDepth = ColorDepth.Depth32Bit;
            images.ImageSize = new Size(16, 16);
            images.Images.Add("_default", SystemIcons.Application.ToBitmap());

            BuildLayout();
            BuildTray();

            // Keeps the panel's lists up to date while it's open.
            uiTimer = new Timer();
            uiTimer.Interval = 1500;
            uiTimer.Tick += delegate { if (Visible) RefreshAll(false); };
            uiTimer.Start();

            // The periodic search for minimized programs on the list.
            scanTimer = new Timer();
            scanTimer.Interval = (int)numInterval.Value * 1000;
            scanTimer.Tick += delegate { Scan(); };
            scanTimer.Start();

            // Also react right away when anything gets minimized.
            minimizeKick = new Timer();
            minimizeKick.Interval = 250;
            minimizeKick.Tick += delegate { minimizeKick.Stop(); Scan(); };
            winEventProc = OnWinEvent;
            try
            {
                winEventHook = Native.SetWinEventHook(Native.EVENT_SYSTEM_MINIMIZESTART, Native.EVENT_SYSTEM_MINIMIZESTART,
                    IntPtr.Zero, winEventProc, 0, 0, Native.WINEVENT_OUTOFCONTEXT | Native.WINEVENT_SKIPOWNPROCESS);
            }
            catch { }
            Application.ApplicationExit += delegate { if (winEventHook != IntPtr.Zero) Native.UnhookWinEvent(winEventHook); };
        }

        // ================================================================ layout
        void BuildLayout()
        {
            lvOpen = MakeListView(new string[] { "Window", "Program" }, new int[] { 240, 110 }, 0);
            lvProgs = MakeListView(new string[] { "Program", "Status", "Location" }, new int[] { 130, 150, 200 }, 2);

            lvOpen.DoubleClick += delegate { AddSelectedAndHide(); };
            lvOpen.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) AddSelectedAndHide(); };
            lvProgs.DoubleClick += delegate { ToggleSelected(); };
            lvProgs.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter) ToggleSelected();
                else if (e.KeyCode == Keys.Delete) RemoveSelected();
            };

            grpOpen = MakeGroup("Open windows", lvOpen,
                new Control[] {
                    MakeButton("Add to list and hide  →", delegate { AddSelectedAndHide(); }, true),
                    MakeButton("Refresh", delegate { RefreshAll(true); }, false) },
                null);

            grpProgs = MakeGroup("My programs", lvProgs,
                new Control[] {
                    MakeButton("←  Show", delegate { ShowPrograms(SelectedEntries(), true); }, true),
                    MakeButton("Hide now", delegate { HidePrograms(SelectedEntries(), true); }, false),
                    MakeButton("Close program", delegate { ClosePrograms(SelectedEntries(), false); }, false),
                    MakeButton("Force quit", delegate { ClosePrograms(SelectedEntries(), true); }, false) },
                new Control[] {
                    MakeButton("Add program…", delegate { AddProgramBrowse(); }, false),
                    MakeButton("Remove from list", delegate { RemoveSelected(); }, false) });

            chkStartup = new CheckBox();
            chkStartup.Text = "Start TrayCorral when Windows starts";
            chkStartup.AutoSize = true;
            chkStartup.Margin = new Padding(3, 6, 20, 3);
            chkStartup.Checked = GetStartup();
            chkStartup.CheckedChanged += delegate { SetStartup(chkStartup.Checked); };

            chkWhole = new CheckBox();
            chkWhole.Text = "Hide every window of a program together";
            chkWhole.AutoSize = true;
            chkWhole.Margin = new Padding(3, 6, 20, 3);
            chkWhole.Checked = GetSettingInt("HideWholeProgram", 0) != 0;
            chkWhole.CheckedChanged += delegate { SetSettingInt("HideWholeProgram", chkWhole.Checked ? 1 : 0); };

            var lblEvery = new Label();
            lblEvery.Text = "Check for minimized programs every";
            lblEvery.AutoSize = true;
            lblEvery.Margin = new Padding(3, 7, 3, 3);

            numInterval = new NumericUpDown();
            numInterval.Minimum = 1;
            numInterval.Maximum = 60;
            numInterval.Width = 48;
            numInterval.Margin = new Padding(0, 4, 3, 3);
            numInterval.Value = Math.Max(1, Math.Min(60, GetSettingInt("CheckSeconds", 2)));
            numInterval.ValueChanged += delegate
            {
                SetSettingInt("CheckSeconds", (int)numInterval.Value);
                if (scanTimer != null) scanTimer.Interval = (int)numInterval.Value * 1000;
            };

            var lblSec = new Label();
            lblSec.Text = "seconds";
            lblSec.AutoSize = true;
            lblSec.Margin = new Padding(0, 7, 20, 3);

            lblTip = new Label();
            lblTip.AutoSize = true;
            lblTip.Margin = new Padding(3, 7, 3, 3);
            lblTip.ForeColor = SystemColors.GrayText;
            lblTip.Text = "Every program on your list is hidden here whenever it's minimized. Ctrl+Alt+H adds and hides the window you're in. Closing this panel keeps TrayCorral running.";

            var bottom = new FlowLayoutPanel();
            bottom.Dock = DockStyle.Fill;
            bottom.AutoSize = true;
            bottom.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            bottom.WrapContents = true;
            bottom.Controls.Add(chkStartup);
            bottom.Controls.Add(chkWhole);
            bottom.Controls.Add(lblEvery);
            bottom.Controls.Add(numInterval);
            bottom.Controls.Add(lblSec);
            bottom.SetFlowBreak(lblSec, true);
            bottom.Controls.Add(lblTip);

            var root = new TableLayoutPanel();
            root.Dock = DockStyle.Fill;
            root.Padding = new Padding(8);
            root.ColumnCount = 2;
            root.RowCount = 2;
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42));
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 58));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.Controls.Add(grpOpen, 0, 0);
            root.Controls.Add(grpProgs, 1, 0);
            root.Controls.Add(bottom, 0, 1);
            root.SetColumnSpan(bottom, 2);
            Controls.Add(root);
        }

        ListView MakeListView(string[] names, int[] widths, int fillCol)
        {
            var lv = new ListView();
            lv.View = View.Details;
            lv.FullRowSelect = true;
            lv.HideSelection = false;
            lv.MultiSelect = true;
            lv.SmallImageList = images;
            lv.Dock = DockStyle.Fill;
            lv.HeaderStyle = ColumnHeaderStyle.Nonclickable;
            for (int i = 0; i < names.Length; i++) lv.Columns.Add(names[i], widths[i]);
            lv.Resize += delegate
            {
                int others = 0;
                for (int i = 0; i < lv.Columns.Count; i++) if (i != fillCol) others += lv.Columns[i].Width;
                int w = lv.ClientSize.Width - others - 4;
                if (w > 60) lv.Columns[fillCol].Width = w;
            };
            return lv;
        }

        Button MakeButton(string text, EventHandler onClick, bool bold)
        {
            var b = new Button();
            b.Text = text;
            b.AutoSize = true;
            b.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            b.Padding = new Padding(6, 2, 6, 2);
            if (bold) b.Font = new Font(Font, FontStyle.Bold);
            b.Click += onClick;
            return b;
        }

        static FlowLayoutPanel MakeRow(Control[] controls)
        {
            var row = new FlowLayoutPanel();
            row.AutoSize = true;
            row.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            row.WrapContents = false;
            row.Margin = new Padding(0);
            foreach (var c in controls) row.Controls.Add(c);
            return row;
        }

        GroupBox MakeGroup(string title, ListView lv, Control[] row1, Control[] row2)
        {
            var g = new GroupBox();
            g.Text = title;
            g.Dock = DockStyle.Fill;
            g.Padding = new Padding(8);

            var rows = new FlowLayoutPanel();
            rows.Dock = DockStyle.Bottom;
            rows.AutoSize = true;
            rows.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            rows.FlowDirection = FlowDirection.TopDown;
            rows.WrapContents = false;
            rows.Padding = new Padding(0, 6, 0, 0);
            rows.Controls.Add(MakeRow(row1));
            if (row2 != null) rows.Controls.Add(MakeRow(row2));

            g.Controls.Add(lv);
            g.Controls.Add(rows);
            lv.BringToFront(); // make the list fill the space left above the buttons
            return g;
        }

        // ================================================================ tray
        void BuildTray()
        {
            trayMenu = new ContextMenuStrip();
            trayMenu.Items.Add("..."); // placeholder so the menu is allowed to open
            trayMenu.Opening += (s, e) => { BuildTrayMenu(); e.Cancel = false; };

            tray = new NotifyIcon();
            tray.Icon = appIcon;
            tray.Text = "TrayCorral";
            tray.ContextMenuStrip = trayMenu;
            tray.MouseClick += (s, e) => { if (e.Button == MouseButtons.Left) ShowPanel(); };
            tray.Visible = true;
        }

        void BuildTrayMenu()
        {
            PruneHidden();
            var open = EnumOpen();
            trayMenu.Items.Clear();

            var openPanel = new ToolStripMenuItem("Open control panel");
            openPanel.Font = new Font(openPanel.Font, FontStyle.Bold);
            openPanel.Click += delegate { ShowPanel(); };
            trayMenu.Items.Add(openPanel);
            trayMenu.Items.Add(new ToolStripSeparator());

            if (programs.Count == 0)
            {
                var none = new ToolStripMenuItem("(no programs on your list yet)");
                none.Enabled = false;
                trayMenu.Items.Add(none);
            }
            else
            {
                foreach (var e0 in programs.ToArray())
                {
                    string entry = e0;
                    var one = new List<string>();
                    one.Add(entry);
                    bool hasHidden = hidden.Exists(w => Matches(entry, w));
                    bool hasOpen = open.Exists(w => Matches(entry, w));

                    var mi = new ToolStripMenuItem(DisplayName(entry) + "   —  " + StatusFor(entry, open));
                    mi.Image = images.Images[IconKeyForEntry(entry)];
                    mi.ToolTipText = entry;

                    var show = new ToolStripMenuItem("Show");
                    show.Font = new Font(show.Font, FontStyle.Bold);
                    show.Enabled = hasHidden;
                    show.Click += delegate { ShowPrograms(one, true); };
                    var hideNow = new ToolStripMenuItem("Hide now");
                    hideNow.Enabled = hasOpen;
                    hideNow.Click += delegate { HidePrograms(one, true); };
                    var close = new ToolStripMenuItem("Close program");
                    close.Enabled = hasHidden || hasOpen;
                    close.Click += delegate { ClosePrograms(one, false); };
                    var kill = new ToolStripMenuItem("Force quit");
                    kill.Enabled = hasHidden || hasOpen;
                    kill.Click += delegate { ClosePrograms(one, true); };
                    var remove = new ToolStripMenuItem("Remove from list");
                    remove.Click += delegate { RemovePrograms(one); };

                    mi.DropDownItems.Add(show);
                    mi.DropDownItems.Add(hideNow);
                    mi.DropDownItems.Add(close);
                    mi.DropDownItems.Add(kill);
                    mi.DropDownItems.Add(new ToolStripSeparator());
                    mi.DropDownItems.Add(remove);
                    trayMenu.Items.Add(mi);
                }
            }

            trayMenu.Items.Add(new ToolStripSeparator());
            var showAll = new ToolStripMenuItem("Show all hidden");
            showAll.Enabled = hidden.Count > 0;
            showAll.Click += delegate
            {
                foreach (var w in hidden.ToArray()) ShowItem(w, false);
                AfterChange();
            };
            trayMenu.Items.Add(showAll);

            var exit = new ToolStripMenuItem("Exit TrayCorral");
            exit.Click += delegate { ExitApp(); };
            trayMenu.Items.Add(exit);
        }

        void UpdateTrayText()
        {
            tray.Text = hidden.Count == 0 ? "TrayCorral" : "TrayCorral - " + hidden.Count + " hidden";
        }

        void ShowPanel()
        {
            PruneHidden();
            RefreshAll(true);
            Show();
            if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
            Activate();
            BringToFront();
        }

        // ================================================================ the saved list
        static string DisplayName(string entry)
        {
            return Path.GetFileNameWithoutExtension(entry);
        }

        static bool HasPath(string entry)
        {
            return entry.IndexOf('\\') >= 0;
        }

        static string EntryFor(WinItem w)
        {
            return !string.IsNullOrEmpty(w.ExePath) ? w.ExePath : w.ProcessName + ".exe";
        }

        // Does this window belong to this list entry?
        static bool Matches(string entry, WinItem w)
        {
            if (!string.IsNullOrEmpty(w.ExePath) && string.Equals(entry, w.ExePath, StringComparison.OrdinalIgnoreCase)) return true;
            if ((!HasPath(entry) || string.IsNullOrEmpty(w.ExePath)) &&
                string.Equals(DisplayName(entry), w.ProcessName, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        string FindEntry(WinItem w)
        {
            foreach (var e in programs) if (Matches(e, w)) return e;
            return null;
        }

        string AddProgram(string entry)
        {
            foreach (var e in programs)
                if (string.Equals(e, entry, StringComparison.OrdinalIgnoreCase)) return e;
            programs.Add(entry);
            SortPrograms();
            SavePrograms();
            return entry;
        }

        void SortPrograms()
        {
            programs.Sort((a, b) => string.Compare(DisplayName(a), DisplayName(b), StringComparison.OrdinalIgnoreCase));
        }

        void LoadPrograms()
        {
            programs.Clear();
            string[] saved = null;
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(SettingsKey))
                    if (k != null) saved = k.GetValue("Programs") as string[];
            }
            catch { }

            bool migrated = false;
            if (saved == null)
            {
                // Bring over the list from the previous version, if there was one.
                try { if (File.Exists(legacyListFile)) { saved = File.ReadAllLines(legacyListFile, Encoding.UTF8); migrated = true; } }
                catch { }
            }
            if (saved != null)
                foreach (var line in saved)
                {
                    string e = (line ?? "").Trim();
                    if (e.Length > 0 && !programs.Exists(x => string.Equals(x, e, StringComparison.OrdinalIgnoreCase))) programs.Add(e);
                }
            SortPrograms();
            if (migrated) SavePrograms();
        }

        void SavePrograms()
        {
            try
            {
                using (var k = Registry.CurrentUser.CreateSubKey(SettingsKey))
                    k.SetValue("Programs", programs.ToArray(), RegistryValueKind.MultiString);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Couldn't save your program list:\n" + ex.Message, "TrayCorral");
            }
        }

        // ================================================================ window discovery
        bool IsCandidate(IntPtr h)
        {
            if (h == IntPtr.Zero || !Native.IsWindowVisible(h)) return false;
            if (Native.GetWindowTextLength(h) == 0) return false;
            if (Native.GetWindow(h, Native.GW_OWNER) != IntPtr.Zero) return false;
            if ((Native.GetWindowLong(h, Native.GWL_EXSTYLE) & Native.WS_EX_TOOLWINDOW) != 0) return false;
            int cloaked;
            try
            {
                if (Native.DwmGetWindowAttribute(h, Native.DWMWA_CLOAKED, out cloaked, 4) == 0 && cloaked != 0) return false;
            }
            catch { }
            string cls = Native.GetClass(h);
            if (cls == "Progman" || cls == "WorkerW" || cls == "Shell_TrayWnd" || cls == "Shell_SecondaryTrayWnd") return false;
            if (Native.GetPid(h) == ownPid) return false;
            return true;
        }

        List<WinItem> EnumOpen()
        {
            var list = new List<WinItem>();
            Native.EnumWindows((h, l) =>
            {
                if (IsCandidate(h)) list.Add(WinItem.From(h));
                return true;
            }, IntPtr.Zero);
            list.Sort((a, b) =>
            {
                int c = string.Compare(a.ProcessName, b.ProcessName, StringComparison.OrdinalIgnoreCase);
                return c != 0 ? c : string.Compare(a.Title, b.Title, StringComparison.OrdinalIgnoreCase);
            });
            return list;
        }

        string IconKeyForPath(string path)
        {
            if (string.IsNullOrEmpty(path) || !HasPath(path)) return "_default";
            string key = path.ToLowerInvariant();
            if (!images.Images.ContainsKey(key))
            {
                try
                {
                    using (var ic = Icon.ExtractAssociatedIcon(path))
                        images.Images.Add(key, ic.ToBitmap());
                }
                catch { return "_default"; }
            }
            return key;
        }

        string IconKeyForEntry(string entry) { return IconKeyForPath(entry); }
        string IconKeyFor(WinItem w) { return IconKeyForPath(w.ExePath); }

        // ================================================================ the periodic search
        void OnWinEvent(IntPtr hook, uint evt, IntPtr hwnd, int idObject, int idChild, uint thread, uint time)
        {
            if (idObject != 0) return; // only whole windows
            minimizeKick.Stop();       // let the minimize finish, then search
            minimizeKick.Start();
        }

        // Finds minimized windows of programs on the list and hides them.
        public void Scan()
        {
            bool changed = PruneHidden();
            if (programs.Count > 0)
            {
                var minimized = new List<IntPtr>();
                Native.EnumWindows((h, l) =>
                {
                    if (Native.IsIconic(h) && IsCandidate(h)) minimized.Add(h);
                    return true;
                }, IntPtr.Zero);

                foreach (var h in minimized)
                {
                    if (!Native.IsWindow(h) || !Native.IsWindowVisible(h) || !Native.IsIconic(h)) continue;
                    var w = WinItem.From(h);
                    if (FindEntry(w) == null) continue;
                    if (HideItem(w))
                    {
                        changed = true;
                        if (!shownAutoTip)
                        {
                            shownAutoTip = true;
                            tray.ShowBalloonTip(3500, "TrayCorral",
                                Shorten(w.Title, 50) + " was minimized, so it's been tucked away here. Click the tray icon to bring it back.",
                                ToolTipIcon.None);
                        }
                    }
                }
            }
            if (changed) AfterChange();
        }

        // Drops hidden entries whose window is gone, or that the program brought back by itself.
        bool PruneHidden()
        {
            int removed = 0;
            foreach (var w in hidden.ToArray())
            {
                bool gone = !Native.IsWindow(w.Handle);
                if (gone || Native.IsWindowVisible(w.Handle))
                {
                    if (!gone) ShowCompanions(w); // it came back on its own: bring its other windows back too
                    hidden.Remove(w);
                    removed++;
                }
            }
            if (removed > 0) SaveHidden();
            return removed > 0;
        }

        // ================================================================ panel refresh
        void AfterChange()
        {
            if (Visible) RefreshAll(true);
            else UpdateTrayText();
        }

        void RefreshAll(bool force)
        {
            var open = EnumOpen();

            var sig = new StringBuilder();
            foreach (var w in open) sig.Append(w.Handle.ToInt64()).Append('|').Append(w.Title).Append('\n');
            string s = sig.ToString();
            if (force || s != lastOpenSig)
            {
                lastOpenSig = s;
                FillOpen(open);
            }
            FillPrograms(open, force);
            UpdateTrayText();
        }

        void FillOpen(List<WinItem> items)
        {
            var selected = new HashSet<long>();
            foreach (ListViewItem it in lvOpen.SelectedItems) selected.Add(((WinItem)it.Tag).Handle.ToInt64());
            int top = lvOpen.TopItem != null ? lvOpen.TopItem.Index : 0;

            lvOpen.BeginUpdate();
            lvOpen.Items.Clear();
            foreach (var w in items)
            {
                var it = new ListViewItem(new string[] { w.Title, w.ProcessName });
                it.Tag = w;
                it.ImageKey = IconKeyFor(w);
                if (FindEntry(w) != null) it.ForeColor = SystemColors.GrayText; // already on the list
                if (selected.Contains(w.Handle.ToInt64())) it.Selected = true;
                lvOpen.Items.Add(it);
            }
            lvOpen.EndUpdate();
            if (lvOpen.Items.Count > 0)
            {
                try { lvOpen.TopItem = lvOpen.Items[Math.Min(top, lvOpen.Items.Count - 1)]; } catch { }
            }
            grpOpen.Text = "Open windows (" + items.Count + ")";
        }

        string StatusFor(string entry, List<WinItem> open)
        {
            int h = 0, showing = 0, mins = 0;
            foreach (var w in hidden) if (Matches(entry, w)) h++;
            foreach (var w in open)
                if (Matches(entry, w)) { if (Native.IsIconic(w.Handle)) mins++; else showing++; }
            if (h > 0 && showing + mins == 0) return h == 1 ? "Hidden" : "Hidden (" + h + " windows)";
            if (h > 0) return "Hidden " + h + ", showing " + (showing + mins);
            if (mins > 0) return "Minimized (hiding…)";
            if (showing > 0) return showing == 1 ? "Showing" : "Showing (" + showing + " windows)";
            return "Not open";
        }

        void FillPrograms(List<WinItem> open, bool force)
        {
            var statuses = new List<string>();
            var sig = new StringBuilder();
            foreach (var e in programs)
            {
                string st = StatusFor(e, open);
                statuses.Add(st);
                sig.Append(e).Append('|').Append(st).Append('\n');
            }
            string s = sig.ToString();
            if (!force && s == lastProgSig) return;
            lastProgSig = s;

            var selected = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (ListViewItem it in lvProgs.SelectedItems) selected.Add((string)it.Tag);

            lvProgs.BeginUpdate();
            lvProgs.Items.Clear();
            for (int i = 0; i < programs.Count; i++)
            {
                string e = programs[i];
                var it = new ListViewItem(new string[] { DisplayName(e), statuses[i], HasPath(e) ? e : "(location unknown)" });
                it.Tag = e;
                it.ImageKey = IconKeyForEntry(e);
                if (statuses[i] == "Not open") it.ForeColor = SystemColors.GrayText;
                if (selected.Contains(e)) it.Selected = true;
                lvProgs.Items.Add(it);
            }
            lvProgs.EndUpdate();
            grpProgs.Text = "My programs (" + programs.Count + ")  —  hidden whenever they're minimized";
        }

        // ================================================================ hiding / showing windows
        bool IsHiddenCompanion(IntPtr h)
        {
            foreach (var w in hidden) if (w.Companions.Contains(h)) return true;
            return false;
        }

        static bool IsIgnorableHelperWindow(IntPtr h)
        {
            string cls = Native.GetClass(h);
            return cls == "tooltips_class32" || cls == "IME" || cls == "MSCTFIME UI" || cls.StartsWith("SysShadow");
        }

        // The program's other visible top-level windows that should disappear along with the main one.
        List<IntPtr> FindCompanions(IntPtr main, uint pid)
        {
            bool whole = chkWhole != null && chkWhole.Checked;
            var list = new List<IntPtr>();
            Native.EnumWindows((h, l) =>
            {
                if (h == main || !Native.IsWindowVisible(h) || Native.GetPid(h) != pid) return true;
                if (IsIgnorableHelperWindow(h)) return true;
                // Attached windows (no taskbar button of their own) always go along.
                // Separate full windows of the same program only go along if that checkbox is on.
                if (whole || !IsCandidate(h)) list.Add(h);
                return true;
            }, IntPtr.Zero);
            return list;
        }

        void ShowCompanions(WinItem w)
        {
            foreach (var c in w.Companions)
                if (Native.IsWindow(c) && !Native.IsWindowVisible(c)) Native.ShowWindow(c, Native.SW_SHOWNA);
            w.Companions.Clear();
        }

        bool HideItem(WinItem w)
        {
            if (!Native.IsWindow(w.Handle)) return true;
            if (hidden.Exists(x => x.Handle == w.Handle) || IsHiddenCompanion(w.Handle)) return true; // already hidden
            w.Companions = FindCompanions(w.Handle, w.Pid);
            Native.ShowWindow(w.Handle, Native.SW_HIDE);
            if (Native.IsWindowVisible(w.Handle)) { w.Companions.Clear(); return false; }
            foreach (var c in w.Companions) Native.ShowWindow(c, Native.SW_HIDE);
            w.Companions.RemoveAll(c => !Native.IsWindow(c) || Native.IsWindowVisible(c));
            hidden.Add(w);
            SaveHidden();
            return true;
        }

        void ShowItem(WinItem w, bool bringToFront)
        {
            hidden.RemoveAll(x => x.Handle == w.Handle);
            if (Native.IsWindow(w.Handle))
            {
                Native.ShowWindow(w.Handle, Native.SW_SHOW);
                if (Native.IsIconic(w.Handle)) Native.ShowWindow(w.Handle, Native.SW_RESTORE);
                ShowCompanions(w);
                if (bringToFront) Native.SetForegroundWindow(w.Handle);
            }
            else ShowCompanions(w);
            SaveHidden();
        }

        // ================================================================ actions
        List<string> SelectedEntries()
        {
            var list = new List<string>();
            foreach (ListViewItem it in lvProgs.SelectedItems) list.Add((string)it.Tag);
            if (list.Count == 0) Hint("Pick one or more programs in \"My programs\" first.");
            return list;
        }

        void AddSelectedAndHide()
        {
            var sel = new List<WinItem>();
            foreach (ListViewItem it in lvOpen.SelectedItems) sel.Add((WinItem)it.Tag);
            if (sel.Count == 0) { Hint("Pick one or more windows in \"Open windows\" first."); return; }

            var failed = new List<string>();
            foreach (var w in sel)
            {
                if (FindEntry(w) == null) AddProgram(EntryFor(w));
                if (!HideItem(w)) failed.Add(w.Title);
            }
            AfterChange();
            if (failed.Count > 0) ShowHideFailed(failed);
        }

        void ShowHideFailed(List<string> failed)
        {
            MessageBox.Show(Visible ? this : null, "These were added to your list, but couldn't be hidden:\n\n" + string.Join("\n", failed.ToArray()) +
                "\n\nThis usually means the program is running as administrator. Run TrayCorral as administrator to hide it.",
                "TrayCorral", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        void ShowPrograms(List<string> entries, bool bringToFront)
        {
            if (entries.Count == 0) return;
            int shown = 0;
            foreach (var e in entries)
                foreach (var w in hidden.ToArray())
                    if (Matches(e, w)) { ShowItem(w, bringToFront); shown++; }
            AfterChange();
            if (shown == 0) Hint("Nothing to show: none of those programs are hidden right now.");
        }

        void HidePrograms(List<string> entries, bool tellIfNothing)
        {
            if (entries.Count == 0) return;
            int found = 0;
            var failed = new List<string>();
            var open = EnumOpen();
            foreach (var e in entries)
                foreach (var w in open)
                    if (Matches(e, w)) { found++; if (!HideItem(w)) failed.Add(w.Title); }
            AfterChange();
            if (failed.Count > 0) ShowHideFailed(failed);
            else if (found == 0 && tellIfNothing) Hint("Nothing to hide: those programs aren't showing any windows right now.");
        }

        void ToggleSelected()
        {
            var sel = SelectedEntries();
            if (sel.Count == 0) return;
            bool anyHidden = false;
            foreach (var e in sel) if (hidden.Exists(w => Matches(e, w))) anyHidden = true;
            if (anyHidden) ShowPrograms(sel, true); else HidePrograms(sel, true);
        }

        void RemoveSelected()
        {
            RemovePrograms(SelectedEntries());
        }

        void RemovePrograms(List<string> entries)
        {
            if (entries.Count == 0) return;
            foreach (var e in entries)
            {
                foreach (var w in hidden.ToArray())
                    if (Matches(e, w)) ShowItem(w, false); // don't leave anything stuck invisible
                programs.RemoveAll(x => string.Equals(x, e, StringComparison.OrdinalIgnoreCase));
            }
            SavePrograms();
            AfterChange();
        }

        void AddProgramBrowse()
        {
            using (var dlg = new OpenFileDialog())
            {
                dlg.Title = "Choose a program to add to your list";
                dlg.Filter = "Programs (*.exe)|*.exe";
                dlg.Multiselect = true;
                if (dlg.ShowDialog(this) != DialogResult.OK) return;
                foreach (var f in dlg.FileNames) AddProgram(f);
            }
            Scan();
            AfterChange();
        }

        void ClosePrograms(List<string> entries, bool force)
        {
            foreach (var e in entries) CloseProgram(e, force);
        }

        void CloseProgram(string entry, bool force)
        {
            var open = EnumOpen().FindAll(w => Matches(entry, w));
            var hid = hidden.FindAll(w => Matches(entry, w));
            if (open.Count + hid.Count == 0) { Hint(DisplayName(entry) + " isn't open."); return; }

            if (force)
            {
                var r = MessageBox.Show(Visible ? this : null,
                    "Force quit " + DisplayName(entry) + "?\n\n" +
                    "This ends the program immediately. Unsaved work will be lost.",
                    "TrayCorral", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                if (r != DialogResult.Yes) return;

                var pids = new HashSet<uint>();
                foreach (var w in open) pids.Add(w.Pid);
                foreach (var w in hid) pids.Add(w.Pid);
                var errors = new List<string>();
                foreach (var pid in pids)
                {
                    try
                    {
                        var p = Process.GetProcessById((int)pid);
                        p.Kill();
                        p.WaitForExit(3000);
                    }
                    catch (Exception ex) { errors.Add(ex.Message); }
                }
                hidden.RemoveAll(w => pids.Contains(w.Pid) && !Native.IsWindow(w.Handle));
                SaveHidden();
                AfterChange();
                if (errors.Count > 0)
                    MessageBox.Show("Couldn't force quit " + DisplayName(entry) + ":\n" + string.Join("\n", errors.ToArray()) +
                        "\n\nIf it's running as administrator, TrayCorral needs to be too.", "TrayCorral",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Polite close: ask each window to close the same way the X button does.
            foreach (var w in hid) Native.PostMessage(w.Handle, Native.WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
            foreach (var w in open) Native.PostMessage(w.Handle, Native.WM_CLOSE, IntPtr.Zero, IntPtr.Zero);

            var t = new Timer();
            t.Interval = 1500;
            t.Tick += delegate
            {
                t.Stop();
                t.Dispose();
                // Anything still hidden didn't close: it may be asking "Save changes?" or it only hides when closed.
                // Show it so nothing gets stuck invisibly.
                var stuck = hidden.FindAll(x => Native.IsWindow(x.Handle) && hid.Exists(y => y.Handle == x.Handle));
                foreach (var x in stuck) ShowItem(x, true);
                if (stuck.Count > 0)
                    tray.ShowBalloonTip(6000, "TrayCorral",
                        DisplayName(entry) + " didn't close on its own, so it's been shown. " +
                        "It may be asking you something, or it only hides when closed (use Force quit for those).",
                        ToolTipIcon.Info);
                PruneHidden();
                AfterChange();
            };
            t.Start();
        }

        void HideForegroundWindow()
        {
            IntPtr h = Native.GetForegroundWindow();
            IntPtr root = Native.GetAncestor(h, Native.GA_ROOTOWNER);
            if (root != IntPtr.Zero) h = root;
            if (!IsCandidate(h)) { System.Media.SystemSounds.Beep.Play(); return; }
            var w = WinItem.From(h);
            bool isNew = FindEntry(w) == null;
            if (isNew) AddProgram(EntryFor(w));
            if (HideItem(w))
            {
                AfterChange();
                tray.ShowBalloonTip(2500, "Hidden", Shorten(w.Title, 60) +
                    (isNew ? "\n" + w.ProcessName + " was added to your list." : "") +
                    "\nClick the TrayCorral icon to get it back.", ToolTipIcon.None);
            }
            else
            {
                AfterChange();
                System.Media.SystemSounds.Beep.Play();
            }
        }

        void Hint(string msg)
        {
            MessageBox.Show(Visible ? this : null, msg, "TrayCorral", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // ================================================================ hidden-window recovery
        // So hidden windows can be found again if TrayCorral is closed or crashes.
        void SaveHidden()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(dataFile));
                var lines = new List<string>();
                foreach (var w in hidden)
                {
                    var comp = new List<string>();
                    foreach (var c in w.Companions) comp.Add(c.ToInt64().ToString());
                    lines.Add(w.Handle.ToInt64() + "\t" + w.Pid + "\t" +
                        (w.Title ?? "").Replace("\t", " ").Replace("\r", " ").Replace("\n", " ") + "\t" +
                        string.Join(",", comp.ToArray()));
                }
                File.WriteAllLines(dataFile, lines.ToArray(), Encoding.UTF8);
            }
            catch { }
        }

        public void LoadHiddenFromLastTime()
        {
            int recovered = 0;
            try
            {
                if (File.Exists(dataFile))
                    foreach (var line in File.ReadAllLines(dataFile, Encoding.UTF8))
                    {
                        var parts = line.Split('\t');
                        if (parts.Length < 2) continue;
                        long hv; uint pid;
                        if (!long.TryParse(parts[0], out hv) || !uint.TryParse(parts[1], out pid)) continue;
                        var h = new IntPtr(hv);
                        // Make sure it's still the same program's window and it's still hidden.
                        if (!Native.IsWindow(h) || Native.IsWindowVisible(h) || Native.GetPid(h) != pid) continue;
                        var w = WinItem.From(h);
                        if (parts.Length >= 4)
                            foreach (var cs in parts[3].Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                            {
                                long cv;
                                if (!long.TryParse(cs, out cv)) continue;
                                var ch = new IntPtr(cv);
                                if (Native.IsWindow(ch) && !Native.IsWindowVisible(ch) && Native.GetPid(ch) == pid) w.Companions.Add(ch);
                            }
                        if (FindEntry(w) == null) AddProgram(EntryFor(w)); // keep it manageable from the list
                        hidden.Add(w);
                        recovered++;
                    }
            }
            catch { }
            SaveHidden();
            UpdateTrayText();
            if (recovered > 0)
                tray.ShowBalloonTip(4000, "TrayCorral",
                    "Found " + recovered + " program window(s) still hidden from last time. Click the tray icon to manage them.", ToolTipIcon.Info);
        }

        // ================================================================ settings
        static int GetSettingInt(string name, int def)
        {
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(SettingsKey))
                {
                    if (k == null) return def;
                    object v = k.GetValue(name);
                    return v == null ? def : Convert.ToInt32(v);
                }
            }
            catch { return def; }
        }

        static void SetSettingInt(string name, int value)
        {
            try
            {
                using (var k = Registry.CurrentUser.CreateSubKey(SettingsKey))
                    k.SetValue(name, value, RegistryValueKind.DWord);
            }
            catch { }
        }

        static bool GetStartup()
        {
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(RunKey))
                    return k != null && k.GetValue("TrayCorral") != null;
            }
            catch { return false; }
        }

        static void SetStartup(bool on)
        {
            try
            {
                using (var k = Registry.CurrentUser.CreateSubKey(RunKey))
                {
                    if (on) k.SetValue("TrayCorral", "\"" + Application.ExecutablePath + "\"");
                    else k.DeleteValue("TrayCorral", false);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Couldn't change the startup setting:\n" + ex.Message, "TrayCorral");
            }
        }

        // ================================================================ exit
        void ExitApp()
        {
            PruneHidden();
            if (hidden.Count > 0)
            {
                var r = MessageBox.Show(
                    hidden.Count + " window(s) are still hidden.\n\n" +
                    "Yes: show them all, then exit.\n" +
                    "No: exit and leave them hidden (TrayCorral will find them again next time it starts).\n" +
                    "Cancel: don't exit.",
                    "Exit TrayCorral", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (r == DialogResult.Cancel) return;
                if (r == DialogResult.Yes) foreach (var w in hidden.ToArray()) ShowItem(w, false);
            }
            SaveHidden();
            exiting = true;
            tray.Visible = false;
            Application.Exit();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (!exiting && e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide(); // closing the panel just tucks it back into the tray
                return;
            }
            SaveHidden();
            tray.Visible = false;
            base.OnFormClosing(e);
        }

        // ================================================================ hotkey (Ctrl+Alt+H)
        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            hotkeyOk = Native.RegisterHotKey(Handle, HOTKEY_ID, Native.MOD_CONTROL | Native.MOD_ALT | Native.MOD_NOREPEAT, (uint)Keys.H);
            if (!hotkeyOk) // older Windows doesn't know MOD_NOREPEAT
                hotkeyOk = Native.RegisterHotKey(Handle, HOTKEY_ID, Native.MOD_CONTROL | Native.MOD_ALT, (uint)Keys.H);
            if (!hotkeyOk && lblTip != null)
                lblTip.Text = "Every program on your list is hidden here whenever it's minimized. (Ctrl+Alt+H is taken by another program, so that shortcut is off.)";
        }

        protected override void OnHandleDestroyed(EventArgs e)
        {
            if (hotkeyOk) Native.UnregisterHotKey(Handle, HOTKEY_ID);
            base.OnHandleDestroyed(e);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == Native.WM_HOTKEY && m.WParam.ToInt32() == HOTKEY_ID) HideForegroundWindow();
            base.WndProc(ref m);
        }

        // ================================================================ helpers
        static string Shorten(string s, int max)
        {
            if (string.IsNullOrEmpty(s)) return "(untitled)";
            return s.Length <= max ? s : s.Substring(0, max - 1) + "…";
        }

        static Icon MakeAppIcon()
        {
            var bmp = new Bitmap(32, 32);
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);
                using (var path = new GraphicsPath())
                {
                    var r = new Rectangle(1, 1, 29, 29);
                    int d = 12;
                    path.AddArc(r.X, r.Y, d, d, 180, 90);
                    path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
                    path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
                    path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
                    path.CloseFigure();
                    using (var b = new SolidBrush(Color.FromArgb(255, 34, 104, 170))) g.FillPath(b, path);
                }
                // a little fence (the "corral")
                using (var rail = new Pen(Color.White, 3f))
                {
                    g.DrawLine(rail, 6, 12, 26, 12);
                    g.DrawLine(rail, 6, 20, 26, 20);
                }
                using (var post = new Pen(Color.White, 3.5f))
                {
                    g.DrawLine(post, 8, 7, 8, 25);
                    g.DrawLine(post, 16, 7, 16, 25);
                    g.DrawLine(post, 24, 7, 24, 25);
                }
            }
            return Icon.FromHandle(bmp.GetHicon());
        }
    }
}
