@echo off
REM Builds TrayCorral.exe using the C# compiler that comes with Windows (.NET Framework 4).
cd /d "%~dp0"

set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
REM 32-bit Windows only has this one; the program it builds still runs on both 32- and 64-bit.
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
  echo Could not find the .NET Framework 4 C# compiler on this PC.
  echo Turn on ".NET Framework 4.8 Advanced Services" in "Turn Windows features on or off" and try again.
  pause
  exit /b 1
)

"%CSC%" /nologo /target:winexe /platform:anycpu /optimize+ /out:TrayCorral.exe /r:System.Windows.Forms.dll /r:System.Drawing.dll TrayCorral.cs
if errorlevel 1 (
  echo.
  echo Build failed - see the messages above.
  pause
  exit /b 1
)

echo.
echo Built TrayCorral.exe - starting it now. Look for the blue fence icon in your system tray.
start "" "%~dp0TrayCorral.exe"
timeout /t 4 >nul
