TrayCorral
==========
Keep a list of programs. Whenever one of them is minimized, TrayCorral hides it
completely and keeps it in one control panel in the system tray, where you can
show it again or close it.

SETUP (one time)
1. Right-click the zip > "Extract All..." (don't run it from inside the zip).
2. Double-click Build-TrayCorral.bat. It builds TrayCorral.exe with the compiler
   that already comes with Windows, then starts it.
   (If Windows shows a "protected your PC" box, click "More info" > "Run anyway".)
3. Look for the blue fence icon in the tray (click the ^ by the clock if hidden).
   You can drag it out onto the taskbar so it's always visible.

THE CONTROL PANEL (left-click the tray icon)
- Left side, "Open windows": select a program and click "Add to list and hide"
  (or double-click it). It's added to your list and hidden right away.
- Right side, "My programs": your saved list, with each program's status.
    Show            - bring a hidden program back
    Hide now        - hide it without waiting for it to be minimized
    Close program   - close it politely, like clicking its X
    Force quit      - end it immediately (asks first)
    Add program...  - add a program by picking its .exe, even if it isn't running
    Remove from list- stop managing it (anything hidden is shown again first)
- Every program on the list is hidden whenever it's minimized. TrayCorral checks
  every few seconds (you can change how often at the bottom of the panel) and
  also reacts the moment something is minimized.
- The list is saved in TrayCorral's settings and kept between restarts.

TRAY MENU (right-click the tray icon)
- Every program on your list, with its status and Show / Hide now / Close /
  Force quit / Remove from list.
- "Show all hidden" and "Exit TrayCorral".

OTHER
- Ctrl+Alt+H: adds the window you're in to the list and hides it.
- Closing the control panel just tucks it back into the tray.
- Tick "Start TrayCorral when Windows starts" to have it load at login.
- Programs made of several windows (like WACUP/Winamp: player, playlist,
  equalizer, library) are hidden and shown back as one. If a program still
  leaves a window behind, tick "Hide every window of a program together".

GOOD TO KNOW
- Works on both 32-bit and 64-bit Windows (Windows 7 or newer recommended).
  The same TrayCorral.exe runs on either.
- If "Close program" doesn't actually close it (it's asking "Save changes?",
  or it only hides when closed), TrayCorral shows it again so nothing gets
  stuck invisible.
- If you exit TrayCorral with programs still hidden, it asks whether to show
  them. Even if it crashes, starting it again finds them.
- Programs running as administrator can only be hidden if TrayCorral is also
  run as administrator (right-click TrayCorral.exe > Run as administrator).
