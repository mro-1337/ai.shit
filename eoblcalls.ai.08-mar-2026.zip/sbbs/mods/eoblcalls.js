// ============================================================
//  L A S T C A L L E R S . J S   v4.0
//  Synchronet BBS - Last Callers Board
// ============================================================
//
//  USAGE:
//    ?lastcallers.js            - display last callers
//    ?lastcallers.js write      - record caller + display
//    ?lastcallers.js settings   - sysop config menu (level 99+)
//
//  FILES  (in sbbs/lcalls/)
//    lcallhd.msg        - generated header  (display fallback)
//    lcallmid.msg       - generated middle  (always used)
//    lcallbot.msg       - generated footer  (display fallback)
//    lcallhd.ans        - custom header override (optional)
//    lcallbot.ans       - custom footer override (optional)
//    lastcallers.json   - caller data store
//    lcallsettings.json - sysop settings (written by menu)
//
// ============================================================

"use strict";

// ============================================================
//  PATHS
// ============================================================
var LCALLS_DIR   = system.exec_dir + "../lcalls/";
var DATA_FILE    = LCALLS_DIR + "lastcallers.json";
var SETTINGS_FILE= LCALLS_DIR + "lcallsettings.json";
var HDR_MSG      = LCALLS_DIR + "lcallhd.msg";
var MID_MSG      = LCALLS_DIR + "lcallmid.msg";
var BOT_MSG      = LCALLS_DIR + "lcallbot.msg";
var HDR_ANS      = LCALLS_DIR + "lcallhd.ans";
var BOT_ANS      = LCALLS_DIR + "lcallbot.ans";

// ============================================================
//  DEFAULTS  (overridden by lcallsettings.json if it exists)
// ============================================================
var CFG = {
    maxCallers:  20,
    doPause:     true,
    dateFormat:  0,
    borderStyle: 0
};

var CLR = {
    reset:       "\x01n",
    title:       "\x01n\x01h\x01w",
    colHdr:      "\x01n\x01h\x01r",
    border:      "\x01n\x01r",
    node:        "\x01n\x01h\x01r",
    time:        "\x01n\x01h\x01w",
    name:        "\x01n\x01h\x01w",
    location:    "\x01n\x01h\x01w",
    level:       "\x01n\x01h\x01y",
    age:         "\x01n\x01h\x01w",
    logons:      "\x01n\x01h\x01w",
    ltoday:      "\x01n\x01h\x01w",
    ttoday:      "\x01n\x01h\x01w",
    tlast:       "\x01n\x01h\x01w",
    uploads:     "\x01n\x01h\x01g",
    downloads:   "\x01n\x01h\x01c",
    ulb:         "\x01n\x01h\x01g",
    dlb:         "\x01n\x01h\x01c",
    posts:       "\x01n\x01h\x01w",
    emails:      "\x01n\x01h\x01w",
    gender:      "\x01n\x01h\x01w",
    laston:      "\x01n\x01h\x01w",
    birthdate:   "\x01n\x01h\x01w",
    connection:  "\x01n\x01h\x01w",
    note:        "\x01n\x01h\x01y",
    comment:     "\x01n\x01h\x01y",
    botLabel:    "\x01n\x01r",
    botName:     "\x01n\x01h\x01w",
    botNumber:   "\x01n\x01h\x01w"
};

// ============================================================
//  COLUMNS
//  on:true/false toggles display.  free:true = raw value,
//  no padding, ANSI CHA used to anchor closing border.
// ============================================================
var COLS = [
    { key:"node",       on:true,  label:"#",         w:2,  clrKey:"node",      free:false, get:function(e){ return e.node; } },
    { key:"time",       on:true,  label:"Time",       w:5,  clrKey:"time",      free:false, get:function(e){ return e.time; } },
    { key:"name",       on:true,  label:"Name",       w:18, clrKey:"name",      free:false, get:function(e){ return e.name; } },
    { key:"location",   on:true,  label:"Location",   w:22, clrKey:"location",  free:false, get:function(e){ return e.location; } },
    { key:"level",      on:false, label:"Level",      w:5,  clrKey:"level",     free:false, get:function(e){ return e.level; } },
    { key:"age",        on:false, label:"Age",        w:3,  clrKey:"age",       free:false, get:function(e){ return e.age; } },
    { key:"logons",     on:false, label:"Calls",      w:6,  clrKey:"logons",    free:false, get:function(e){ return e.logons; } },
    { key:"ltoday",     on:false, label:"Today",      w:5,  clrKey:"ltoday",    free:false, get:function(e){ return e.ltoday; } },
    { key:"ttoday",     on:false, label:"Tmin",       w:5,  clrKey:"ttoday",    free:false, get:function(e){ return e.ttoday; } },
    { key:"tlast",      on:false, label:"Lmin",       w:5,  clrKey:"tlast",     free:false, get:function(e){ return e.tlast; } },
    { key:"uploads",    on:false, label:"Upls",       w:5,  clrKey:"uploads",   free:false, get:function(e){ return e.uploads; } },
    { key:"downloads",  on:false, label:"Dnls",       w:5,  clrKey:"downloads", free:false, get:function(e){ return e.downloads; } },
    { key:"ulb",        on:false, label:"Ulkb",       w:8,  clrKey:"ulb",       free:false, get:function(e){ return e.ulb; } },
    { key:"dlb",        on:false, label:"Dlkb",       w:8,  clrKey:"dlb",       free:false, get:function(e){ return e.dlb; } },
    { key:"posts",      on:false, label:"Posts",      w:5,  clrKey:"posts",     free:false, get:function(e){ return e.posts; } },
    { key:"emails",     on:false, label:"Email",      w:5,  clrKey:"emails",    free:false, get:function(e){ return e.emails; } },
    { key:"gender",     on:false, label:"g",          w:1,  clrKey:"gender",    free:false, get:function(e){ return e.gender; } },
    { key:"laston",     on:false, label:"Laston",     w:10, clrKey:"laston",    free:false, get:function(e){ return e.laston; } },
    { key:"birthdate",  on:false, label:"Birth",      w:10, clrKey:"birthdate", free:false, get:function(e){ return e.birthdate; } },
    { key:"connection", on:false, label:"Conn",       w:8,  clrKey:"connection",free:false, get:function(e){ return e.connection; } },
    { key:"comment",    on:true,  label:"Comment",    w:16, clrKey:"comment",   free:true,  get:function(e){ return e.comment; } }
];

// ============================================================
//  DEFAULT COLUMN METADATA  (used by Reset to Defaults)
// ============================================================
var DEFAULT_COLS_META = [
    {key:"node",       on:true,  label:"#",        w:2},
    {key:"time",       on:true,  label:"Time",      w:5},
    {key:"name",       on:true,  label:"Name",      w:18},
    {key:"location",   on:true,  label:"Location",  w:22},
    {key:"level",      on:false, label:"Level",     w:5},
    {key:"age",        on:false, label:"Age",       w:3},
    {key:"logons",     on:false, label:"Calls",     w:6},
    {key:"ltoday",     on:false, label:"Today",     w:5},
    {key:"ttoday",     on:false, label:"Tmin",      w:5},
    {key:"tlast",      on:false, label:"Lmin",      w:5},
    {key:"uploads",    on:false, label:"Upls",      w:5},
    {key:"downloads",  on:false, label:"Dnls",      w:5},
    {key:"ulb",        on:false, label:"Ulkb",      w:8},
    {key:"dlb",        on:false, label:"Dlkb",      w:8},
    {key:"posts",      on:false, label:"Posts",     w:5},
    {key:"emails",     on:false, label:"Email",     w:5},
    {key:"gender",     on:false, label:"G",         w:1},
    {key:"laston",     on:false, label:"Laston",    w:10},
    {key:"birthdate",  on:false, label:"Birth",     w:10},
    {key:"connection", on:false, label:"Conn",      w:8},
    {key:"comment",    on:true,  label:"Comment",   w:16}
];

function resetDefaults() {
    CFG.maxCallers  = 20;
    CFG.doPause     = true;
    CFG.dateFormat  = 0;
    CFG.borderStyle = 0;
    applyBorderSet(0);
    CLR.reset      = "\x01n";
    CLR.title      = "\x01n\x01h\x01w";
    CLR.colHdr     = "\x01n\x01h\x01r";
    CLR.border     = "\x01n\x01r";
    CLR.node       = "\x01n\x01h\x01r";
    CLR.time       = "\x01n\x01h\x01w";
    CLR.name       = "\x01n\x01h\x01w";
    CLR.location   = "\x01n\x01h\x01w";
    CLR.level      = "\x01n\x01h\x01y";
    CLR.age        = "\x01n\x01h\x01w";
    CLR.logons     = "\x01n\x01h\x01w";
    CLR.ltoday     = "\x01n\x01h\x01w";
    CLR.ttoday     = "\x01n\x01h\x01w";
    CLR.tlast      = "\x01n\x01h\x01w";
    CLR.uploads    = "\x01n\x01h\x01g";
    CLR.downloads  = "\x01n\x01h\x01c";
    CLR.ulb        = "\x01n\x01h\x01g";
    CLR.dlb        = "\x01n\x01h\x01c";
    CLR.posts      = "\x01n\x01h\x01w";
    CLR.emails     = "\x01n\x01h\x01w";
    CLR.gender     = "\x01n\x01h\x01w";
    CLR.laston     = "\x01n\x01h\x01w";
    CLR.birthdate  = "\x01n\x01h\x01w";
    CLR.connection = "\x01n\x01h\x01w";
    CLR.note       = "\x01n\x01h\x01y";
    CLR.comment    = "\x01n\x01h\x01y";
    CLR.botLabel   = "\x01n\x01r";
    CLR.botName    = "\x01n\x01h\x01w";
    CLR.botNumber  = "\x01n\x01h\x01w";
    // Reset COLS to default order, labels, widths, and on-state
    for (var ri = 0; ri < DEFAULT_COLS_META.length; ri++) {
        var dm = DEFAULT_COLS_META[ri];
        for (var ci = 0; ci < COLS.length; ci++) {
            if (COLS[ci].key === dm.key) {
                COLS[ci].on    = dm.on;
                COLS[ci].label = dm.label;
                COLS[ci].w     = dm.w;
                break;
            }
        }
    }
    var ord = [];
    for (var ri2 = 0; ri2 < DEFAULT_COLS_META.length; ri2++) {
        for (var ci2 = 0; ci2 < COLS.length; ci2++) {
            if (COLS[ci2].key === DEFAULT_COLS_META[ri2].key) { ord.push(COLS[ci2]); break; }
        }
    }
    COLS.length = 0;
    for (var ni = 0; ni < ord.length; ni++) COLS.push(ord[ni]);
}


// ============================================================
//  BORDER CHARACTER SETS
//  Each set: { label, H, V, TL, TR, BL, BR, LT, RT, TT, BT, CR }
// ============================================================
var BORDER_SETS = [
    { label:"Single line  (CP437)", H:"\xc4",V:"\xb3",TL:"\xda",TR:"\xbf",BL:"\xc0",BR:"\xd9",LT:"\xc3",RT:"\xb4",TT:"\xc2",BT:"\xc1",CR:"\xc5" },
    { label:"Double line  (CP437)", H:"\xcd",V:"\xba",TL:"\xc9",TR:"\xbb",BL:"\xc8",BR:"\xbc",LT:"\xcc",RT:"\xb9",TT:"\xcb",BT:"\xca",CR:"\xce" },
    { label:"Dbl horiz/Sgl vert",   H:"\xcd",V:"\xb3",TL:"\xd5",TR:"\xb8",BL:"\xd4",BR:"\xbe",LT:"\xc6",RT:"\xb5",TT:"\xd1",BT:"\xcf",CR:"\xd8" },
    { label:"Sgl horiz/Dbl vert",   H:"\xc4",V:"\xba",TL:"\xd6",TR:"\xb7",BL:"\xd3",BR:"\xbd",LT:"\xc7",RT:"\xb6",TT:"\xd2",BT:"\xd0",CR:"\xd7" },
    { label:"Block solid  (CP437)",  H:"\xdb",V:"\xdb",TL:"\xdb",TR:"\xdb",BL:"\xdb",BR:"\xdb",LT:"\xdb",RT:"\xdb",TT:"\xdb",BT:"\xdb",CR:"\xdb" },
    { label:"ASCII plain  (-|+)",   H:"-",   V:"|",  TL:"+",TR:"+",BL:"+",BR:"+",LT:"+",RT:"+",TT:"+",BT:"+",CR:"+" },
    { label:"ASCII hash   (=|#)",   H:"=",   V:"|",  TL:"#",TR:"#",BL:"#",BR:"#",LT:"+",RT:"+",TT:"+",BT:"+",CR:"+" },
    { label:"Dots/periods  (....)", H:".",   V:":",  TL:".",TR:".",BL:".",BR:".",LT:":",RT:":",TT:".",BT:".",CR:":" },
    { label:"Spaces (invisible)",   H:" ",   V:" ",  TL:" ",TR:" ",BL:" ",BR:" ",LT:" ",RT:" ",TT:" ",BT:" ",CR:" " }
];

function applyBorderSet(idx) {
    var bs = BORDER_SETS[(idx >= 0 && idx < BORDER_SETS.length) ? idx : 0];
    B.H=bs.H; B.V=bs.V; B.TL=bs.TL; B.TR=bs.TR; B.BL=bs.BL; B.BR=bs.BR;
    B.LT=bs.LT; B.RT=bs.RT; B.TT=bs.TT; B.BT=bs.BT; B.CR=bs.CR;
}

// ============================================================
//  CP437 BOX DRAWING
// ============================================================
var B = {
    H:"\xc4", V:"\xb3", TL:"\xda", TR:"\xbf", BL:"\xc0", BR:"\xd9",
    LT:"\xc3", RT:"\xb4", TT:"\xc2", BT:"\xc1", CR:"\xc5"
};

// ============================================================
//  UTILITIES
// ============================================================

// ============================================================
//  DATE FORMATTING
// ============================================================
// Each format is { label, example, fn(y4,y2,mo,dd,monAbbr) }
var DATE_FORMATS = [
    { label:"MM/DD/YY      ",  example:"03/07/26",
      fn: function(y4,y2,mo,dd,mn){ return mo+"/"+dd+"/"+y2; } },
    { label:"MM/DD/YYYY    ",  example:"03/07/2026",
      fn: function(y4,y2,mo,dd,mn){ return mo+"/"+dd+"/"+y4; } },
    { label:"DD/MM/YY      ",  example:"07/03/26",
      fn: function(y4,y2,mo,dd,mn){ return dd+"/"+mo+"/"+y2; } },
    { label:"DD/MM/YYYY    ",  example:"07/03/2026",
      fn: function(y4,y2,mo,dd,mn){ return dd+"/"+mo+"/"+y4; } },
    { label:"DD-Mon-YY     ",  example:"07-Mar-26",
      fn: function(y4,y2,mo,dd,mn){ return dd+"-"+mn+"-"+y2; } },
    { label:"DD-Mon-YYYY   ",  example:"07-Mar-2026",
      fn: function(y4,y2,mo,dd,mn){ return dd+"-"+mn+"-"+y4; } },
    { label:"YYYY-MM-DD    ",  example:"2026-03-07",
      fn: function(y4,y2,mo,dd,mn){ return y4+"-"+mo+"-"+dd; } },
    { label:"DD.MM.YYYY    ",  example:"07.03.2026",
      fn: function(y4,y2,mo,dd,mn){ return dd+"."+mo+"."+y4; } },
    { label:"Mon DD, YYYY  ",  example:"Mar 07, 2026",
      fn: function(y4,y2,mo,dd,mn){ return mn+" "+dd+", "+y4; } },
    { label:"DD Mon YYYY   ",  example:"07 Mar 2026",
      fn: function(y4,y2,mo,dd,mn){ return dd+" "+mn+" "+y4; } }
];

var MON_ABBR = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

function formatCallerDate(timet) {
    if (!timet) return "";
    var d   = new Date(timet * 1000);
    var y4  = String(d.getFullYear());
    var y2  = y4.substr(2);
    var mon = d.getMonth();                              // 0-based
    var day = d.getDate();
    var mo  = (mon+1 < 10 ? "0" : "") + (mon+1);
    var dd  = (day  < 10 ? "0" : "") + day;
    var mn  = MON_ABBR[mon] || "???";
    var idx = (CFG.dateFormat >= 0 && CFG.dateFormat < DATE_FORMATS.length)
              ? CFG.dateFormat : 0;
    return DATE_FORMATS[idx].fn(y4, y2, mo, dd, mn);
}

function rep(ch, n)      { if(n<=0)return""; var s=""; for(var i=0;i<n;i++)s+=ch; return s; }
function padRight(s, n)  { s=String(s==null?"":s); if(s.length>n)return s.substr(0,n); return s+rep(" ",n-s.length); }
function padLeft(s, n)   { s=String(s==null?"":s); if(s.length>n)return s.substr(0,n); return rep(" ",n-s.length)+s; }
function centerText(s,n) { s=String(s||""); if(s.length>=n)return s.substr(0,n); var p=n-s.length,l=Math.floor(p/2); return rep(" ",l)+s+rep(" ",p-l); }
function getTimeStr()    { var d=new Date(),h=d.getHours(),m=d.getMinutes(); return (h<10?"0":"")+h+":"+(m<10?"0":"")+m; }
function getActiveCols() { var a=[]; for(var i=0;i<COLS.length;i++) if(COLS[i].on) a.push(COLS[i]); return a; }
function calcTotalW(ac)  { var w=1; for(var i=0;i<ac.length;i++) w+=ac[i].w+3; return w; }

// ============================================================
//  SETTINGS  LOAD / SAVE / APPLY
// ============================================================
function loadSettings() {
    try {
        var f = new File(SETTINGS_FILE);
        if (!f.exists || !f.open("r")) return null;
        var raw = f.read(); f.close();
        return JSON.parse(raw);
    } catch(e) { return null; }
}

function saveSettings() {
    try {
        // Save full col state including order, on, and width
        var colArr = [];
        for (var i = 0; i < COLS.length; i++)
            colArr.push({ key: COLS[i].key, on: COLS[i].on, w: COLS[i].w, label: COLS[i].label });
        var clrState = {};
        var ck = Object.keys(CLR);
        for (var j = 0; j < ck.length; j++) clrState[ck[j]] = CLR[ck[j]];
        var out = { cfg: { maxCallers: CFG.maxCallers, doPause: CFG.doPause, dateFormat: CFG.dateFormat, borderStyle: CFG.borderStyle },
                    cols: colArr, clr: clrState };
        var f = new File(SETTINGS_FILE);
        if (!f.open("w")) return false;
        f.write(JSON.stringify(out, null, 2));
        f.close();
        return true;
    } catch(e) { return false; }
}

function applySettings(s) {
    if (!s) return;
    if (s.cfg) {
        if (typeof s.cfg.maxCallers === "number") CFG.maxCallers = s.cfg.maxCallers;
        if (typeof s.cfg.doPause   === "boolean") CFG.doPause    = s.cfg.doPause;
        if (typeof s.cfg.dateFormat  === "number") CFG.dateFormat  = s.cfg.dateFormat;
        if (typeof s.cfg.borderStyle === "number") { CFG.borderStyle = s.cfg.borderStyle; applyBorderSet(CFG.borderStyle); }
    }
    if (s.cols) {
        if (Array.isArray(s.cols)) {
            // New format: ordered array with key/on/w
            var newOrder = [];
            for (var i = 0; i < s.cols.length; i++) {
                var saved = s.cols[i];
                // Find matching COLS entry (carries the get fn and other props)
                for (var j = 0; j < COLS.length; j++) {
                    if (COLS[j].key === saved.key) {
                        if (typeof saved.on    === "boolean") COLS[j].on    = saved.on;
                        if (typeof saved.w     === "number")  COLS[j].w     = saved.w;
                        if (typeof saved.label === "string" && saved.label.length > 0) COLS[j].label = saved.label;
                        newOrder.push(COLS[j]);
                        break;
                    }
                }
            }
            // Append any cols not present in saved data (new cols added after save)
            for (var k = 0; k < COLS.length; k++) {
                var found = false;
                for (var m = 0; m < newOrder.length; m++)
                    if (newOrder[m].key === COLS[k].key) { found=true; break; }
                if (!found) newOrder.push(COLS[k]);
            }
            // Replace COLS contents in-place so references stay valid
            COLS.length = 0;
            for (var n = 0; n < newOrder.length; n++) COLS.push(newOrder[n]);
        } else {
            // Legacy format: object keyed by col name
            for (var i2 = 0; i2 < COLS.length; i2++) {
                if (typeof s.cols[COLS[i2].key] === "boolean") COLS[i2].on = s.cols[COLS[i2].key];
            }
        }
    }
    if (s.clr) {
        var ck = Object.keys(s.clr);
        for (var j2 = 0; j2 < ck.length; j2++) {
            if (CLR.hasOwnProperty(ck[j2])) CLR[ck[j2]] = s.clr[ck[j2]];
        }
    }
}

// ============================================================
//  BORDER / ROW BUILDERS
// ============================================================
// cc() — color code helper.
// Injects ANSI SGR 22 (normal intensity / bold-off) after every \x01n reset
// so that non-bright colors actually render dim on terminals (e.g. SyncTERM)
// that don't fully clear bold from \x1b[0m alone.
// If \x01h follows, it re-enables bright as expected.
function cc(code) {
    return code.replace(/\x01n/g, "\x01n\x1b[22m");
}
function makeTopBorder(ac) {
    var s=cc(CLR.border)+B.TL; for(var i=0;i<ac.length;i++){s+=rep(B.H,ac[i].w+2);s+=(i<ac.length-1)?B.TT:B.TR;} return s;
}
function makeMidDivider(ac) {
    var s=cc(CLR.border)+B.LT; for(var i=0;i<ac.length;i++){s+=rep(B.H,ac[i].w+2);s+=(i<ac.length-1)?B.CR:B.RT;} return s;
}
function makeBotBorder(ac) {
    var s=cc(CLR.border)+B.BL; for(var i=0;i<ac.length;i++){s+=rep(B.H,ac[i].w+2);s+=(i<ac.length-1)?B.BT:B.BR;} return s;
}
function makeHeaderRow(ac) {
    var s=cc(CLR.border)+B.V;
    for(var i=0;i<ac.length;i++){s+=" "+cc(CLR.colHdr)+padRight(ac[i].label,ac[i].w)+" "+cc(CLR.border)+B.V;}
    return s;
}
function makeDataRow(ac, entry, totalW) {
    var s=cc(CLR.border)+B.V;
    for(var i=0;i<ac.length;i++){
        var col=ac[i], val=String(col.get(entry)||"");
        if(col.free){
            s+=" "+cc(CLR[col.clrKey])+val+"\x1b["+totalW+"G"+cc(CLR.border)+B.V;
        } else {
            s+=" "+cc(CLR[col.clrKey])+padRight(val,col.w)+" "+cc(CLR.border)+B.V;
        }
    }
    return s;
}
function makeEmptyRow(ac, totalW) {
    // Blank row: outer V borders only, no column separators.
    var inner = totalW - 2;
    return cc(CLR.border) + B.V + rep(" ", inner > 0 ? inner : 0) + B.V;
}

// ============================================================
//  DATA
// ============================================================

// Safely convert any value to string - keeps 0 as "0",
// only returns "" for genuinely missing/null/undefined values.
// Defined at module scope so it is never affected by JS scoping quirks.
function ns(v) { return (v !== undefined && v !== null) ? String(v) : ""; }

function loadData() {
    try {
        var f=new File(DATA_FILE);
        if(!f.exists||!f.open("r")) return {callers:[]};
        var raw=f.read(); f.close();
        var p=JSON.parse(raw);
        if(!p||typeof p!=="object"||!Array.isArray(p.callers)) return {callers:[]};
        // Migrate old entries: fill any missing fields with "" so display is consistent
        var fields=["node","time","name","location","comment","note","level","age",
                    "logons","ltoday","ttoday","tlast","uploads","downloads",
                    "ulb","dlb","posts","emails","gender","laston","birthdate","connection"];
        for(var i=0;i<p.callers.length;i++){
            var e=p.callers[i];
            for(var j=0;j<fields.length;j++)
                if(e[fields[j]]===undefined||e[fields[j]]===null) e[fields[j]]="";
        }
        return p;
    } catch(e){ return {callers:[]}; }
}
function saveData(data) {
    try { var f=new File(DATA_FILE); if(!f.open("w"))return; f.write(JSON.stringify(data,null,2)); f.close(); } catch(e){}
}
function recordCaller(data) {
    if(!user||user.number<1) return;
    // ---- Correct Synchronet JS API property paths ----
    // Flat on user:     alias, name, location, age, gender, comment, note, number
    // user.security.*:  level
    // user.stats.*:     files_uploaded, files_downloaded, bytes_uploaded,
    //                   bytes_downloaded, messages_posted, email_sent,
    //                   total_logons, logons_today, time_on_today,
    //                   time_on_last, date_last_on
    // client.*:         protocol (connection type)
    var st  = (user.stats    || {});
    var sec = (user.security || {});
    var entry={
        node:       String(bbs.node_num),
        time:       getTimeStr(),
        name:       String(user.alias||user.name||"Unknown"),
        location:   ns(user.location),
        comment:    ns(user.comment),
        note:       ns(user.note),
        level:      ns(sec.level),
        age:        ns(user.age),
        logons:     ns(st.total_logons),
        ltoday:     ns(st.logons_today),
        ttoday:     ns(st.timeon_today),
        tlast:      ns(st.timeon_last_logon),
        uploads:    ns(st.files_uploaded),
        downloads:  ns(st.files_downloaded),
        ulb:        String(Math.round(((st.bytes_uploaded)||0)/1024)),
        dlb:        String(Math.round(((st.bytes_downloaded)||0)/1024)),
        posts:      ns(st.total_posts),
        emails:     ns(st.total_emails),
        gender:     ns(user.gender),
        laston:     (st.laston_date ? formatCallerDate(st.laston_date) : ""),
        birthdate:  ns(user.birthdate),
        connection: ns(client.protocol)
    };
    data.callers.unshift(entry);
    if(data.callers.length>CFG.maxCallers) data.callers=data.callers.slice(0,CFG.maxCallers);
    saveData(data);
}

// ============================================================
//  BUILD + DISPLAY
// ============================================================
var hdrLines=[], midLines=[], botLines=[];

function buildAll(data) {
    var ac=getActiveCols(), totalW=calcTotalW(ac);
    hdrLines=[];  midLines=[];  botLines=[];

    hdrLines.push(cc(CLR.title)+centerText("L A S T C A L L E R S",totalW));
    hdrLines.push(makeTopBorder(ac));
    hdrLines.push(makeHeaderRow(ac));
    hdrLines.push(makeMidDivider(ac));

    var callers=data.callers.slice().reverse();
    while(callers.length<CFG.maxCallers) callers.unshift(null);
    for(var i=0;i<callers.length;i++)
        midLines.push(callers[i]?makeDataRow(ac,callers[i],totalW):makeEmptyRow(ac,totalW));

    botLines.push(makeBotBorder(ac));
    // NOTE: "you are caller #" line is printed separately after file display,
    // NOT included in the lcallbot.msg file, so it never appears in the saved file.
}

function writeLinesTo(path, lines) {
    try { var f=new File(path); if(!f.open("w"))return; f.write(lines.join("\r\n")); f.close(); } catch(e){}
}
function printLines(lines) { for(var i=0;i<lines.length;i++) console.print(lines[i]+"\r\n"); }
function printFile(path) {
    try {
        var f=new File(path); if(!f.exists||!f.open("r"))return;
        var ln; while((ln=f.readln())!==null) console.print(ln+"\r\n"); f.close();
    } catch(e){}
}
function fileExists(path) { try{ var f=new File(path); return f.exists; }catch(e){return false;} }

// Show only: read and print the existing .msg/.ans files. Never writes anything.
function doShow() {
    var callerName = (user && user.alias) ? user.alias : "Guest";
    var callerNum  = (system.stats && system.stats.total_logons)
                     ? system.stats.total_logons : 0;
    fileExists(HDR_ANS) ? printFile(HDR_ANS) : printFile(HDR_MSG);
    printFile(MID_MSG);
    fileExists(BOT_ANS) ? printFile(BOT_ANS) : printFile(BOT_MSG);
    console.print(" "+cc(CLR.botName)+callerName+cc(CLR.botLabel)+", you are caller # "+cc(CLR.botNumber)+callerNum+CLR.reset+"\r\n");
    if(CFG.doPause) console.pause();
}

// Write: record caller, rebuild all .msg files and HTML, then show.
function doWrite(data) {
    recordCaller(data);
    buildAll(data);
    writeLinesTo(HDR_MSG,hdrLines); writeLinesTo(MID_MSG,midLines); writeLinesTo(BOT_MSG,botLines);
    var callerName = (user && user.alias) ? user.alias : "Guest";
    var callerNum  = (system.stats && system.stats.total_logons)
                     ? system.stats.total_logons : data.callers.length;
    fileExists(HDR_ANS) ? printFile(HDR_ANS) : printLines(hdrLines);
    printLines(midLines);
    fileExists(BOT_ANS) ? printFile(BOT_ANS) : printLines(botLines);
    console.print(" "+cc(CLR.botName)+callerName+cc(CLR.botLabel)+", you are caller # "+cc(CLR.botNumber)+callerNum+CLR.reset+"\r\n");
    if(CFG.doPause) console.pause();
}

// ============================================================
//  SYSOP MENU HELPERS
// ============================================================
var M_H = "\x01n\x01h\x01r";   // menu heading color
var M_K = "\x01n\x01h\x01w";   // menu key highlight
var M_T = "\x01n\x01r";        // menu normal text
var M_G = "\x01n\x01h\x01g";   // ON  indicator
var M_R = "\x01n\x01r";        // OFF indicator
var M_Y = "\x01n\x01h\x01y";   // prompt / input color
var M_C = "\x01n\x01h\x01c";   // sample text color
var M_W = "\x01n\x01h\x01w";   // value display
var M_D = "\x01n\x01h\x01k";   // dim / bright-black (dark gray) - brackets, [OFF]
var M_L = "\x01n\x01w";         // light gray (no bright) - body text
var HR  = "\x01n\x01r"+rep("\xc4",79);

function cls()     { console.print("\x01n\x1b[2J\x1b[H"); }
function mprint(s) { console.print(s+"\r\n"); }
function mkey(keys){ return console.getkeys(keys).toUpperCase(); }
function mstr(prompt, maxlen) {
    console.print(M_Y+prompt+" "+M_W);
    return console.getstr(maxlen||40);
}

function menuTitle(title) {
    mprint("");
    mprint(M_H+"  "+centerText("\x01h\x01wL A S T C A L L E R S  -  "+title, 73)+"  ");
//    mprint(HR);
//    mprint("");
}

// Render a single color code as a human-readable label + live sample
function colorLabel(code) {
    var clean = code.replace(/\x01./g,"");
    var label = code.replace(/\x01n/g,"^n").replace(/\x01h/g,"^h")
                    .replace(/\x01r/g,"^r").replace(/\x01g/g,"^g")
                    .replace(/\x01y/g,"^y").replace(/\x01b/g,"^b")
                    .replace(/\x01c/g,"^c").replace(/\x01w/g,"^w")
                    .replace(/\x01m/g,"^m").replace(/\x01k/g,"^k")
                    .replace(/\x01R/g,"^R").replace(/\x01G/g,"^G")
                    .replace(/\x01Y/g,"^Y").replace(/\x01B/g,"^B")
                    .replace(/\x01C/g,"^C").replace(/\x01W/g,"^W")
                    .replace(/\x01M/g,"^M").replace(/\x01K/g,"^K");
    return padRight(label,20) + "  " + code + "Sample" + "\x01n";
}

// ============================================================
//  VARIABLES SUBMENU
// ============================================================

// Full-screen label editor - clean slate so getstr works reliably
function editLabel(idx) {
    cls();
    menuTitle("RENAME LABEL  >  " + COLS[idx].key.toUpperCase());
    mprint("");
    mprint("  "+M_H+"Column key    : "+M_W+COLS[idx].key);
    mprint("  "+M_H+"Current label : "+M_W+COLS[idx].label);
    mprint("  "+M_H+"Column width  : "+M_W+COLS[idx].w+M_T+" chars  (suggested max for clean alignment)");
    mprint("");
    mprint(HR);
    mprint("  Type the new label and press "+M_K+"ENTER"+M_T+".");
    mprint("  Press "+M_K+"ENTER"+M_T+" with no text to keep the current label.");
    mprint("  "+M_Y+"Tip: labels longer than the column width will overlap the next column.");
    mprint("");
    console.print(M_Y+"  New label: "+M_W);
    var got = console.getstr(64);
    if (typeof got === "string" && got.length > 0) {
        COLS[idx].label = got;
        mprint("");
        mprint(M_G+"  Saved: "+M_W+COLS[idx].label);
    } else {
        mprint("");
        mprint(M_T+"  Unchanged.");
    }
    mprint("");
    mprint(M_T+"  Press any key...");
    console.getkey();
}

// Full-screen width editor
function editWidth(idx) {
    cls();
    menuTitle("PADDING WIDTH  >  " + COLS[idx].key.toUpperCase());
    mprint("");
    mprint("  "+M_H+"Column key  : "+M_W+COLS[idx].key);
    mprint("  "+M_H+"Current label: "+M_W+COLS[idx].label);
    mprint("  "+M_H+"Current width: "+M_W+COLS[idx].w+M_T+" chars");
    mprint("");
    mprint(HR);
    mprint("  "+M_T+"Enter a new width between "+M_W+"1"+M_T+" and "+M_W+"40"+M_T+".");
    mprint("  "+M_Y+"Note: narrowing width will also trim the label to fit.");
    mprint("");
    console.print(M_Y+"  New width (1-40): "+M_W);
    var got = console.getstr(2);
    var n   = parseInt(got, 10);
    if (!isNaN(n) && n >= 1 && n <= 40) {
        COLS[idx].w = n;
        if (COLS[idx].label.length > n) COLS[idx].label = COLS[idx].label.substr(0, n);
        mprint("");
        mprint(M_G+"  Width set to "+M_W+COLS[idx].w+M_T+" chars.  Label: "+M_W+COLS[idx].label);
    } else {
        mprint("");
        mprint(M_T+"  Unchanged.");
    }
    mprint("");
    mprint(M_T+"  Press any key...");
    console.getkey();
}

// Inline color edit — shared by menuColumnEdit and menuColors
function editColor(clrKey) {
    mprint("");
    mprint(M_T+"  Editing color for: "+M_K+clrKey+M_T+"   Current: "+colorLabel(CLR[clrKey]));
    mprint(M_T+"  Use ^x codes  (e.g. ^n^h^w = bright white)");
    mprint(M_T+"  ^n=reset  ^h=bright  ^r^g^y^b^c^m^w^k=fg  ^R^G^Y^B^C^M^W^K=bg");
    mprint(M_T+"  Press ENTER to keep current.");
    mprint("");
    var raw = mstr("New color:", 40);
    if (raw && raw.length > 0) {
        CLR[clrKey] = raw.replace(/\^([a-zA-Z])/g, "\x01$1");
    }
}

// Column detail screen
function menuColumnEdit(idx) {
    var done = false;
    while (!done) {
        var c = COLS[idx];
        cls();
        menuTitle("EDIT COLUMN  >  " + c.key.toUpperCase());
        mprint("");
        mprint("  "+M_H+"Column  : "+M_W+c.key);
        mprint("  "+M_H+"Label   : "+M_W+c.label+M_T+"   (max "+M_W+c.w+M_T+" chars)");
        mprint("  "+M_H+"Width   : "+M_W+c.w+M_T+" chars");
        mprint("  "+M_H+"Status  : "+(c.on ? M_G+"ON" : M_R+"OFF"));
        mprint("  "+M_H+"Color   : "+colorLabel(CLR[c.clrKey]));
        mprint("");
        mprint(HR);
        mprint("  "+M_D+"("+M_K+"T"+M_D+")"+M_L+"  Toggle "+M_G+"[ON]"+M_L+" / "+M_D+"[OFF]");
        mprint("  "+M_D+"("+M_K+"L"+M_D+")"+M_L+"  Rename header label");
        mprint("  "+M_D+"("+M_K+"W"+M_D+")"+M_L+"  Change padding width");
        mprint("  "+M_D+"("+M_K+"C"+M_D+")"+M_L+"  Change column color");
        mprint("  "+M_D+"("+M_K+"U"+M_D+")"+M_L+"  Move UP    (swap with column above)");
        mprint("  "+M_D+"("+M_K+"D"+M_D+")"+M_L+"  Move DOWN  (swap with column below)");
        mprint("");
        mprint(HR);
        mprint("  "+M_D+"("+M_K+"Q"+M_D+")"+M_L+"  Back to column list");
        mprint("");

        var ch = mkey("TLWCUDQ");
        if (ch === "Q") {
            done = true;
        } else if (ch === "T") {
            COLS[idx].on = !COLS[idx].on;
        } else if (ch === "L") {
            editLabel(idx);
        } else if (ch === "W") {
            editWidth(idx);
        } else if (ch === "C") {
            editColor(c.clrKey);
        } else if (ch === "U") {
            if (idx > 0) {
                var tmp = COLS[idx]; COLS[idx] = COLS[idx-1]; COLS[idx-1] = tmp; idx--;
            } else {
                mprint(M_R+"  Already at top."); console.getkey();
            }
        } else if (ch === "D") {
            if (idx < COLS.length - 1) {
                var tmp2 = COLS[idx]; COLS[idx] = COLS[idx+1]; COLS[idx+1] = tmp2; idx++;
            } else {
                mprint(M_R+"  Already at bottom."); console.getkey();
            }
        }
    }
}

// Draw one page of the variables list
// page 0 = cols 0..10  (up to 11 rows)  page 1 = cols 11..21
var VARS_PAGE_SIZE = 11;
function drawVarsPage(page) {
    var ALPHA  = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    var start  = page * VARS_PAGE_SIZE;
    var end    = Math.min(start + VARS_PAGE_SIZE, COLS.length);
    var pages  = Math.ceil(COLS.length / VARS_PAGE_SIZE);

    cls();
    menuTitle("VARIABLES  -  PAGE "+(page+1)+" OF "+pages);
//    mprint(M_T+"  Select a column to toggle, resize, rename, or reorder it.");
  //  mprint(M_T+"  Total width = sum of (w+3) per enabled col + 1.  Target: 79 cols.");
    mprint("");
    mprint(M_H+"  "+M_L+padRight("KEY",4)+padRight("POS",6)+padRight("COLUMN",14)+
                   padRight("LABEL",12)+padRight("PAD",5)+"STATUS");
    mprint(HR);

    for (var i = start; i < end; i++) {
        var c   = COLS[i];
        var ltr = ALPHA[i - start];
        var pos = padLeft(String(i+1),2)+"/"+COLS.length;
        var ind = c.on ? M_G+"[ON ] " : M_D+"[OFF] ";
        mprint("  "+M_D+"("+M_K+ltr+M_D+")"+M_L+"  "+
               padRight(pos,6)+padRight(c.key,14)+
               padRight(c.label,12)+padRight(String(c.w),5)+
               ind);
    }

    mprint("");
    mprint(HR);
    var ac = getActiveCols(), tw = calcTotalW(ac);
    mprint(M_T+"  Enabled: "+M_W+ac.length+M_T+
           "   Width: "+(tw<=80?M_G:M_R)+tw+M_T+
           "");
    mprint("");
    var nav = "";
    if (page > 0)         nav += M_K+"["+M_T+" prev page   ";
    if (page < pages-1)   nav += M_K+"]"+M_T+" next page   ";
    mprint("  "+nav+M_L+"A-"+ALPHA[end-start-1]+M_L+" edit column   "+M_D+"("+M_K+"Q"+M_D+")"+M_L+" Back");
    mprint("");
}

function menuVariables() {
    var ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    var page  = 0;
    var pages = Math.ceil(COLS.length / VARS_PAGE_SIZE);
    var done  = false;

    while (!done) {
        drawVarsPage(page);

        var start    = page * VARS_PAGE_SIZE;
        var end      = Math.min(start + VARS_PAGE_SIZE, COLS.length);
        var colKeys  = ALPHA.substr(0, end - start);
        var navKeys  = (page > 0 ? "[" : "") + (page < pages-1 ? "]" : "");
        var validKeys= colKeys + navKeys + "Q";

        var ch = mkey(validKeys);
        if (ch === "Q") {
            done = true;
        } else if (ch === "[") {
            if (page > 0) page--;
        } else if (ch === "]") {
            if (page < pages - 1) page++;
        } else {
            var localIdx = ALPHA.indexOf(ch);
            if (localIdx >= 0) menuColumnEdit(start + localIdx);
        }
    }
}

// ============================================================
//  COLORS SUBMENU
// ============================================================
// Color groups: each group = { title, keys[] }
var CLR_GROUPS = [
    { title:"STRUCTURE",  keys:["title","colHdr","border"] },
    { title:"COLUMNS",    keys:["node","time","name","location","level","age",
                                "logons","ltoday","ttoday","tlast"] },
    { title:"STATS",      keys:["uploads","downloads","ulb","dlb","posts",
                                "emails","gender","laston","birthdate","connection"] },
    { title:"COMMENT",    keys:["comment"] },
    { title:"FOOTER",     keys:["botLabel","botName","botNumber"] }
];

function menuColors() {
    var groupIdx = 0;
    var done = false;

    while (!done) {
        var grp = CLR_GROUPS[groupIdx];
        cls();
        menuTitle("COLORS  -  "+grp.title);
        mprint(M_T+"  Enter a color key as ^x codes.  Example:  ^n^h^w  =  bright white");
        mprint(M_T+"  ^n=reset  ^h=bright  ^r^g^y^b^c^m^w^k=fg  ^R^G^Y^B^C^M^W^K=bg");
        mprint("");
        mprint(M_H+"  "+padRight("KEY",4)+padRight("COLOR KEY",16)+"CURRENT CODE          SAMPLE");
        mprint(HR);

        var ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        var keys  = grp.keys;
        for (var i = 0; i < keys.length; i++) {
            var k = keys[i];
            mprint("  "+M_D+"("+M_K+ALPHA[i]+M_D+")"+M_L+" "+padRight(k,16)+colorLabel(CLR[k]));
        }

        mprint("");
        mprint(HR);
        mprint(M_T+"  Groups: "+M_K+"[ ]"+M_T+" prev  "+M_K+"[ ]"+M_T+" next");
        mprint(M_L+"  Press "+M_K+"A-"+ALPHA[keys.length-1]+M_L+" to edit  |  "+
               M_D+"("+M_K+","+M_D+")"+M_L+" prev group  "+M_D+"("+M_K+"."+M_D+")"+M_L+" next group  |  "+M_D+"("+M_K+"Q"+M_D+")"+M_L+" Back");
        mprint("");

        var validKeys = ALPHA.substr(0,keys.length)+"Q,.";
        var ch = mkey(validKeys);

        if (ch === "Q") {
            done = true;
        } else if (ch === ",") {
            groupIdx = (groupIdx - 1 + CLR_GROUPS.length) % CLR_GROUPS.length;
        } else if (ch === ".") {
            groupIdx = (groupIdx + 1) % CLR_GROUPS.length;
        } else {
            var idx = ALPHA.indexOf(ch);
            if (idx >= 0 && idx < keys.length) {
                editColor(keys[idx]);
            }
        }
    }
}

// ============================================================
//  GENERAL SETTINGS SUBMENU
// ============================================================
function menuGeneral() {
    var done = false;
    while (!done) {
        cls();
        menuTitle("GENERAL SETTINGS");
        mprint("");
        mprint("  "+M_D+"("+M_K+"A"+M_D+")"+M_L+" Max callers to track/display  :  "+M_W+CFG.maxCallers);
        mprint("  "+M_D+"("+M_K+"B"+M_D+")"+M_L+" Pause after display           :  "+(CFG.doPause?M_G+"[ON]":M_D+"[OFF]"));
        var dfi = (CFG.dateFormat >= 0 && CFG.dateFormat < DATE_FORMATS.length) ? CFG.dateFormat : 0;
        mprint("  "+M_D+"("+M_K+"C"+M_D+")"+M_L+" Date format                   :  "+M_W+DATE_FORMATS[dfi].example);
        mprint("");
        mprint(HR);
        mprint("  "+M_K+"Q"+M_T+" back to main menu");
        mprint("");

        var ch = mkey("ABCQ");
        if (ch === "Q") {
            done = true;
        } else if (ch === "A") {
            var s = mstr("Max callers (1-99):", 2);
            var n = parseInt(s, 10);
            if (!isNaN(n) && n >= 1 && n <= 99) CFG.maxCallers = n;
        } else if (ch === "B") {
            CFG.doPause = !CFG.doPause;
        } else if (ch === "C") {
            menuDateFormat();
        }
    }
}

// ============================================================
//  DATE FORMAT PICKER
// ============================================================
function menuDateFormat() {
    var done = false;
    while (!done) {
        cls();
        menuTitle("DATE FORMAT");
        mprint("");
        mprint("  "+M_T+"Choose a date format for Last On, Birth, and any date fields.");
        mprint("  "+M_T+"Example date used: "+M_W+"07 Mar 2026");
        mprint("");
        for (var i = 0; i < DATE_FORMATS.length; i++) {
            var sel = (i === CFG.dateFormat) ? M_G+"  >> " : M_T+"     ";
            var num = String(i+1);
            mprint("  "+sel+M_D+"("+M_K+num+M_D+")"+M_L+"  "+M_W+DATE_FORMATS[i].label+M_L+"  e.g.  "+M_W+DATE_FORMATS[i].example);
        }
        mprint("");
        mprint(HR);
        mprint("  "+M_L+"Type a number  "+M_D+"("+M_K+"1"+M_D+")"+M_L+"-"+M_D+"("+M_K+String(DATE_FORMATS.length)+M_D+")"+M_L+
               "  to select.    "+M_D+"("+M_K+"Q"+M_D+")"+M_L+" to go back.");
        mprint("");

        var raw = console.getkey();
        var rawU = raw ? raw.toUpperCase() : "";
        if (rawU === "Q") {
            done = true;
        } else {
            var pick = parseInt(raw, 10);
            if (!isNaN(pick) && pick >= 1 && pick <= DATE_FORMATS.length) {
                CFG.dateFormat = pick - 1;
            }
        }
    }
}

// ============================================================
//  GENERATE .ANS FILES
// ============================================================
function generateAnsFiles(data) {
    cls();
    menuTitle("GENERATE .ANS FILES");
    mprint("");
    mprint(M_T+"  This will write lcallhd.ans and lcallbot.ans using the");
    mprint(M_T+"  current column and color settings as a starting template.");
    mprint("");
    mprint(M_T+"  WARNING: This will overwrite any existing .ans files.");
    mprint(M_T+"  Once saved, edit them with your ANSI art tool.");
    mprint(M_T+"  Delete them to revert to auto-generated .msg display.");
    mprint("");
    mprint(M_L+"  "+M_D+"("+M_K+"Y"+M_D+")"+M_L+" to confirm  |  "+M_D+"("+M_K+"N"+M_D+")"+M_L+" to cancel");
    mprint("");

    var ch = mkey("YN");
    if (ch === "Y") {
        buildAll(data);
        writeLinesTo(HDR_ANS, hdrLines);
        writeLinesTo(BOT_ANS, botLines);
            // mid is always generated, no .ans override for it
        mprint("");
        mprint(M_G+"  Done!  Written:");
        mprint(M_W+"    "+HDR_ANS);
        mprint(M_W+"    "+BOT_ANS);
        mprint("");
        mprint(M_T+"  Press any key...");
        console.getkey();
    }
}


// ============================================================
//  BORDER STYLE PICKER
// ============================================================
function menuBorders() {
    var done = false;
    while (!done) {
        cls();
        menuTitle("BORDER STYLE");
        mprint("");
        mprint(M_L+"  Choose the box-drawing characters used for the table borders.");
        mprint("");
        for (var i = 0; i < BORDER_SETS.length; i++) {
            var bs  = BORDER_SETS[i];
            var sel = (i === CFG.borderStyle) ? M_G+">> " : M_L+"   ";
            var num = M_D+"("+M_K+String(i+1)+M_D+")";
            var preview = M_L+bs.TL+bs.H+bs.TT+bs.H+bs.TR+
                          " "+bs.V+"A"+bs.V+"B"+bs.V+
                          " "+bs.BL+bs.H+bs.BT+bs.H+bs.BR;
            mprint("  "+sel+num+" "+M_W+padRight(bs.label,22)+M_T+"  "+preview);
        }
        mprint("");
        mprint(HR);
        mprint("  "+M_L+"Type "+M_D+"("+M_K+"1"+M_D+")"+M_L+"-"+M_D+"("+M_K+String(BORDER_SETS.length)+M_D+")"+M_L+" to select.    "+M_D+"("+M_K+"Q"+M_D+")"+M_L+" to go back.");
        mprint("");

        var raw = console.getkey();
        if (!raw) continue;
        var rawU = raw.toUpperCase();
        if (rawU === "Q") {
            done = true;
        } else {
            var pick = parseInt(raw, 10);
            if (!isNaN(pick) && pick >= 1 && pick <= BORDER_SETS.length) {
                CFG.borderStyle = pick - 1;
                applyBorderSet(CFG.borderStyle);
            }
        }
    }
}

// ============================================================
//  MAIN SYSOP MENU
// ============================================================
function menuMain(data) {
    var done     = false;
    var modified = false;

    while (!done) {
        cls();
        menuTitle("SYSOP CONFIGURATION");
        mprint("");
        mprint("  "+M_D+"("+M_K+"V"+M_D+")"+M_L+"  Variables    "+M_L+"Toggle which columns are displayed");
        mprint("  "+M_D+"("+M_K+"C"+M_D+")"+M_L+"  Colors       "+M_L+"Set color codes for each element");
        mprint("  "+M_D+"("+M_K+"B"+M_D+")"+M_L+"  Borders      "+M_L+"Choose box-drawing character style");
        mprint("  "+M_D+"("+M_K+"G"+M_D+")"+M_L+"  General      "+M_L+"Max callers, pause settings");
        mprint("");
        mprint(HR);
        mprint("  "+M_D+"("+M_K+"P"+M_D+")"+M_L+"  Preview      "+M_L+"Preview the last callers list");
        mprint("  "+M_D+"("+M_K+"A"+M_D+")"+M_L+"  Generate     "+M_L+"Write lcallhd.ans and lcallbot.ans");
        mprint("");
        mprint(HR);
        mprint("  "+M_D+"("+M_K+"R"+M_D+")"+M_L+"  Reset        "+M_L+"Reset ALL settings to factory defaults");
        mprint("");
        mprint(HR);
        mprint("  "+M_D+"("+M_K+"S"+M_D+")"+M_L+"  Save & exit  "+M_L+"Save settings to lcallsettings.json");
        mprint("  "+M_D+"("+M_K+"Q"+M_D+")"+M_L+"  Quit         "+M_L+"Exit without saving");
        mprint("");

        var ch = mkey("VCBGPASRQ");

        if (ch === "V") { menuVariables(); modified=true; }
        else if (ch === "C") { menuColors(); modified=true; }
        else if (ch === "B") { menuBorders(); modified=true; }
        else if (ch === "G") { menuGeneral(); modified=true; }
        else if (ch === "P") {
            cls();
            buildAll(data);
            printLines(hdrLines);
            printLines(midLines);
            printLines(botLines);
            var pName = (user && user.alias) ? user.alias : "Guest";
            var pNum  = (system.stats && system.stats.total_logons)
                        ? system.stats.total_logons : data.callers.length;
            console.print(" "+CLR.botName+pName+CLR.botLabel+", you are caller # "+CLR.botNumber+pNum+CLR.reset+"\r\n");
            mprint(""); mprint(M_T+"  Press any key..."); console.getkey();
        }
        else if (ch === "A") { generateAnsFiles(data); }
        else if (ch === "R") {
            cls();
            menuTitle("RESET TO DEFAULTS");
            mprint("");
            mprint(M_Y+"  WARNING: This will reset ALL columns, colors, and settings");
            mprint(M_Y+"  to factory defaults.  The saved settings file will be deleted.");
            mprint("");
            mprint(M_L+"  "+M_D+"("+M_K+"Y"+M_D+")"+M_L+" to confirm  |  "+M_D+"("+M_K+"N"+M_D+")"+M_L+" to cancel");
            mprint("");
            var rch = mkey("YN");
            if (rch === "Y") {
                resetDefaults();
                file_remove(SETTINGS_FILE);
                modified = false;
                cls(); menuTitle("RESET COMPLETE");
                mprint(""); mprint(M_G+"  All settings restored to factory defaults.");
                mprint(M_T+"  Settings file deleted.  Press any key...");
                console.getkey();
            }
        }
        else if (ch === "S") {
            if (saveSettings()) {
                cls(); menuTitle("SAVED");
                mprint(""); mprint(M_G+"  Settings saved to:"); mprint(M_W+"    "+SETTINGS_FILE);
                mprint(""); mprint(M_T+"  Press any key..."); console.getkey();
            } else {
                mprint(M_R+"  ERROR: could not write settings file."); console.getkey();
            }
            done = true;
        }
        else if (ch === "Q") {
            if (modified) {
                mprint(""); mprint(M_Y+"  Unsaved changes.  "+M_D+"("+M_K+"S"+M_D+")"+M_Y+" to save,  "+M_D+"("+M_K+"Q"+M_D+")"+M_Y+" to discard:  ");
                var c2 = mkey("SQ");
                if (c2 === "S") { saveSettings(); }
            }
            done = true;
        }
    }
}

// ============================================================
//  MAIN ENTRY POINT
// ============================================================
try { mkdir(LCALLS_DIR); } catch(e) {}

// Apply saved settings over the defaults
applySettings(loadSettings());
applyBorderSet(CFG.borderStyle);

var appData = loadData();
// Scan ALL argv slots - Synchronet may put the script name in argv[0]
// and push the actual argument to argv[1] depending on how it was invoked.
var arg0 = "";
if (argv && argv.length > 0) {
    for (var ai = 0; ai < argv.length; ai++) {
        var av = String(argv[ai]).toLowerCase().replace(/\.js$/,"");
        if (av === "show" || av === "write" || av === "debug" || av === "settings") {
            arg0 = av;
            break;
        }
    }
}

if (arg0 === "debug") {
    // ---- Sysop debug: dump raw user property values (level 99+) --------
    if (!user || (user.security && user.security.level < 99) || !user.security) {
        console.print("\x01n\x01r  Access denied.\r\n");
    } else {
        console.print("\x01n\x1b[2J\x1b[H");
        console.print("\x01n\x01h\x01w  USER PROPERTY DEBUG DUMP\r\n");
        console.print("\x01n\x01r" + rep("\xc4",79) + "\r\n");
        var dSt  = (user.stats    || {});
        var dSec = (user.security || {});
        var dbProps = [
            ["user.number",              user.number],
            ["user.alias",               user.alias],
            ["user.name",                user.name],
            ["user.location",            user.location],
            ["user.age",                 user.age],
            ["user.gender",              user.gender],
            ["user.birthdate",           user.birthdate],
            ["user.comment",             user.comment],
            ["user.note",                user.note],
            ["user.security.level",      dSec.level],
            ["user.stats.total_logons",  dSt.total_logons],
            ["user.stats.logons_today",  dSt.logons_today],
            ["user.stats.timeon_today",  dSt.timeon_today],
            ["user.stats.timeon_last_logon", dSt.timeon_last_logon],
            ["user.stats.files_uploaded",   dSt.files_uploaded],
            ["user.stats.bytes_uploaded",   dSt.bytes_uploaded],
            ["user.stats.files_downloaded", dSt.files_downloaded],
            ["user.stats.bytes_downloaded", dSt.bytes_downloaded],
            ["user.stats.total_posts",      dSt.total_posts],
            ["user.stats.total_emails",     dSt.total_emails],
            ["user.stats.laston_date (raw)",  dSt.laston_date],
            ["user.stats.laston_date (fmt)",  dSt.laston_date ? formatCallerDate(dSt.laston_date) : ""],
            ["formatCallerDate(now)",           formatCallerDate(time())],
            ["client.protocol",          client.protocol],
            ["bbs.node_num",             bbs.node_num],
            ["argv.length",              argv ? argv.length : "(no argv)"],
            ["argv (all)",               argv ? argv.join(" | ") : "(no argv)"]
        ];
        for (var di = 0; di < dbProps.length; di++) {
            var label = padRight(dbProps[di][0], 22);
            var val   = (dbProps[di][1] === undefined) ? "\x01n\x01r(undefined)"
                      : (dbProps[di][1] === null)      ? "\x01n\x01r(null)"
                      : "\x01n\x01h\x01w" + String(dbProps[di][1]);
            console.print("\x01n\x01r  " + label + " = " + val + "\r\n");
        }
        console.print("\x01n\x01r" + rep("\xc4",79) + "\r\n\r\n");
        console.pause();
    }

} else if (arg0 === "settings") {
    // ---- Sysop configuration menu ---------------------------
    if (!user || (user.security && user.security.level < 99) || !user.security) {
        console.print(M_R+"  Access denied.  Security level 99 required.\r\n");
    } else {
        menuMain(appData);
    }

} else if (arg0 === "show") {
    // ---- SHOW: display existing files only, no writing -----
    console.print("\x01n\x1b[2J\x1b[H");
    doShow();

} else if (arg0 === "write") {
    // ---- WRITE: record caller, rebuild files, then show ----
    console.print("\x01n\x1b[2J\x1b[H");
    doWrite(appData);

} else {
    // ---- No recognised argument: show usage ----------------
    console.print("\x01n\x01r\r\n");
    console.print("\x01n\x01h\x01w  eoblcalls.js  -  Last Callers Board\r\n");
    console.print("\x01n\x01r  Usage:\r\n");
    console.print("\x01n\x01h\x01w    ?eoblcalls.js show      \x01n\x01r  Display last callers list (read-only)\r\n");
    console.print("\x01n\x01h\x01w    ?eoblcalls.js write     \x01n\x01r  Record this login, then display\r\n");
    console.print("\x01n\x01h\x01w    ?eoblcalls.js settings  \x01n\x01r  Sysop configuration menu (level 99+)\r\n");
    console.print("\x01n\x01h\x01w    ?eoblcalls.js debug     \x01n\x01r  Dump user property values (level 99+)\r\n");
    console.print("\r\n");
}