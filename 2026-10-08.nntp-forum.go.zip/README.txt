NNTP Web Forum — Go Edition
===========================

A standalone web server that turns any NNTP newsgroup server into a modern
browser-based forum.  No dependencies, no runtime required — just a single
self-contained executable.

FILES
-----
  nntp-forum-win64.exe   Windows 64-bit  (Windows 7+)
  nntp-forum-win32.exe   Windows 32-bit  (Windows XP+)
  nntp-forum-linux64     Linux 64-bit    (glibc 2.17+, most distros)
  nntp-forum.ini         Configuration file
  README.txt             This file

QUICK START
-----------
1. Edit nntp-forum.ini — set host, port, and optionally username/password.

2. Run the executable for your platform:

     Windows:   double-click nntp-forum-win64.exe
                or from a command prompt:
                  nntp-forum-win64.exe

     Linux:     chmod +x nntp-forum-linux64
                ./nntp-forum-linux64

3. Open your browser to:   http://localhost:8080

4. Sign in with your NNTP credentials (or any username if the server is open).

CONFIGURATION (nntp-forum.ini)
-------------------------------
  host         NNTP server hostname or IP
  port         Port number (119 standard, 563 SSL — SSL not yet supported)
  username     Server login username (leave blank if open)
  password     Server login password
  timeout      Socket timeout in seconds (default 30)
  max_headers  Max article headers to fetch per group (default 300)
  web_port     Port the web UI listens on (default 8080)
  data_dir     Where session/group/cache files are stored (default: data/)
  session_ttl  Login session lifetime in seconds (default 28800 = 8 hours)

The nntp-forum.ini file must be in the same directory as the executable,
or specify a different path with --config:

  nntp-forum-win64.exe --config C:\path\to\nntp-forum.ini

Command-line flags
------------------
  --config <path>    Path to configuration file
  --port   <n>       Override web_port from ini

DATA DIRECTORY
--------------
The data/ directory (or whatever data_dir is set to) is created automatically
and contains:

  nntp_sessions.json   Active login sessions
  nntp_groups.json     Cached newsgroup list
  nntp_subs.json       Per-group subscription flags
  nntp_cache/          Per-group article header caches

Delete these files to start fresh.

FEATURES
--------
  * Full forum UI with threaded message tree
  * Quote-reply with > prefixes and attribution lines
  * Sort threads by newest or oldest
  * 8 color themes + custom theme editor
  * User profile (display name, email, signature)
  * Refresh button clears group cache and re-fetches
  * Subscribe/unsubscribe to individual groups
  * Scan for new groups added since a date
  * Settings panel to change server config and test connection

NOTES
-----
  * SSL/TLS (port 563) is not yet implemented; use a plain port 119 connection
    or a local SSL tunnel (e.g. stunnel) in front.
  * The web UI is served over plain HTTP; do not expose it to the internet
    without a reverse proxy with HTTPS.
  * Tested against INN and Synchronet NNTP servers.
