package main

import _ "embed"

//go:embed frontend.html
var indexHTML []byte
