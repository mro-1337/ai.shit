// nntp-forum — standalone NNTP web forum server
// Compile:
//   go build -o nntp-forum .
// Cross-compile:
//   GOOS=windows GOARCH=amd64 go build -o nntp-forum-win64.exe .
//   GOOS=windows GOARCH=386   go build -o nntp-forum-win32.exe .
//   GOOS=linux   GOARCH=amd64 go build -o nntp-forum-linux64  .

package main

import (
	"bufio"
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"math"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

// ─── Config ────────────────────────────────────────────────────────────────────

type Config struct {
	Host       string `json:"host"`
	Port       int    `json:"port"`
	UseSSL     bool   `json:"use_ssl"`
	Username   string `json:"username"`
	Password   string `json:"password"`
	Timeout    int    `json:"timeout"`
	MaxHeaders int    `json:"max_headers"`
	WebPort    int    `json:"web_port"`
	DataDir    string `json:"data_dir"`
	SessionTTL int    `json:"session_ttl"`
}

func defaultConfig() Config {
	return Config{
		Host:       "localhost",
		Port:       119,
		Timeout:    30,
		MaxHeaders: 300,
		WebPort:    8080,
		DataDir:    "data",
		SessionTTL: 28800,
	}
}

var configPath = "nntp-forum.ini"

func loadConfig() Config {
	cfg := defaultConfig()
	f, err := os.Open(configPath)
	if err != nil {
		return cfg
	}
	defer f.Close()

	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || line[0] == ';' || line[0] == '#' || line[0] == '[' {
			continue
		}
		idx := strings.IndexByte(line, '=')
		if idx < 0 {
			continue
		}
		k := strings.TrimSpace(line[:idx])
		v := strings.TrimSpace(line[idx+1:])
		// strip inline comment
		if ci := strings.IndexByte(v, ';'); ci >= 0 {
			v = strings.TrimSpace(v[:ci])
		}
		switch strings.ToLower(k) {
		case "host":
			cfg.Host = v
		case "port":
			if n, err := strconv.Atoi(v); err == nil {
				cfg.Port = n
			}
		case "use_ssl":
			cfg.UseSSL = v == "true" || v == "1" || v == "yes"
		case "username":
			cfg.Username = v
		case "password":
			cfg.Password = v
		case "timeout":
			if n, err := strconv.Atoi(v); err == nil {
				cfg.Timeout = n
			}
		case "max_headers":
			if n, err := strconv.Atoi(v); err == nil {
				cfg.MaxHeaders = n
			}
		case "web_port":
			if n, err := strconv.Atoi(v); err == nil {
				cfg.WebPort = n
			}
		case "data_dir":
			cfg.DataDir = v
		case "session_ttl":
			if n, err := strconv.Atoi(v); err == nil {
				cfg.SessionTTL = n
			}
		}
	}
	return cfg
}

func saveConfig(cfg Config) {
	lines := []string{
		"; nntp-forum.ini — NNTP Web Forum configuration",
		"",
		"[NNTP]",
		fmt.Sprintf("host        = %s", cfg.Host),
		fmt.Sprintf("port        = %d", cfg.Port),
		fmt.Sprintf("use_ssl     = %v", cfg.UseSSL),
		fmt.Sprintf("username    = %s", cfg.Username),
		fmt.Sprintf("password    = %s", cfg.Password),
		fmt.Sprintf("timeout     = %d", cfg.Timeout),
		fmt.Sprintf("max_headers = %d", cfg.MaxHeaders),
		fmt.Sprintf("web_port    = %d", cfg.WebPort),
		fmt.Sprintf("data_dir    = %s", cfg.DataDir),
		fmt.Sprintf("session_ttl = %d", cfg.SessionTTL),
	}
	_ = os.WriteFile(configPath, []byte(strings.Join(lines, "\n")+"\n"), 0644)
}

// ─── NNTP Client ────────────────────────────────────────────────────────────────

type NNTPClient struct {
	conn    net.Conn
	reader  *bufio.Reader
	timeout time.Duration
}

func dialNNTP(host string, port int, timeoutSec int) (*NNTPClient, error) {
	addr := fmt.Sprintf("%s:%d", host, port)
	d := net.Dialer{Timeout: time.Duration(timeoutSec) * time.Second}
	conn, err := d.Dial("tcp", addr)
	if err != nil {
		return nil, fmt.Errorf("cannot connect to %s: %w", addr, err)
	}
	c := &NNTPClient{
		conn:    conn,
		reader:  bufio.NewReader(conn),
		timeout: time.Duration(timeoutSec) * time.Second,
	}
	// read greeting
	banner, err := c.readline()
	if err != nil {
		conn.Close()
		return nil, err
	}
	code, _ := strconv.Atoi(safeCode(banner))
	if code != 200 && code != 201 {
		conn.Close()
		return nil, fmt.Errorf("NNTP rejected connection: %s", banner)
	}
	return c, nil
}

func safeCode(s string) string {
	if len(s) >= 3 {
		return s[:3]
	}
	return "000"
}

func (c *NNTPClient) setDeadline() {
	if c.timeout > 0 {
		_ = c.conn.SetDeadline(time.Now().Add(c.timeout))
	}
}

func (c *NNTPClient) readline() (string, error) {
	c.setDeadline()
	line, err := c.reader.ReadString('\n')
	if err != nil {
		return "", fmt.Errorf("NNTP read error: %w", err)
	}
	return strings.TrimRight(line, "\r\n"), nil
}

func (c *NNTPClient) send(cmd string) error {
	c.setDeadline()
	_, err := fmt.Fprintf(c.conn, "%s\r\n", cmd)
	return err
}

func (c *NNTPClient) cmd(cmd string, okCodes []int) (int, string, error) {
	if err := c.send(cmd); err != nil {
		return 0, "", err
	}
	resp, err := c.readline()
	if err != nil {
		return 0, "", err
	}
	code, _ := strconv.Atoi(safeCode(resp))
	if okCodes != nil {
		ok := false
		for _, oc := range okCodes {
			if code == oc {
				ok = true
				break
			}
		}
		if !ok {
			verb := cmd
			if i := strings.IndexByte(cmd, ' '); i > 0 {
				verb = cmd[:i]
			}
			return code, resp, fmt.Errorf("NNTP %s error: %s", verb, resp)
		}
	}
	text := ""
	if len(resp) > 4 {
		text = resp[4:]
	}
	return code, text, nil
}

func (c *NNTPClient) readMulti() ([]string, error) {
	var lines []string
	for {
		line, err := c.readline()
		if err != nil {
			return lines, err
		}
		if line == "." {
			break
		}
		if len(line) > 0 && line[0] == '.' {
			line = line[1:]
		}
		lines = append(lines, line)
	}
	return lines, nil
}

func (c *NNTPClient) Auth(user, pass string) error {
	if user == "" {
		return nil
	}
	// Match the working Node.js behaviour exactly:
	//   USER → 381  → send PASS
	//   USER → 281  → already authed, done
	//   USER → 482  → auth not available, proceed anyway
	//   USER → 502  → server doesn't support AUTHINFO, proceed without PASS
	// Do NOT send PASS on 502 — Synchronet closes the connection if we do.
	code, _, err := c.cmd("AUTHINFO USER "+user, []int{381, 281, 482, 502})
	if err != nil {
		return err
	}
	if code == 381 && pass != "" {
		r2code, _, err := c.cmd("AUTHINFO PASS "+pass, []int{281, 481, 502})
		if err != nil {
			return err
		}
		if r2code == 481 {
			return fmt.Errorf("Authentication failed: wrong username or password")
		}
	}
	return nil
}

func (c *NNTPClient) Quit() {
	if c.conn == nil {
		return
	}
	_ = c.send("QUIT")
	_ = c.conn.Close()
	c.conn = nil
}

// ─── Group / Article types ──────────────────────────────────────────────────────

type Group struct {
	Name     string `json:"name"`
	High     int    `json:"high"`
	Low      int    `json:"low"`
	Count    int    `json:"count"`
	Flag     string `json:"flag,omitempty"`
	AddedAt  string `json:"addedAt,omitempty"`
	LastSeen string `json:"lastSeen,omitempty"`
}

type Article struct {
	Num        int      `json:"num"`
	Subject    string   `json:"subject"`
	From       string   `json:"from"`
	Date       string   `json:"date"`
	MessageID  string   `json:"messageId"`
	References []string `json:"references"`
	ByteCount  int      `json:"byteCount"`
	LineCount  int      `json:"lineCount"`
}

type FullArticle struct {
	Headers map[string]string `json:"headers"`
	Body    []string          `json:"body"`
}

func (c *NNTPClient) ListGroups() ([]Group, error) {
	if err := c.send("LIST"); err != nil {
		return nil, err
	}
	resp, err := c.readline()
	if err != nil {
		return nil, err
	}
	code, _ := strconv.Atoi(safeCode(resp))
	if code == 480 {
		return nil, fmt.Errorf("Server requires authentication (480) — check your username and password in the config")
	}
	if code != 215 {
		return nil, fmt.Errorf("LIST failed: %s", resp)
	}
	lines, err := c.readMulti()
	if err != nil {
		return nil, err
	}
	var groups []Group
	for _, line := range lines {
		f := strings.Fields(line)
		if len(f) < 1 || f[0] == "" {
			continue
		}
		h, _ := strconv.Atoi(safeGet(f, 1))
		lo, _ := strconv.Atoi(safeGet(f, 2))
		count := h - lo
		if count < 0 {
			count = 0
		}
		flag := safeGet(f, 3)
		if flag == "" {
			flag = "y"
		}
		groups = append(groups, Group{Name: f[0], High: h, Low: lo, Count: count, Flag: flag})
	}
	return groups, nil
}

func (c *NNTPClient) NewGroups(since time.Time) ([]Group, error) {
	ds := since.Format("20060102")
	ts := since.Format("150405")
	if err := c.send("NEWGROUPS " + ds + " " + ts); err != nil {
		return nil, err
	}
	resp, err := c.readline()
	if err != nil {
		return nil, err
	}
	code, _ := strconv.Atoi(safeCode(resp))
	if code != 231 {
		return nil, nil
	}
	lines, err := c.readMulti()
	if err != nil {
		return nil, err
	}
	var groups []Group
	for _, line := range lines {
		f := strings.Fields(line)
		if len(f) < 1 || f[0] == "" {
			continue
		}
		h, _ := strconv.Atoi(safeGet(f, 1))
		lo, _ := strconv.Atoi(safeGet(f, 2))
		count := h - lo
		if count < 0 {
			count = 0
		}
		groups = append(groups, Group{Name: f[0], High: h, Low: lo, Count: count})
	}
	return groups, nil
}

func (c *NNTPClient) SelectGroup(name string) (Group, error) {
	_, text, err := c.cmd("GROUP "+name, []int{211})
	if err != nil {
		return Group{}, err
	}
	f := strings.Fields(text)
	cnt, _ := strconv.Atoi(safeGet(f, 0))
	lo, _ := strconv.Atoi(safeGet(f, 1))
	hi, _ := strconv.Atoi(safeGet(f, 2))
	return Group{Name: name, Count: cnt, Low: lo, High: hi}, nil
}

func (c *NNTPClient) GetOverview(low, high int) ([]Article, error) {
	if err := c.send(fmt.Sprintf("XOVER %d-%d", low, high)); err != nil {
		return nil, err
	}
	resp, err := c.readline()
	if err != nil {
		return nil, err
	}
	code, _ := strconv.Atoi(safeCode(resp))
	if code != 224 {
		return nil, nil
	}
	lines, err := c.readMulti()
	if err != nil {
		return nil, err
	}
	var articles []Article
	for _, line := range lines {
		f := strings.Split(line, "\t")
		if len(f) < 5 {
			continue
		}
		num, _ := strconv.Atoi(safeGet(f, 0))
		bc, _ := strconv.Atoi(safeGet(f, 6))
		lc, _ := strconv.Atoi(safeGet(f, 7))
		refs := []string{}
		if len(f) > 5 {
			for _, r := range strings.Fields(f[5]) {
				if r != "" {
					refs = append(refs, r)
				}
			}
		}
		articles = append(articles, Article{
			Num:        num,
			Subject:    decodeHeader(safeGet(f, 1)),
			From:       decodeHeader(safeGet(f, 2)),
			Date:       safeGet(f, 3),
			MessageID:  safeGet(f, 4),
			References: refs,
			ByteCount:  bc,
			LineCount:  lc,
		})
	}
	return articles, nil
}

func (c *NNTPClient) GetArticle(numOrID string) (*FullArticle, error) {
	_, _, err := c.cmd("ARTICLE "+numOrID, []int{220})
	if err != nil {
		return nil, err
	}
	lines, err := c.readMulti()
	if err != nil {
		return nil, err
	}
	art := &FullArticle{
		Headers: map[string]string{},
		Body:    []string{},
	}
	inBody := false
	for _, line := range lines {
		if !inBody && line == "" {
			inBody = true
			continue
		}
		if inBody {
			art.Body = append(art.Body, line)
		} else {
			if idx := strings.IndexByte(line, ':'); idx > 0 {
				k := strings.ToLower(line[:idx])
				v := ""
				if len(line) > idx+2 {
					v = decodeHeader(line[idx+2:])
				}
				art.Headers[k] = v
			}
		}
	}
	return art, nil
}

type PostOptions struct {
	Newsgroups string
	Subject    string
	From       string
	RefID      string
	Body       []string
}

func (c *NNTPClient) Post(opts PostOptions) (bool, error) {
	_, _, err := c.cmd("POST", []int{340})
	if err != nil {
		return false, err
	}
	var sb strings.Builder
	sb.WriteString("From: " + opts.From + "\r\n")
	sb.WriteString("Newsgroups: " + opts.Newsgroups + "\r\n")
	sb.WriteString("Subject: " + opts.Subject + "\r\n")
	if opts.RefID != "" {
		sb.WriteString("References: " + opts.RefID + "\r\n")
	}
	sb.WriteString("X-Newsreader: NNTP Web Forum (Go)\r\n\r\n")
	for _, line := range opts.Body {
		if len(line) > 0 && line[0] == '.' {
			line = "." + line
		}
		sb.WriteString(line + "\r\n")
	}
	sb.WriteString(".\r\n")
	c.setDeadline()
	_, err = io.WriteString(c.conn, sb.String())
	if err != nil {
		return false, err
	}
	resp, err := c.readline()
	if err != nil {
		return false, err
	}
	code, _ := strconv.Atoi(safeCode(resp))
	return code == 240, nil
}

// ─── RFC-2047 header decode (minimal) ──────────────────────────────────────────

var rfc2047Re = regexp.MustCompile(`=\?[^?]+\?[BbQq]\?([^?]*)\?=`)

func decodeHeader(s string) string {
	return rfc2047Re.ReplaceAllStringFunc(s, func(m string) string {
		sub := rfc2047Re.FindStringSubmatch(m)
		if len(sub) < 2 {
			return m
		}
		return strings.ReplaceAll(sub[1], "_", " ")
	})
}

func safeGet(f []string, i int) string {
	if i < len(f) {
		return f[i]
	}
	return ""
}

// ─── Session management ─────────────────────────────────────────────────────────

type Session struct {
	Username    string  `json:"username"`
	Password    string  `json:"password"`
	DisplayName string  `json:"displayName"`
	Created     float64 `json:"created"`
	LastActive  float64 `json:"lastActive"`
}

type SessionStore struct {
	mu   sync.Mutex
	data map[string]*Session
	path string
	ttl  int
}

func newSessionStore(path string, ttl int) *SessionStore {
	ss := &SessionStore{path: path, ttl: ttl, data: map[string]*Session{}}
	ss.load()
	return ss
}

func (ss *SessionStore) load() {
	b, err := os.ReadFile(ss.path)
	if err != nil {
		return
	}
	_ = json.Unmarshal(b, &ss.data)
}

func (ss *SessionStore) save() {
	b, _ := json.MarshalIndent(ss.data, "", "  ")
	_ = os.WriteFile(ss.path, b, 0644)
}

func (ss *SessionStore) prune() {
	now := float64(time.Now().Unix())
	changed := false
	for t, s := range ss.data {
		if now-s.Created > float64(ss.ttl) {
			delete(ss.data, t)
			changed = true
		}
	}
	if changed {
		ss.save()
	}
}

func (ss *SessionStore) Get(token string) *Session {
	ss.mu.Lock()
	defer ss.mu.Unlock()
	s, ok := ss.data[token]
	if !ok {
		return nil
	}
	now := float64(time.Now().Unix())
	if now-s.Created > float64(ss.ttl) {
		delete(ss.data, token)
		ss.save()
		return nil
	}
	s.LastActive = now
	return s
}

func (ss *SessionStore) Create(username, password, displayName string) string {
	ss.mu.Lock()
	defer ss.mu.Unlock()
	b := make([]byte, 24)
	_, _ = rand.Read(b)
	token := hex.EncodeToString(b) + "_" + strconv.FormatInt(time.Now().UnixNano(), 36)
	ss.data[token] = &Session{
		Username:    username,
		Password:    password,
		DisplayName: displayName,
		Created:     float64(time.Now().Unix()),
		LastActive:  float64(time.Now().Unix()),
	}
	ss.save()
	return token
}

func (ss *SessionStore) Delete(token string) {
	ss.mu.Lock()
	defer ss.mu.Unlock()
	delete(ss.data, token)
	ss.save()
}

// ─── Group / Subscription DB ───────────────────────────────────────────────────

type GroupDB struct {
	mu   sync.Mutex
	data map[string]*Group
	path string
}

func newGroupDB(path string) *GroupDB {
	db := &GroupDB{path: path, data: map[string]*Group{}}
	b, err := os.ReadFile(path)
	if err == nil {
		_ = json.Unmarshal(b, &db.data)
	}
	return db
}

func (db *GroupDB) save() {
	b, _ := json.MarshalIndent(db.data, "", "  ")
	_ = os.WriteFile(db.path, b, 0644)
}

func (db *GroupDB) Merge(fresh []Group) map[string]int {
	db.mu.Lock()
	defer db.mu.Unlock()
	now := time.Now().UTC().Format(time.RFC3339)
	added, updated := 0, 0
	for i := range fresh {
		g := &fresh[i]
		if existing, ok := db.data[g.Name]; !ok {
			ng := *g
			ng.AddedAt = now
			ng.LastSeen = now
			db.data[g.Name] = &ng
			added++
		} else {
			existing.High = g.High
			existing.Low = g.Low
			existing.Count = g.Count
			existing.LastSeen = now
			updated++
		}
	}
	db.save()
	return map[string]int{"added": added, "updated": updated, "total": len(db.data)}
}

func (db *GroupDB) Replace(fresh []Group) map[string]int {
	db.mu.Lock()
	defer db.mu.Unlock()
	now := time.Now().UTC().Format(time.RFC3339)
	oldData := db.data
	db.data = map[string]*Group{}
	added := 0
	for i := range fresh {
		g := &fresh[i]
		ng := *g
		if prev, ok := oldData[g.Name]; ok {
			ng.AddedAt = prev.AddedAt
		} else {
			ng.AddedAt = now
			added++
		}
		ng.LastSeen = now
		db.data[g.Name] = &ng
	}
	db.save()
	return map[string]int{"total": len(fresh), "added": added}
}

func (db *GroupDB) All() []*Group {
	db.mu.Lock()
	defer db.mu.Unlock()
	list := make([]*Group, 0, len(db.data))
	for _, g := range db.data {
		list = append(list, g)
	}
	return list
}

func (db *GroupDB) Update(name string, g Group) {
	db.mu.Lock()
	defer db.mu.Unlock()
	if existing, ok := db.data[name]; ok {
		existing.High = g.High
		existing.Low = g.Low
		existing.Count = g.Count
	}
	db.save()
}

func (db *GroupDB) Len() int {
	db.mu.Lock()
	defer db.mu.Unlock()
	return len(db.data)
}

type SubDB struct {
	mu   sync.Mutex
	data map[string]bool
	path string
}

func newSubDB(path string) *SubDB {
	db := &SubDB{path: path, data: map[string]bool{}}
	b, err := os.ReadFile(path)
	if err == nil {
		_ = json.Unmarshal(b, &db.data)
	}
	return db
}

func (db *SubDB) save() {
	b, _ := json.MarshalIndent(db.data, "", "  ")
	_ = os.WriteFile(db.path, b, 0644)
}

func (db *SubDB) IsSubscribed(name string) bool {
	db.mu.Lock()
	defer db.mu.Unlock()
	v, ok := db.data[name]
	return !ok || v // default true if unseen
}

func (db *SubDB) All() map[string]bool {
	db.mu.Lock()
	defer db.mu.Unlock()
	out := make(map[string]bool, len(db.data))
	for k, v := range db.data {
		out[k] = v
	}
	return out
}

func (db *SubDB) SetIfNew(name string) {
	db.mu.Lock()
	defer db.mu.Unlock()
	if _, ok := db.data[name]; !ok {
		db.data[name] = true
	}
}

func (db *SubDB) Update(updates map[string]bool) {
	db.mu.Lock()
	defer db.mu.Unlock()
	for k, v := range updates {
		db.data[k] = v
	}
	db.save()
}

func (db *SubDB) RemoveAbsent(groupDB *GroupDB) {
	db.mu.Lock()
	defer db.mu.Unlock()
	groupDB.mu.Lock()
	defer groupDB.mu.Unlock()
	for name := range db.data {
		if _, ok := groupDB.data[name]; !ok {
			delete(db.data, name)
		}
	}
	db.save()
}

func (db *SubDB) Count() int {
	db.mu.Lock()
	defer db.mu.Unlock()
	n := 0
	for _, v := range db.data {
		if v {
			n++
		}
	}
	return n
}

// ─── Article cache ──────────────────────────────────────────────────────────────

type ArticleCache struct {
	High     int       `json:"high"`
	Articles []Article `json:"articles"`
}

func cacheFilePath(dataDir, groupName string) string {
	safe := regexp.MustCompile(`[^a-zA-Z0-9._-]`).ReplaceAllString(groupName, "_")
	return filepath.Join(dataDir, "nntp_cache", safe+".json")
}

func readArticleCache(path string) *ArticleCache {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil
	}
	var c ArticleCache
	if err := json.Unmarshal(b, &c); err != nil {
		return nil
	}
	return &c
}

func writeArticleCache(path string, c *ArticleCache) {
	b, _ := json.MarshalIndent(c, "", "  ")
	_ = os.WriteFile(path, b, 0644)
}

// ─── Server ─────────────────────────────────────────────────────────────────────

type Server struct {
	cfg      Config
	cfgMu    sync.RWMutex
	sessions *SessionStore
	groups   *GroupDB
	subs     *SubDB
}

func newServer(cfg Config) *Server {
	_ = os.MkdirAll(filepath.Join(cfg.DataDir, "nntp_cache"), 0755)
	return &Server{
		cfg:      cfg,
		sessions: newSessionStore(filepath.Join(cfg.DataDir, "nntp_sessions.json"), cfg.SessionTTL),
		groups:   newGroupDB(filepath.Join(cfg.DataDir, "nntp_groups.json")),
		subs:     newSubDB(filepath.Join(cfg.DataDir, "nntp_subs.json")),
	}
}

func (s *Server) getCfg() Config {
	s.cfgMu.RLock()
	defer s.cfgMu.RUnlock()
	return s.cfg
}

func (s *Server) dialNNTP(user, pass string) (*NNTPClient, error) {
	cfg := s.getCfg()
	if user == "" {
		user = cfg.Username
		pass = cfg.Password
	}
	c, err := dialNNTP(cfg.Host, cfg.Port, cfg.Timeout)
	if err != nil {
		return nil, err
	}
	if err := c.Auth(user, pass); err != nil {
		c.Quit()
		return nil, err
	}
	return c, nil
}

// ─── HTTP helpers ───────────────────────────────────────────────────────────────

func sendJSON(w http.ResponseWriter, status int, v interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

func sendError(w http.ResponseWriter, status int, msg string) {
	sendJSON(w, status, map[string]string{"error": msg})
}

func bearerToken(r *http.Request) string {
	auth := r.Header.Get("Authorization")
	if strings.HasPrefix(auth, "Bearer ") {
		return strings.TrimSpace(auth[7:])
	}
	return ""
}

func readBody(r *http.Request, v interface{}) error {
	defer r.Body.Close()
	return json.NewDecoder(r.Body).Decode(v)
}

func qp(r *http.Request, key string) string {
	return r.URL.Query().Get(key)
}

// ─── Router ─────────────────────────────────────────────────────────────────────

func (s *Server) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	// CORS (allow local use from any origin)
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Headers", "Authorization, Content-Type")
	w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
	if r.Method == http.MethodOptions {
		w.WriteHeader(http.StatusNoContent)
		return
	}

	path := r.URL.Path

	// Serve embedded frontend
	if path == "/" || path == "/index.html" {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		_, _ = w.Write(indexHTML)
		return
	}

	// API routes under /api/
	if !strings.HasPrefix(path, "/api/") {
		http.NotFound(w, r)
		return
	}

	apiPath := strings.TrimPrefix(path, "/api")
	s.serveAPI(w, r, apiPath)
}

func (s *Server) serveAPI(w http.ResponseWriter, r *http.Request, path string) {
	s.sessions.prune()

	switch {
	case path == "/server-info" && r.Method == http.MethodGet:
		cfg := s.getCfg()
		sendJSON(w, 200, map[string]interface{}{"host": cfg.Host, "port": cfg.Port})

	case path == "/login" && r.Method == http.MethodPost:
		s.handleLogin(w, r)

	case path == "/logout" && r.Method == http.MethodPost:
		s.handleLogout(w, r)

	default:
		// All remaining routes require auth
		token := bearerToken(r)
		sess := s.sessions.Get(token)
		if sess == nil {
			sendError(w, 401, "Not authenticated")
			return
		}
		s.serveAuthed(w, r, path, sess)
	}
}

func (s *Server) serveAuthed(w http.ResponseWriter, r *http.Request, path string, sess *Session) {
	switch {
	case path == "/me" && r.Method == http.MethodGet:
		sendJSON(w, 200, map[string]string{"username": sess.Username, "displayName": sess.DisplayName})

	case path == "/config" && r.Method == http.MethodGet:
		cfg := s.getCfg()
		sendJSON(w, 200, map[string]interface{}{
			"host": cfg.Host, "port": cfg.Port,
			"maxHeaders": cfg.MaxHeaders, "timeout": cfg.Timeout,
		})

	case path == "/config" && r.Method == http.MethodPost:
		s.handleConfigSave(w, r)

	case path == "/config/test" && r.Method == http.MethodPost:
		s.handleConfigTest(w, r, sess)

	case path == "/groups" && r.Method == http.MethodGet:
		s.handleGroups(w, r, sess)

	case path == "/groups/sync" && r.Method == http.MethodPost:
		s.handleGroupsSync(w, r, sess)

	case path == "/groups/scan-new" && r.Method == http.MethodPost:
		s.handleGroupsScanNew(w, r, sess)

	case path == "/subscriptions" && r.Method == http.MethodGet:
		sendJSON(w, 200, s.subs.All())

	case path == "/subscriptions" && r.Method == http.MethodPost:
		s.handleSubscriptions(w, r)

	case strings.HasPrefix(path, "/groups/") && strings.HasSuffix(path, "/articles"):
		groupName := strings.TrimSuffix(strings.TrimPrefix(path, "/groups/"), "/articles")
		switch r.Method {
		case http.MethodGet:
			s.handleArticles(w, r, sess, groupName)
		case http.MethodPost:
			s.handlePost(w, r, sess, groupName)
		default:
			sendError(w, 405, "Method not allowed")
		}

	case strings.HasPrefix(path, "/groups/") && strings.Contains(path, "/articles/"):
		parts := strings.SplitN(strings.TrimPrefix(path, "/groups/"), "/articles/", 2)
		if len(parts) == 2 && r.Method == http.MethodGet {
			s.handleArticle(w, r, sess, parts[0], parts[1])
		} else {
			sendError(w, 405, "Method not allowed")
		}

	case path == "/stats" && r.Method == http.MethodGet:
		sendJSON(w, 200, map[string]int{
			"totalGroups": s.groups.Len(),
			"subscribed":  s.subs.Count(),
		})

	default:
		sendError(w, 404, "Not found")
	}
}

// ─── Handlers ───────────────────────────────────────────────────────────────────

func (s *Server) handleLogin(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Username    string `json:"username"`
		Password    string `json:"password"`
		DisplayName string `json:"displayName"`
	}
	if err := readBody(r, &body); err != nil {
		sendError(w, 400, "Invalid JSON")
		return
	}
	if body.Username == "" {
		sendError(w, 400, "Username required")
		return
	}
	if body.DisplayName == "" {
		body.DisplayName = body.Username
	}
	// Verify credentials by connecting
	c, err := s.dialNNTP(body.Username, body.Password)
	if err != nil {
		sendError(w, 401, "Login failed: "+err.Error())
		return
	}
	c.Quit()
	token := s.sessions.Create(body.Username, body.Password, body.DisplayName)
	sendJSON(w, 200, map[string]string{
		"token": token, "username": body.Username, "displayName": body.DisplayName,
	})
}

func (s *Server) handleLogout(w http.ResponseWriter, r *http.Request) {
	token := bearerToken(r)
	if token != "" {
		s.sessions.Delete(token)
	}
	sendJSON(w, 200, map[string]bool{"ok": true})
}

func (s *Server) handleConfigSave(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Host       *string `json:"host"`
		Port       *int    `json:"port"`
		MaxHeaders *int    `json:"maxHeaders"`
		Timeout    *int    `json:"timeout"`
	}
	if err := readBody(r, &body); err != nil {
		sendError(w, 400, "Invalid JSON")
		return
	}
	s.cfgMu.Lock()
	if body.Host != nil {
		s.cfg.Host = *body.Host
	}
	if body.Port != nil {
		s.cfg.Port = *body.Port
	}
	if body.MaxHeaders != nil {
		s.cfg.MaxHeaders = *body.MaxHeaders
	}
	if body.Timeout != nil {
		s.cfg.Timeout = *body.Timeout
	}
	cfg := s.cfg
	s.cfgMu.Unlock()
	saveConfig(cfg)
	sendJSON(w, 200, map[string]bool{"ok": true})
}

func (s *Server) handleConfigTest(w http.ResponseWriter, r *http.Request, sess *Session) {
	var body struct {
		Host string `json:"host"`
		Port int    `json:"port"`
	}
	_ = readBody(r, &body)
	cfg := s.getCfg()
	if body.Host == "" {
		body.Host = cfg.Host
	}
	if body.Port == 0 {
		body.Port = cfg.Port
	}
	c, err := dialNNTP(body.Host, body.Port, 8)
	if err != nil {
		sendJSON(w, 200, map[string]interface{}{"ok": false, "error": err.Error()})
		return
	}
	_ = c.Auth(sess.Username, sess.Password)
	c.Quit()
	sendJSON(w, 200, map[string]bool{"ok": true})
}

func (s *Server) handleGroups(w http.ResponseWriter, r *http.Request, sess *Session) {
	showAll := qp(r, "all") == "1"

	// Auto-fetch if DB is empty
	if s.groups.Len() == 0 {
		c, err := s.dialNNTP(sess.Username, sess.Password)
		if err != nil {
			sendError(w, 500, "Failed to fetch groups: "+err.Error())
			return
		}
		fresh, err := c.ListGroups()
		c.Quit()
		if err != nil {
			sendError(w, 500, err.Error())
			return
		}
		result := s.groups.Merge(fresh)
		for name := range result {
			s.subs.SetIfNew(name)
		}
		// auto-set new groups as subscribed
		for i := range fresh {
			s.subs.SetIfNew(fresh[i].Name)
		}
		s.subs.save()
	}

	all := s.groups.All()
	list := make([]*Group, 0, len(all))
	for _, g := range all {
		if showAll || s.subs.IsSubscribed(g.Name) {
			list = append(list, g)
		}
	}
	sort.Slice(list, func(i, j int) bool { return list[i].Name < list[j].Name })
	sendJSON(w, 200, list)
}

func (s *Server) handleGroupsSync(w http.ResponseWriter, r *http.Request, sess *Session) {
	replace := qp(r, "replace") == "1"
	c, err := s.dialNNTP(sess.Username, sess.Password)
	if err != nil {
		sendError(w, 500, err.Error())
		return
	}
	fresh, err := c.ListGroups()
	c.Quit()
	if err != nil {
		sendError(w, 500, err.Error())
		return
	}
	var result map[string]int
	if replace {
		result = s.groups.Replace(fresh)
		s.subs.RemoveAbsent(s.groups)
	} else {
		result = s.groups.Merge(fresh)
	}
	for i := range fresh {
		s.subs.SetIfNew(fresh[i].Name)
	}
	s.subs.save()
	sendJSON(w, 200, result)
}

func (s *Server) handleGroupsScanNew(w http.ResponseWriter, r *http.Request, sess *Session) {
	var body struct {
		Since string `json:"since"`
	}
	_ = readBody(r, &body)
	since := time.Now().Add(-7 * 24 * time.Hour)
	if body.Since != "" {
		if t, err := time.Parse(time.RFC3339, body.Since); err == nil {
			since = t
		}
	}
	c, err := s.dialNNTP(sess.Username, sess.Password)
	if err != nil {
		sendError(w, 500, err.Error())
		return
	}
	fresh, err := c.NewGroups(since)
	c.Quit()
	if err != nil {
		sendError(w, 500, err.Error())
		return
	}
	result := s.groups.Merge(fresh)
	result["found"] = len(fresh)
	sendJSON(w, 200, result)
}

func (s *Server) handleSubscriptions(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Updates map[string]bool `json:"updates"`
	}
	if err := readBody(r, &body); err != nil {
		sendError(w, 400, "Invalid JSON")
		return
	}
	s.subs.Update(body.Updates)
	sendJSON(w, 200, map[string]bool{"ok": true})
}

func (s *Server) handleArticles(w http.ResponseWriter, r *http.Request, sess *Session, groupName string) {
	noCache := qp(r, "nocache") == "1"
	cfg := s.getCfg()
	limit := cfg.MaxHeaders
	if ls := qp(r, "limit"); ls != "" {
		if n, err := strconv.Atoi(ls); err == nil {
			limit = n
		}
	}

	cf := cacheFilePath(cfg.DataDir, groupName)
	var cached *ArticleCache
	if !noCache {
		cached = readArticleCache(cf)
	}

	c, err := s.dialNNTP(sess.Username, sess.Password)
	if err != nil {
		sendError(w, 500, err.Error())
		return
	}
	defer c.Quit()

	info, err := c.SelectGroup(groupName)
	if err != nil {
		sendError(w, 500, err.Error())
		return
	}

	// Update group DB
	s.groups.Update(groupName, info)

	articles := make([]Article, 0)

	if info.Count == 0 {
		// articles already []Article{}
	} else if cached != nil && cached.High >= info.Low && !noCache {
		if cached.High >= info.High {
			articles = cached.Articles
		} else {
			newArts, err := c.GetOverview(cached.High+1, info.High)
			if err != nil {
				sendError(w, 500, err.Error())
				return
			}
			articles = append(cached.Articles, newArts...)
			if len(articles) > limit {
				articles = articles[len(articles)-limit:]
			}
			writeArticleCache(cf, &ArticleCache{High: info.High, Articles: articles})
		}
	} else {
		lo := int(math.Max(float64(info.Low), float64(info.High-limit+1)))
		articles, err = c.GetOverview(lo, info.High)
		if err != nil {
			sendError(w, 500, err.Error())
			return
		}
		writeArticleCache(cf, &ArticleCache{High: info.High, Articles: articles})
	}

	sendJSON(w, 200, articles)
}

func (s *Server) handleArticle(w http.ResponseWriter, r *http.Request, sess *Session, groupName, numOrID string) {
	c, err := s.dialNNTP(sess.Username, sess.Password)
	if err != nil {
		sendError(w, 500, err.Error())
		return
	}
	defer c.Quit()

	if _, err := c.SelectGroup(groupName); err != nil {
		sendError(w, 500, err.Error())
		return
	}
	art, err := c.GetArticle(numOrID)
	if err != nil {
		sendError(w, 500, err.Error())
		return
	}
	sendJSON(w, 200, art)
}

func (s *Server) handlePost(w http.ResponseWriter, r *http.Request, sess *Session, groupName string) {
	var body struct {
		Subject string   `json:"subject"`
		From    string   `json:"from"`
		RefID   string   `json:"refId"`
		Body    []string `json:"body"`
	}
	if err := readBody(r, &body); err != nil {
		sendError(w, 400, "Invalid JSON")
		return
	}
	if body.Subject == "" {
		sendError(w, 400, "subject required")
		return
	}
	if body.From == "" {
		sendError(w, 400, "from required")
		return
	}
	if len(body.Body) == 0 {
		sendError(w, 400, "body required")
		return
	}

	c, err := s.dialNNTP(sess.Username, sess.Password)
	if err != nil {
		sendError(w, 500, err.Error())
		return
	}
	defer c.Quit()

	if _, err := c.SelectGroup(groupName); err != nil {
		sendError(w, 500, err.Error())
		return
	}

	ok, err := c.Post(PostOptions{
		Newsgroups: groupName,
		Subject:    body.Subject,
		From:       body.From,
		RefID:      body.RefID,
		Body:       body.Body,
	})
	if err != nil {
		sendError(w, 500, err.Error())
		return
	}
	sendJSON(w, 200, map[string]bool{"ok": ok})
}

// ─── Main ────────────────────────────────────────────────────────────────────────

func main() {
	cfg := loadConfig()

	// CLI flag: --port overrides ini
	for i, arg := range os.Args[1:] {
		if (arg == "--port" || arg == "-port") && i+1 < len(os.Args[1:]) {
			if n, err := strconv.Atoi(os.Args[i+2]); err == nil {
				cfg.WebPort = n
			}
		}
		if (arg == "--config" || arg == "-config") && i+1 < len(os.Args[1:]) {
			configPath = os.Args[i+2]
			cfg = loadConfig()
		}
	}

	srv := newServer(cfg)

	addr := fmt.Sprintf(":%d", cfg.WebPort)
	log.Printf("NNTP Web Forum starting on http://localhost%s", addr)
	log.Printf("NNTP server: %s:%d", cfg.Host, cfg.Port)
	log.Printf("Data directory: %s", cfg.DataDir)

	httpSrv := &http.Server{
		Addr:         addr,
		Handler:      srv,
		ReadTimeout:  30 * time.Second,
		WriteTimeout: 120 * time.Second,
		BaseContext:  func(_ net.Listener) context.Context { return context.Background() },
	}

	if err := httpSrv.ListenAndServe(); err != nil {
		log.Fatal(err)
	}
}
