module telnetvision/service

go 1.24
