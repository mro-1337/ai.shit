package main

import (
	"os"
	"os/exec"
	"strings"
	"testing"
)

func TestEscapeWithFFmpeg(t *testing.T) {
	dir := os.Getenv("ESC_DIR")
	if dir == "" {
		t.Skip()
	}
	for _, src := range []string{dir + "/weird dir/Bob's [news], 9:30; part.ts", "http://127.0.0.1:8765/cc.ts"} {
		arg := "movie=" + escapeFilterArg(src) + "[out0+subcc]"
		out, _ := exec.Command("ffmpeg", "-hide_banner", "-loglevel", "error", "-real_time", "1", "-f", "lavfi", "-i", arg, "-map", "0:1", "-f", "srt", "-").CombinedOutput()
		if !strings.Contains(string(out), "CHANNEL NINE NEWS") {
			t.Errorf("%s\n  arg: %s\n  ffmpeg: %.300s", src, arg, out)
		}
	}
}
