//go:build windows

package main

import (
	"testing"
	"unsafe"
)

func TestInputRecordLayout(t *testing.T) {
	var r inputRecord
	if unsafe.Sizeof(r) != 20 || unsafe.Offsetof(r.keyDown) != 4 || unsafe.Offsetof(r.vk) != 10 || unsafe.Offsetof(r.char) != 14 || unsafe.Offsetof(r.ctrlState) != 16 {
		t.Fatalf("INPUT_RECORD layout wrong: size %d", unsafe.Sizeof(r))
	}
}
