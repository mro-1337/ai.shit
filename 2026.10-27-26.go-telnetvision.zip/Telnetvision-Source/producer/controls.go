package main

// Keyboard controls for the camera window: picture adjustments, a typing
// line for choosing a new source or a message for viewers, playlist
// skipping, and a help overlay.

import (
	"fmt"
	"strings"
	"sync"
	"time"
	"unicode/utf8"
)

type action struct{ kind, arg string } // "switch" | "add" | "next" | "prev"

type controls struct {
	mu       sync.Mutex
	sat      float64
	con      float64
	bri      int
	mode     string
	ramp     string
	preview  bool
	captions bool
	shuffle  bool

	prompt string // "" | "source" | "add" | "message"
	buf    []rune
	utf    []byte // a UTF-8 character split across reads

	message      string
	messageUntil time.Time // zero: stays until cleared
	messageSec   int
	helpOn       bool
	dirty        bool // something on screen needs redrawing now
	flash        string
	flashUntil   time.Time

	actions chan action
}

func newControls(cfg *Config) *controls {
	return &controls{sat: cfg.Saturation, con: cfg.Contrast, bri: cfg.Brightness,
		mode: cfg.Mode, ramp: cfg.Ramp, captions: true, shuffle: cfg.Shuffle, messageSec: cfg.MessageSec,
		actions: make(chan action, 8)}
}

func (c *controls) captionsOn() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.captions
}

func (c *controls) snapshot() (float64, float64, int, string, string, bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.sat, c.con, c.bri, c.mode, c.ramp, c.preview
}

// currentMessage is the typed message to show viewers now ("" for none).
func (c *controls) currentMessage(now time.Time) string {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.message != "" && !c.messageUntil.IsZero() && now.After(c.messageUntil) {
		c.message, c.dirty = "", true
	}
	return c.message
}

// promptLine returns the typing line being edited, if any.
func (c *controls) promptLine() (label, text string, on bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.prompt == "" {
		return "", "", false
	}
	return promptLabels[c.prompt], string(c.buf), true
}

var promptLabels = map[string]string{
	"source":  "Play (file, folder, URL, camera, screen, test): ",
	"add":     "Add file or folder to the playlist: ",
	"message": "Message for viewers (empty = clear): ",
}

// flashText is a short note shown on the status line after a key press.
func (c *controls) flashText() string {
	c.mu.Lock()
	defer c.mu.Unlock()
	if time.Now().After(c.flashUntil) {
		return ""
	}
	return c.flash
}

func (c *controls) helpShown() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.helpOn
}

// takeDirty reports (and clears) whether the screen needs redrawing.
func (c *controls) takeDirty() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	d := c.dirty
	c.dirty = false
	return d
}

func (c *controls) markDirty() {
	c.mu.Lock()
	c.dirty = true
	c.mu.Unlock()
}

func round1(v float64) float64 { return float64(int(v*10+0.5*sign(v))) / 10 }
func sign(v float64) float64 {
	if v < 0 {
		return -1
	}
	return 1
}

func (c *controls) send(a action) {
	select {
	case c.actions <- a:
	default:
	}
}

// key applies one input byte; returns true to quit.
func (c *controls) key(k byte) bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.dirty = true
	if c.prompt != "" {
		c.typed(k)
		return false
	}
	switch k {
	case '+', '=':
		c.sat = round1(min(3, c.sat+0.1))
	case '-', '_':
		c.sat = round1(max(0, c.sat-0.1))
	case ']':
		c.con = round1(min(3, c.con+0.1))
	case '[':
		c.con = round1(max(0.1, c.con-0.1))
	case '.', '>':
		c.bri = min(128, c.bri+8)
	case ',', '<':
		c.bri = max(-128, c.bri-8)
	case 'm', 'M':
		c.mode = map[string]string{"half": "ramp", "ramp": "half"}[c.mode]
	case 'g', 'G':
		c.ramp = map[string]string{"ascii": "shades", "shades": "ascii"}[c.ramp]
	case '0':
		c.sat, c.con, c.bri = 1, 1, 0
	case 'p', 'P':
		c.preview = !c.preview
	case 'c', 'C':
		c.captions = !c.captions
	case 's', 'S':
		c.prompt, c.buf = "source", nil
	case 'a', 'A':
		c.prompt, c.buf = "add", nil
	case 't', 'T':
		c.prompt, c.buf = "message", []rune(c.message)
	case 'x', 'X':
		if c.message != "" {
			c.flash, c.flashUntil = "message cleared", time.Now().Add(3*time.Second)
		}
		c.message = ""
	case 'r', 'R':
		c.shuffle = !c.shuffle
		on := map[bool]string{true: "on", false: "off"}[c.shuffle]
		c.send(action{kind: "shuffle", arg: on})
		c.flash, c.flashUntil = "shuffle "+on, time.Now().Add(3*time.Second)
	case 'n', 'N':
		c.send(action{kind: "next"})
		c.flash, c.flashUntil = ">> skipping to the next video...", time.Now().Add(2*time.Second)
	case 'b', 'B':
		c.send(action{kind: "prev"})
		c.flash, c.flashUntil = "<< going back a video...", time.Now().Add(2*time.Second)
	case 'h', 'H', '?':
		c.helpOn = !c.helpOn
	case 27: // Esc closes the help; it never quits, so a stray Esc can't end the broadcast
		c.helpOn = false
	case 'q', 'Q':
		if c.helpOn {
			c.helpOn = false // with the help open, Q just closes it
			return false
		}
		return true
	}
	return false
}

// paste takes a burst of typed text - a file or folder dropped on the
// window, or a paste - and reports whether it handled it. With a typing
// line open the text goes into it; otherwise it opens the Play line with
// the path filled in, ready for Enter (or Esc to cancel).
func (c *controls) paste(b []byte) bool {
	printable := 0
	for _, k := range b {
		if k >= 32 && k != 127 {
			printable++
		}
	}
	if printable < 4 { // a person typing: one or two keys at a time
		return false
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	c.dirty = true
	if c.prompt != "" {
		for _, k := range b {
			c.typed(k)
		}
		return true
	}
	text := strings.TrimSpace(strings.Map(func(r rune) rune {
		if r < 32 || r == 127 {
			return -1
		}
		return r
	}, string(b)))
	text = strings.Trim(text, `"`) // Explorer quotes paths with spaces
	if text == "" {
		return true
	}
	c.prompt, c.buf, c.utf = "source", []rune(text), nil
	c.flash, c.flashUntil = "Dropped: press Enter to play it now, Esc to cancel", time.Now().Add(6*time.Second)
	return true
}

// typed edits the typing line. Called with c.mu held.
func (c *controls) typed(k byte) {
	c.utf = append(c.utf, k)
	for len(c.utf) > 0 {
		if !utf8.FullRune(c.utf) {
			return // wait for the rest of this character
		}
		r, size := utf8.DecodeRune(c.utf)
		c.utf = c.utf[size:]
		switch {
		case r == '\r' || r == '\n':
			c.commit()
			return
		case r == 27: // Esc: cancel
			c.prompt, c.buf, c.utf = "", nil, nil
			return
		case r == 8 || r == 127: // Backspace
			if len(c.buf) > 0 {
				c.buf = c.buf[:len(c.buf)-1]
			}
		case r == 21: // Ctrl+U: clear the line
			c.buf = nil
		case r == utf8.RuneError && size == 1, r < 32:
			// ignore other control keys
		default:
			if len(c.buf) < 1000 {
				c.buf = append(c.buf, r)
			}
		}
	}
}

// commit finishes the typing line. Called with c.mu held.
func (c *controls) commit() {
	text := strings.TrimSpace(string(c.buf))
	kind := c.prompt
	c.prompt, c.buf, c.utf = "", nil, nil
	switch kind {
	case "message":
		c.message = text
		c.messageUntil = time.Time{}
		if text != "" && c.messageSec > 0 {
			c.messageUntil = time.Now().Add(time.Duration(c.messageSec) * time.Second)
		}
		switch {
		case text == "":
			c.flash = "message cleared"
		case c.messageSec > 0:
			c.flash = fmt.Sprintf("message on viewers' screens for %d s (X clears)", c.messageSec)
		default:
			c.flash = "message on viewers' screens until you clear it (X)"
		}
		c.flashUntil = time.Now().Add(4 * time.Second)
	case "source":
		if text != "" {
			c.send(action{kind: "switch", arg: text})
		}
	case "add":
		if text != "" {
			c.send(action{kind: "add", arg: text})
		}
	}
}

var helpLines = padLines([]string{
	" KEYS                                      H or Esc closes ",
	"",
	"  S    Play something else: file, folder, URL, camera",
	"  A    Add a file or folder to the end of the playlist",
	"  N    Next video              B    Back a video",
	"  R    Shuffle on / off",
	"",
	"  T    Type a message for viewers (Enter shows it)",
	"  X    Clear the message",
	"",
	"  C    Captions on / off       P    Preview on / off",
	"  + -  Saturation              [ ]  Contrast",
	"  < >  Brightness              0    Reset the picture",
	"  M    Block / text style      G    Text characters",
	"",
	"  Q    Quit",
	"",
	"  Tip: drop a file or folder on this window, then Enter.",
})

// padLines makes every line the same width, so the help box is even.
func padLines(l []string) []string {
	w := 0
	for _, s := range l {
		if len(s) > w {
			w = len(s)
		}
	}
	for i, s := range l {
		l[i] = s + strings.Repeat(" ", w+1-len(s))
	}
	return l
}

// combineCaption puts a typed message above the subtitles, keeping the
// whole caption to three lines.
func combineCaption(message string, caption []byte) []byte {
	if message == "" {
		return caption
	}
	if len(caption) == 0 {
		return []byte(message)
	}
	lines := strings.Split(string(caption), "\n")
	if len(lines) > 2 {
		lines = lines[len(lines)-2:]
	}
	return []byte(message + "\n" + strings.Join(lines, "\n"))
}
