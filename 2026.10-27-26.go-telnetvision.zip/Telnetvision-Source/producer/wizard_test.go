package main

import "testing"

func TestCurrentOptions(t *testing.T) {
	devs := []Device{{"Integrated Webcam", "video"}, {"SplitCam Video Driver", "video"},
		{"Microphone (Realtek Audio)", "audio"}, {"Microphone (SplitCam Audio Mixer)", "audio"}}
	for src, want := range map[string]string{
		"camera:SplitCam": "camera:SplitCam Video Driver", "camera": "camera:Integrated Webcam",
		"1": "camera:SplitCam Video Driver", "screen": "screen", "camera:nothing": "",
	} {
		if got := currentVideoOption(src, devs); got != want {
			t.Errorf("video %q: got %q want %q", src, got, want)
		}
	}
	for src, want := range map[string]string{
		"mic:SplitCam Audio Mixer": "mic:Microphone (SplitCam Audio Mixer)",
		"mic":                      "mic:Microphone (Realtek Audio)",
		":realtek":                 "mic:Microphone (Realtek Audio)",
		"mic:unplugged usb mic":    "",
	} {
		if got := currentAudioOption(src, devs, false); got != want {
			t.Errorf("audio %q: got %q want %q", src, got, want)
		}
	}
	if currentAudioOption("auto", devs, true) != "auto" {
		t.Error("auto with a file source")
	}
}
