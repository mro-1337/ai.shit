package main

// Subtitles and closed captions.
//
// Where captions can come from (SUBTITLES=auto picks the first that exists):
//   1. CAPTION_FILE - a text file whose last line is shown (live speech-to-
//      text and the like). Always wins while it has text.
//   2. A sidecar file next to a video file: movie.srt, movie.en.srt, movie.vtt
//   3. A text subtitle track inside the file or stream (mkv/mp4/ts)
//   4. Closed captions (EIA-608/CEA-708) carried in the video itself, as in
//      US broadcast TV, HDHomeRun tuners and recorded .ts files
//
// Tracks and closed captions are pulled out by the same ffmpeg process that
// decodes the video, written as SRT to a local socket, so they share the
// video's clock.

import (
	"bufio"
	"context"
	"fmt"
	"html"
	"math"
	"net"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"
)

type subCue struct {
	start, end float64 // seconds on the stream clock
	text       string
}

// Subtitles holds the caption state shared by the ffmpeg reader and the
// frame loop.
type Subtitles struct {
	mode  string // "" | "sidecar" | "track" | "cc"
	desc  string
	track int // for mode "track": index among the source's subtitle streams

	mu       sync.Mutex
	cues     []subCue  // sidecar / track
	period   float64   // sidecar: file duration, so cues repeat as the file loops
	anchor   time.Time // when the current ffmpeg run's first frame arrived
	liveText string    // cc: the caption on screen right now
	liveAt   time.Time
}

// ffmpegStreams is what a quick ffmpeg probe found in a source.
type ffmpegStreams struct {
	hasAudio   bool
	duration   float64
	textSubs   []string // "index:lang:codec" per subtitle stream, in order
	bitmapSubs int
	hasCC      bool
}

var (
	reDuration = regexp.MustCompile(`Duration: (\d+):(\d+):(\d+(?:\.\d+)?)`)
	reSubLine  = regexp.MustCompile(`Stream #\d+:\d+(?:\[[^\]]*\])?(?:\(([a-z]{2,3})\))?.*?: Subtitle: ([a-z0-9_]+)`)
)

var textSubCodecs = map[string]bool{
	"subrip": true, "srt": true, "ass": true, "ssa": true, "mov_text": true,
	"webvtt": true, "text": true, "eia_608": true, "microdvd": true,
	"subviewer": true, "subviewer1": true, "sami": true, "realtext": true,
	"jacosub": true, "mpl2": true, "pjs": true, "stl": true, "vplayer": true,
}

var probeCache struct {
	sync.Mutex
	m map[string]probeEntry
}

type probeEntry struct {
	st ffmpegStreams
	at time.Time
}

// probeStreams asks ffmpeg what's in a source. Results are kept for a few
// minutes so each file is only checked once per play.
func probeStreams(ctx context.Context, ffmpeg, src string) ffmpegStreams {
	probeCache.Lock()
	if e, ok := probeCache.m[src]; ok && time.Since(e.at) < 5*time.Minute {
		probeCache.Unlock()
		return e.st
	}
	probeCache.Unlock()
	st := probeStreamsUncached(ctx, ffmpeg, src)
	if ctx.Err() == nil {
		probeCache.Lock()
		if probeCache.m == nil {
			probeCache.m = map[string]probeEntry{}
		}
		probeCache.m[src] = probeEntry{st, time.Now()}
		probeCache.Unlock()
	}
	return st
}

func probeStreamsUncached(ctx context.Context, ffmpeg, src string) ffmpegStreams {
	ctx, cancel := context.WithTimeout(ctx, 25*time.Second)
	defer cancel()
	cmd := ffmpegCommand(ctx, ffmpeg, "-hide_banner", "-nostdin", "-i", src)
	out, _ := cmd.CombinedOutput() // exits non-zero: no output file given
	var st ffmpegStreams
	text := string(out)
	if m := reDuration.FindStringSubmatch(text); m != nil {
		h, _ := strconv.ParseFloat(m[1], 64)
		mi, _ := strconv.ParseFloat(m[2], 64)
		s, _ := strconv.ParseFloat(m[3], 64)
		st.duration = h*3600 + mi*60 + s
	}
	n := 0
	for _, line := range strings.Split(text, "\n") {
		if strings.Contains(line, "Stream #") && strings.Contains(line, ": Audio:") {
			st.hasAudio = true
		}
		if strings.Contains(line, "Video:") && strings.Contains(line, "Closed Captions") {
			st.hasCC = true
		}
		if m := reSubLine.FindStringSubmatch(line); m != nil {
			if textSubCodecs[m[2]] {
				st.textSubs = append(st.textSubs, fmt.Sprintf("%d:%s:%s", n, m[1], m[2]))
			} else {
				st.bitmapSubs++
				st.textSubs = append(st.textSubs, fmt.Sprintf("%d:%s:%s:bitmap", n, m[1], m[2]))
			}
			n++
		}
	}
	return st
}

// findSidecar looks for movie.srt, movie.<lang>.srt, movie.vtt next to path.
func findSidecar(path string) string {
	base := strings.TrimSuffix(path, filepath.Ext(path))
	for _, ext := range []string{".srt", ".vtt"} {
		if fileExists(base + ext) {
			return base + ext
		}
	}
	matches, _ := filepath.Glob(globEscape(base) + ".*.srt")
	if len(matches) == 0 {
		matches, _ = filepath.Glob(globEscape(base) + ".*.vtt")
	}
	// Prefer English when several languages sit side by side.
	for _, m := range matches {
		l := strings.ToLower(m)
		if strings.Contains(l, ".en.") || strings.Contains(l, ".eng.") {
			return m
		}
	}
	if len(matches) > 0 {
		return matches[0]
	}
	return ""
}

func globEscape(s string) string {
	r := strings.NewReplacer("[", "[[]", "*", "[*]", "?", "[?]")
	return r.Replace(s)
}

// pickTrack chooses a subtitle stream by number ("1") or language ("eng").
func pickTrack(subs []string, want string) (int, string, bool) {
	want = strings.ToLower(strings.TrimSpace(want))
	usable := func(s string) bool { return !strings.HasSuffix(s, ":bitmap") }
	if want != "" {
		if n, err := strconv.Atoi(want); err == nil {
			if n >= 0 && n < len(subs) && usable(subs[n]) {
				return n, subs[n], true
			}
			return 0, "", false
		}
		for i, s := range subs {
			f := strings.Split(s, ":")
			if usable(s) && (f[1] == want || strings.HasPrefix(f[1], want) || strings.HasPrefix(want, f[1]) && f[1] != "") {
				return i, s, true
			}
		}
	}
	for i, s := range subs {
		if usable(s) {
			return i, s, true
		}
	}
	return 0, "", false
}

// setupSubtitles decides where captions come from for this source.
func setupSubtitles(ctx context.Context, cfg *Config, ffmpeg string, logf func(string, ...any)) *Subtitles {
	setting := strings.TrimSpace(cfg.Subtitles)
	low := strings.ToLower(setting)
	if low == "off" || low == "0" || low == "no" || ffmpeg == "" {
		return nil
	}
	src := cfg.Source
	lowSrc := strings.ToLower(src)
	isFile := fileExists(src)
	isNet := isURL(src)
	if !isFile && !isNet {
		if low != "" && low != "auto" && fileExists(setting) {
			// A subtitle file with a live source makes no sense to time.
			logf("subtitles: SUBTITLES=%s needs a video file as SOURCE; ignoring", setting)
		}
		_ = lowSrc
		return nil
	}

	// An explicit subtitle file.
	if low != "" && low != "auto" && low != "cc" && !strings.HasPrefix(low, "track") {
		if !fileExists(setting) {
			logf("subtitles: file %s not found", setting)
			return nil
		}
		return loadSidecar(ctx, setting, src, ffmpeg, logf)
	}

	if (low == "" || low == "auto") && isFile {
		if sc := findSidecar(src); sc != "" {
			if s := loadSidecar(ctx, sc, src, ffmpeg, logf); s != nil {
				return s
			}
		}
	}

	if isNet {
		logf("checking the stream for subtitles and closed captions...")
	}
	st := probeStreams(ctx, ffmpeg, src)
	wantCC := low == "cc"
	wantTrack := strings.HasPrefix(low, "track")
	if !wantCC {
		if i, info, ok := pickTrack(st.textSubs, cfg.SubtitleTrack); ok {
			f := strings.Split(info, ":")
			lang := f[1]
			if lang == "" {
				lang = "unknown language"
			}
			desc := fmt.Sprintf("subtitle track %d (%s, %s)", i, lang, f[2])
			if isFile {
				// Read the whole track out in a quick separate pass instead
				// of riding the playing ffmpeg: a sparse subtitle output in
				// the same run can stall picture and sound in newer ffmpeg.
				s := &Subtitles{mode: "sidecar", desc: desc, period: st.duration}
				logf("subtitles: %s (reading it out of the file...)", desc)
				go s.extractTrack(ctx, ffmpeg, src, i, logf)
				return s
			}
			s := &Subtitles{mode: "track", track: i, desc: desc}
			logf("subtitles: %s", s.desc)
			return s
		}
		if wantTrack {
			logf("subtitles: no usable text subtitle track found")
		}
	}
	if st.hasCC || wantCC {
		s := &Subtitles{mode: "cc", desc: "closed captions"}
		logf("subtitles: %s", s.desc)
		return s
	}
	if st.bitmapSubs > 0 {
		logf("subtitles: this file only has picture-based subtitles (DVD/Blu-ray), which can't be shown as text; put a .srt file next to it instead")
	} else if isNet {
		logf("subtitles: none found in the stream")
	}
	return nil
}

// extractTrack reads text subtitle track i out of a file (demuxing only, no
// decoding, so it takes seconds) and makes its lines the captions.
func (s *Subtitles) extractTrack(ctx context.Context, ffmpeg, src string, i int, logf func(string, ...any)) {
	cmd := ffmpegCommand(ctx, ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin",
		"-i", src, "-map", fmt.Sprintf("0:s:%d", i), "-c:s", "srt", "-f", "srt", "-")
	out, err := cmd.Output()
	if ctx.Err() != nil {
		return
	}
	cues := parseSubtitleFile(string(out))
	if len(cues) == 0 {
		logf("subtitles: couldn't read %s (%v)", s.desc, err)
		return
	}
	s.mu.Lock()
	s.cues = cues
	s.mu.Unlock()
	logf("subtitles: %s ready (%d lines)", s.desc, len(cues))
}

func loadSidecar(ctx context.Context, path, src, ffmpeg string, logf func(string, ...any)) *Subtitles {
	data, err := os.ReadFile(path)
	if err != nil {
		logf("subtitles: can't read %s: %v", path, err)
		return nil
	}
	cues := parseSubtitleFile(string(data))
	if len(cues) == 0 {
		logf("subtitles: no cues found in %s", filepath.Base(path))
		return nil
	}
	s := &Subtitles{mode: "sidecar", cues: cues, desc: "subtitle file " + filepath.Base(path)}
	s.period = probeStreams(ctx, ffmpeg, src).duration
	logf("subtitles: %s (%d lines)", s.desc, len(cues))
	return s
}

var reTime = regexp.MustCompile(`(?:(\d+):)?(\d{1,2}):(\d{2})[,.](\d{1,3})\s*-->\s*(?:(\d+):)?(\d{1,2}):(\d{2})[,.](\d{1,3})`)

func ts(h, m, s, ms string) float64 {
	hh, _ := strconv.Atoi(h)
	mm, _ := strconv.Atoi(m)
	ss, _ := strconv.Atoi(s)
	frac, _ := strconv.Atoi((ms + "00")[:3])
	return float64(hh*3600+mm*60+ss) + float64(frac)/1000
}

// parseSubtitleFile reads SRT or WebVTT.
func parseSubtitleFile(data string) []subCue {
	data = strings.TrimPrefix(strings.ReplaceAll(data, "\r", ""), "\ufeff")
	var cues []subCue
	for _, block := range strings.Split(data, "\n\n") {
		lines := strings.Split(strings.Trim(block, "\n"), "\n")
		for i, l := range lines {
			m := reTime.FindStringSubmatch(l)
			if m == nil {
				continue
			}
			c := subCue{start: ts(m[1], m[2], m[3], m[4]), end: ts(m[5], m[6], m[7], m[8])}
			c.text = cleanCaption(strings.Join(lines[i+1:], "\n"))
			if c.text != "" && c.end > c.start {
				cues = append(cues, c)
			}
			break
		}
	}
	return cues
}

var (
	reTags     = regexp.MustCompile(`<[^>]*>`)
	reASS      = regexp.MustCompile(`\{\\[^}]*\}`)
	reSpaces   = regexp.MustCompile(`[ \t]+`)
	reASSBreak = strings.NewReplacer(`\N`, "\n", `\n`, "\n", `\h`, " ")
)

// cleanCaption strips styling and keeps at most the last three lines.
func cleanCaption(t string) string {
	t = reASSBreak.Replace(t)
	t = reASS.ReplaceAllString(t, "")
	t = reTags.ReplaceAllString(t, "")
	t = html.UnescapeString(t)
	var lines []string
	for _, l := range strings.Split(t, "\n") {
		l = strings.TrimSpace(reSpaces.ReplaceAllString(l, " "))
		if l != "" {
			lines = append(lines, l)
		}
	}
	if len(lines) > 3 {
		lines = lines[len(lines)-3:]
	}
	return strings.Join(lines, "\n")
}

// Current returns the caption to show now ("" for none).
func (s *Subtitles) Current(now time.Time) string {
	if s == nil {
		return ""
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	switch s.mode {
	case "cc":
		// Captions stay up until the broadcast clears or replaces them;
		// drop anything stale if the stream stops updating.
		if now.Sub(s.liveAt) > 20*time.Second {
			return ""
		}
		return s.liveText
	case "track", "sidecar":
		if s.anchor.IsZero() {
			return ""
		}
		pos := now.Sub(s.anchor).Seconds()
		if s.mode == "sidecar" && s.period > 1 {
			pos = math.Mod(pos, s.period)
		}
		for _, c := range s.cues {
			if pos >= c.start && pos < c.end {
				return c.text
			}
		}
	}
	return ""
}

// startRun is called for every new ffmpeg run, at its first video frame.
func (s *Subtitles) startRun(now time.Time) {
	if s == nil {
		return
	}
	s.mu.Lock()
	s.anchor = now
	if s.mode == "track" {
		s.cues = nil // timestamps restart with the new run
	}
	s.liveText = ""
	s.mu.Unlock()
}

// ffmpegArgs returns the input and the extra subtitle output for one run,
// given the normal video input. port is the local socket ffmpeg writes to.
func (s *Subtitles) ffmpegArgs(cfg *Config, input []string, port int) (in, videoMap, subOut []string) {
	out := []string{"-c:s", "srt", "-flush_packets", "1", "-f", "srt",
		fmt.Sprintf("tcp://127.0.0.1:%d?tcp_nodelay=1", port)}
	switch s.mode {
	case "track":
		return input, []string{"-map", "0:v:0"}, append([]string{"-map", fmt.Sprintf("0:s:%d", s.track)}, out...)
	case "cc":
		// The movie filter exposes the captions in the video as a stream;
		// real_time shows each caption the moment it appears on screen.
		in = []string{}
		if fileExists(cfg.Source) {
			in = append(in, "-re")
		}
		in = append(in, "-real_time", "1", "-f", "lavfi", "-i", "movie="+escapeFilterArg(cfg.Source)+"[out0+subcc]")
		return in, []string{"-map", "0:0"}, append([]string{"-map", "0:1"}, out...)
	}
	return input, nil, nil
}

// escapeFilterArg quotes a path or URL for use as a filter option inside a
// filtergraph (two levels of ffmpeg escaping).
func escapeFilterArg(p string) string {
	if len(p) > 2 && p[1] == ':' && !isURL(p) {
		p = filepath.ToSlash(p) // C:\Videos\x.ts -> C:/Videos/x.ts
		p = strings.ReplaceAll(p, `\`, "/")
	}
	lvl1 := strings.NewReplacer(`\`, `\\`, `'`, `\'`, `:`, `\:`).Replace(p)
	return strings.NewReplacer(`\`, `\\`, `'`, `\'`, `[`, `\[`, `]`, `\]`, `,`, `\,`, `;`, `\;`).Replace(lvl1)
}

// readSRT parses the SRT ffmpeg streams to us.
func (s *Subtitles) readSRT(conn net.Conn, logf func(string, ...any)) {
	defer conn.Close()
	sc := bufio.NewScanner(conn)
	sc.Buffer(make([]byte, 64<<10), 1<<20)
	var block []string
	flush := func() {
		defer func() { block = block[:0] }()
		for i, l := range block {
			m := reTime.FindStringSubmatch(l)
			if m == nil {
				continue
			}
			c := subCue{start: ts(m[1], m[2], m[3], m[4]), end: ts(m[5], m[6], m[7], m[8])}
			c.text = cleanCaption(strings.Join(block[i+1:], "\n"))
			s.mu.Lock()
			if s.mode == "cc" {
				s.liveText, s.liveAt = c.text, time.Now() // empty text clears
			} else if c.text != "" {
				s.cues = append(s.cues, c)
				// Keep memory flat on long streams.
				if len(s.cues) > 400 {
					s.cues = s.cues[len(s.cues)-200:]
				}
			}
			s.mu.Unlock()
			return
		}
	}
	for sc.Scan() {
		l := strings.TrimRight(sc.Text(), "\r")
		if l == "" {
			if len(block) > 0 {
				flush()
			}
			continue
		}
		block = append(block, l)
	}
	if len(block) > 0 {
		flush()
	}
}
