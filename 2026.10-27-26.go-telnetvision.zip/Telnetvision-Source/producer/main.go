// Telnetvision producer for Windows: captures a webcam, the screen, a video
// file or a stream with ffmpeg, color-grades it, and pushes it to a
// Telnetvision relay (service.exe) so BBS callers can watch it as ANSI art.
//
// A single-.exe Go port of producer.py + stream-source.bat from
// https://github.com/hmderdoc/telnetvision, using the same wire protocol.
package main

import (
	"bufio"
	"context"
	"flag"
	"fmt"
	"os"
	"os/signal"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

const version = "1.1.0"

// logger writes to telnetvision.log next to the exe and keeps the latest
// message for the on-screen status area.
type logger struct {
	mu     sync.Mutex
	f      *os.File
	last   string
	screen bool // print directly (no preview occupying the screen)
	out    func(string)
}

func newLogger() *logger {
	l := &logger{screen: true}
	path := filepath.Join(exeDir(), "telnetvision.log")
	if st, err := os.Stat(path); err == nil && st.Size() > 1<<20 {
		os.Rename(path, path+".old")
	}
	l.f, _ = os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	return l
}

func (l *logger) printf(format string, a ...any) {
	msg := fmt.Sprintf(format, a...)
	l.mu.Lock()
	defer l.mu.Unlock()
	l.last = time.Now().Format("15:04:05 ") + msg
	if l.f != nil {
		fmt.Fprintf(l.f, "%s %s\n", time.Now().Format("2006-01-02 15:04:05"), msg)
	}
	if l.screen {
		line := fmt.Sprintf("\r%s%s\n", clearLine(), l.last)
		if l.out != nil {
			l.out(line)
		} else {
			fmt.Print(line)
		}
	}
	logRedraw.Store(true)
}

func (l *logger) lastMsg() string {
	l.mu.Lock()
	defer l.mu.Unlock()
	return l.last
}

func (l *logger) setScreen(on bool) {
	l.mu.Lock()
	l.screen = on
	l.mu.Unlock()
}

var pauseOnExit bool

// logRedraw: a log line was printed, so the typing line needs redrawing.
var logRedraw atomic.Bool

// ansiOK is false on old Windows consoles without escape-code support.
var ansiOK = true

func clearLine() string {
	if ansiOK {
		return "\x1b[K"
	}
	return strings.Repeat(" ", 79) + "\r"
}

func fatal(format string, a ...any) {
	fmt.Fprintf(os.Stderr, "\nERROR: "+format+"\n", a...)
	if pauseOnExit {
		fmt.Fprint(os.Stderr, "\nPress Enter to close...")
		bufio.NewReader(os.Stdin).ReadString('\n')
	}
	os.Exit(1)
}

func main() {
	interactive := isConsole()
	pauseOnExit = interactive && launchedByDoubleClick()
	setTitle("Telnetvision")

	cfg := defaultConfig()
	fs := flag.NewFlagSet("telnetvision", flag.ContinueOnError)
	fs.Usage = func() {
		fmt.Fprintf(os.Stderr, `Telnetvision %s - stream a webcam, screen or video to your BBS as ANSI art.

Just double-click telnetvision.exe: the first run asks a few questions and
saves them to telnetvision.ini. After that it starts streaming right away.

Options (all optional; they override telnetvision.ini for this run):
`, version)
		fs.PrintDefaults()
		fmt.Fprint(os.Stderr, `
Keys while running (H shows them on screen):
  S  play something else (file, folder, URL, camera, screen, test)
  A  add a file or folder to the playlist     N / B  next / previous video
  T  type a message for viewers               X  clear the message
  + -  saturation   [ ]  contrast   < >  brightness   0  reset
  M  half-block / text style   G  text glyphs   C  captions   P  preview
  Q  quit
`)
	}
	setup := fs.Bool("setup", false, "run the setup questions again")
	cfgPath := fs.String("config", "", "settings file (default: telnetvision.ini next to the exe)")
	listDev := fs.Bool("list-devices", false, "list cameras and microphones, then exit")
	frames := fs.Int("frames", 0, "stop after N frames (0 = run forever)")
	showVer := fs.Bool("version", false, "print version and exit")
	ov := map[string]*string{}
	for _, k := range []struct{ flag, key, help string }{
		{"host", "BBS_HOST", "server host"},
		{"port", "BBS_PORT", "server feed port"},
		{"token", "TOKEN", "server token"},
		{"channel", "CHANNEL", "channel name"},
		{"tls", "TLS", "1 = TLS, 0 = plaintext"},
		{"insecure", "INSECURE", "1 = accept self-signed certs"},
		{"source", "SOURCE", "camera | camera:<name> | screen | test | <file> | <url> | -"},
		{"in-size", "IN_SIZE", "WxH of raw rgb24 frames on stdin (SOURCE=-)"},
		{"flip", "FLIP", "auto | 1 | 0"},
		{"cols", "COLS", "picture width in characters"},
		{"rows", "ROWS", "picture height in characters"},
		{"fps", "FPS", "frames per second"},
		{"mode", "MODE", "half | ramp"},
		{"ramp", "RAMP", "ascii | shades"},
		{"caption-file", "CAPTION_FILE", "live caption text file (last line is shown)"},
		{"subtitles", "SUBTITLES", "auto | off | cc | track | <file.srt or .vtt>"},
		{"subtitle-track", "SUBTITLE_TRACK", "which subtitle track: number or language (eng, spa...)"},
		{"audio", "AUDIO", "1 = stream sound"},
		{"audio-source", "AUDIO_SOURCE", "auto | mic | mic:<name> | <file/url>"},
		{"ffmpeg", "FFMPEG", "path to ffmpeg.exe"},
		{"preview", "PREVIEW", "1 = live preview in this window"},
	} {
		ov[k.key] = fs.String(k.flag, "", k.help)
	}
	if err := fs.Parse(os.Args[1:]); err != nil {
		if err == flag.ErrHelp {
			return
		}
		fatal("%v", err)
	}
	if *showVer {
		fmt.Println("telnetvision", version)
		return
	}

	// Find settings: --config, else telnetvision.ini, else an upstream .env.
	path := *cfgPath
	if path == "" {
		path = filepath.Join(exeDir(), "telnetvision.ini")
	}
	loaded := false
	if _, err := os.Stat(path); err == nil {
		// Add settings introduced since this file was made, at their
		// defaults, so they're there to edit. Nothing else is touched.
		def := defaultConfig()
		upgradeINI(path, def.template(), iniAliases, nil, true, "telnetvision "+version,
			func(f string, a ...any) { fmt.Printf(f+"\n", a...) })
	}
	if err := cfg.loadFile(path); err == nil {
		loaded = true
	} else if !os.IsNotExist(err) {
		fatal("%v", err)
	} else if *cfgPath == "" {
		for _, env := range []string{filepath.Join(exeDir(), ".env"), ".env"} {
			if err := cfg.loadFile(env); err == nil {
				loaded = true
				break
			}
		}
	}
	for key, v := range ov {
		if *v != "" {
			if err := cfg.set(key, *v); err != nil {
				fatal("%v", err)
			}
		}
	}

	if *listDev {
		ff, err := findFFmpeg(&cfg)
		if err != nil {
			fatal("%v", err)
		}
		devs, _ := listDevices(ff)
		if len(devs) == 0 {
			fmt.Println("No DirectShow devices found (or not on Windows).")
		}
		for _, kind := range []string{"video", "audio"} {
			fmt.Printf("%s devices:\n", strings.ToUpper(kind[:1])+kind[1:])
			for _, d := range devs {
				if d.Kind == kind {
					fmt.Printf("  %s\n", d.Name)
				}
			}
		}
		if pauseOnExit {
			fmt.Print("\nPress Enter to close...")
			bufio.NewReader(os.Stdin).ReadString('\n')
		}
		return
	}

	// Ask the setup questions on request, or when there are no settings
	// yet and the command line didn't supply the essentials either.
	if *setup || (!loaded && cfg.validate() != nil) {
		if !interactive {
			fatal("no settings file found at %s - run telnetvision.exe once in a window to set it up", path)
		}
		if err := runWizard(&cfg, path); err != nil {
			fatal("%v", err)
		}
	}
	if err := cfg.validate(); err != nil {
		fatal("%v\n(fix %s, or run: telnetvision.exe --setup)", err, path)
	}
	if code := run(&cfg, interactive, *frames); code != 0 {
		if pauseOnExit {
			fmt.Fprint(os.Stderr, "\nPress Enter to close...")
			bufio.NewReader(os.Stdin).ReadString('\n')
		}
		os.Exit(code)
	}
}

func run(cfg *Config, interactive bool, maxFrames int) int {
	log := newLogger()
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	w, h := cfg.Cols, 2*cfg.Rows
	src := newVideoSource(w, h)
	lowSrc := strings.ToLower(cfg.Source)
	useStdin := lowSrc == "-"
	if cfg.SixelWidth >= w*2 && !useStdin {
		// Sharper pictures for sixel viewers: same shape as the normal one.
		src.HiW = cfg.SixelWidth
		src.HiH = cfg.SixelWidth * h / w
	}
	// ffmpeg is needed for everything except the test pattern and stdin,
	// and for sound - and for switching sources later, so find it now.
	ffmpeg, ffErr := findFFmpeg(cfg)
	if ffErr != nil && ((lowSrc != "test" && !useStdin) || cfg.Audio) {
		fmt.Fprintf(os.Stderr, "\nERROR: %v\n", ffErr)
		if runtime.GOARCH == "386" {
			fmt.Fprintln(os.Stderr, "Get a 32-bit ffmpeg from https://github.com/defisym/FFmpeg-Builds-Win32/releases")
			fmt.Fprintln(os.Stderr, "(or: winget install Defisym.FFmpeg.GPL) and copy ffmpeg.exe into:")
		} else {
			fmt.Fprintln(os.Stderr, "Get ffmpeg from https://www.gyan.dev/ffmpeg/builds/ (the \"essentials\" zip)")
			fmt.Fprintln(os.Stderr, "(or: winget install Gyan.FFmpeg) and copy bin\\ffmpeg.exe into:")
		}
		fmt.Fprintf(os.Stderr, "  %s\n", exeDir())
		fmt.Fprintln(os.Stderr, "Tip: SOURCE=test works without ffmpeg, to check your server settings.")
		return 1
	}

	var caps byte
	if cfg.Audio {
		caps = capAudio
	}
	snd := NewSender(cfg, caps, log.printf)
	go snd.Run()
	defer snd.Stop()
	clock0 := time.Now()

	var player *Player
	if useStdin {
		iw, ih, err := parseSize(cfg.InSize)
		if err != nil {
			fmt.Fprintln(os.Stderr, "ERROR:", err)
			return 1
		}
		src.Desc = "stdin " + cfg.InSize
		interactive = false // stdin carries video, not keys
		go runStdin(ctx, src, iw, ih)
	} else {
		src.Desc = cleanPath(cfg.Source)
		player = NewPlayer(cfg, ffmpeg, src, snd, clock0, log.printf)
		playerDone := make(chan struct{})
		go func() {
			defer close(playerDone)
			player.Run(ctx, cfg.Source)
		}()
		// On the way out, stop the player and give it a moment to stop
		// ffmpeg, so none are left running after the window closes.
		defer func() {
			cancel()
			select {
			case <-playerDone:
			case <-time.After(5 * time.Second):
			}
		}()
	}

	ctl := newControls(cfg)
	quit := make(chan struct{})
	var quitOnce sync.Once
	doQuit := func() { quitOnce.Do(func() { close(quit) }) }

	sig := make(chan os.Signal, 1)
	signal.Notify(sig, os.Interrupt)
	go func() { <-sig; doQuit() }()

	if player != nil {
		go func() {
			for a := range ctl.actions {
				player.Command(a.kind, a.arg)
			}
		}()
	}

	var con *consoleState
	vt := false
	if interactive {
		con, vt = setupConsole()
		defer con.restore()
		con.rawInput()
		go readKeys(func(b []byte) bool {
			// A file dropped on the window (or text pasted) arrives as a
			// burst of typed characters. Never run those as key commands
			// (a "q" in the path would quit): put them in the Play line.
			if ctl.paste(b) {
				return true
			}
			for _, k := range b {
				if ctl.key(k) {
					doQuit()
					return false
				}
			}
			return true
		})
	}
	ansiOK = vt || !interactive
	ctl.preview = cfg.Preview && interactive && vt

	// From here on, everything shown in this window goes through sw, so a
	// frozen window can never hold up the stream.
	sw := newScreenWriter()
	defer sw.Close(time.Second)
	log.mu.Lock()
	log.out = sw.Raw
	log.mu.Unlock()

	sw.Raw(fmt.Sprintf("Telnetvision %s\n  source : %s\n  server : %s:%d  channel=%s  tls=%v\n  picture: %dx%d chars @ %g fps\n",
		version, src.Desc, cfg.Host, cfg.Port, cfg.Channel, cfg.TLS, cfg.Cols, cfg.Rows, cfg.FPS))
	if interactive {
		sw.Raw("  keys   : S play something else  A add to playlist  N/B next/back  R shuffle  T message  H all keys  Q quit\n")
	}
	log.printf("starting: %s -> %s:%d", src.Desc, cfg.Host, cfg.Port)
	if interactive && vt {
		time.Sleep(1500 * time.Millisecond) // let the banner be read
	}

	previewOn := false
	enterPreview := func() {
		log.setScreen(false)
		sw.Raw("\x1b[?25l\x1b[?7l\x1b[2J")
		previewOn = true
	}
	leavePreview := func() {
		sw.Raw("\x1b[0m\x1b[?7h\x1b[?25h\x1b[2J\x1b[H")
		log.setScreen(true)
		previewOn = false
	}
	defer func() {
		if previewOn {
			leavePreview()
		}
	}()

	interval := time.Duration(float64(time.Second) / cfg.FPS)
	var seq uint64
	var lastSend time.Time
	sentFrames := 0
	fpsCount, fpsMark := 0, time.Now()
	slowSecs, slowWarned := 0, ""
	fps := 0.0
	lastStatus := time.Time{}
	var sb strings.Builder
	helpPrinted := false
	var lastFrame []byte
	var lastCaption []byte

	fit := func(s string, n int) string {
		r := []rune(s)
		if len(r) > n {
			return string(r[:n])
		}
		return s
	}

	for {
		select {
		case <-quit:
			log.printf("stopped")
			return 0
		default:
		}
		frame, nseq, framePTS, err := src.Next(seq, 100*time.Millisecond)
		if err != nil && frame == nil {
			if previewOn {
				leavePreview()
			}
			log.printf("%v", err)
			return 1
		}
		sat, cn, bri, mode, ramp, wantPreview := ctl.snapshot()
		if wantPreview && !previewOn {
			enterPreview()
		} else if !wantPreview && previewOn {
			leavePreview()
		}
		now := time.Now()
		message := ctl.currentMessage(now)

		if frame != nil {
			seq = nseq
			if d := time.Since(lastSend); d < interval {
				time.Sleep(interval - d) // pacing for unthrottled sources
			}
			lastSend = time.Now()
			grade(frame, bri, cn, sat)
			capOn := ctl.captionsOn()
			// A typed message goes on top; then the live caption file if it
			// has text, otherwise the video's own subtitles / captions.
			caption := readCaption(cfg.CaptionFile)
			if len(caption) == 0 && capOn && player != nil {
				caption = []byte(player.Subs().Current(time.Now()))
			}
			msg := message
			if msg != "" && snd.ServerOffers(capMessages) {
				msg = msgMark + msg // shows even for viewers who hid the subtitles
			}
			caption = combineCaption(msg, caption)
			var m, r byte = modeHalf, rampASCII
			if mode == "ramp" {
				m = modeRamp
			}
			if ramp == "shades" {
				r = rampShades
			}
			pts := uint64(time.Since(clock0).Milliseconds())
			if framePTS >= 0 {
				pts = uint64(framePTS) // its place in the movie, matching the sound
			}
			title := ""
			if player != nil {
				title = player.Title()
			}
			snd.SendVideo(framePayload(cfg.Cols, cfg.Rows, m, r, caption, frame, pts, title))
			// The sharper copy, while the server has viewers watching in sixel.
			if src.HiW > 0 && snd.WantsHi() {
				if hi := src.Hi(nseq); hi != nil {
					grade(hi, bri, cn, sat)
					snd.SendHi(hiPayload(src.HiW, src.HiH, hi, pts))
				}
			}
			sentFrames++
			fpsCount++
			lastFrame, lastCaption = frame, caption
		}

		redraw := ctl.takeDirty() || logRedraw.Swap(false)
		sb.Reset()
		if previewOn && lastFrame != nil && (frame != nil || redraw) {
			renderPreview(&sb, lastFrame, cfg.Cols, cfg.Rows, mode, ramp, lastCaption)
			if ctl.helpShown() {
				for i, l := range helpLines {
					fmt.Fprintf(&sb, "\x1b[%d;3H\x1b[0;30;47m%s\x1b[0m", i+2, fit(l, cfg.Cols-4))
				}
			}
		}
		if !previewOn && interactive {
			if h := ctl.helpShown(); h && !helpPrinted {
				// \r\n: the window is in raw mode, where \n alone doesn't go
				// back to the start of the line (the help came out as a staircase).
				var hb strings.Builder
				hb.WriteString("\r" + clearLine() + "\r\n")
				for _, l := range helpLines {
					hb.WriteString("\x1b[0;30;47m" + fit(l, 79) + "\x1b[0m" + clearLine() + "\r\n")
				}
				sw.Raw(hb.String())
				helpPrinted = true
			} else if !h {
				helpPrinted = false
			}
		}

		if el := time.Since(fpsMark); el >= time.Second {
			fps = float64(fpsCount) / el.Seconds()
			fpsCount, fpsMark = 0, time.Now()
			// A movie that comes out of ffmpeg slower than FPS for a while
			// means this PC can't decode it in real time. Say so, once per
			// item, with what helps.
			now := ""
			if player != nil {
				now = player.NowPlaying()
			}
			if fps > 0 && fps < cfg.FPS*0.8 && now != "" {
				slowSecs++
				if slowSecs == 6 && slowWarned != now {
					slowWarned = now
					log.printf("this PC can't decode %q fast enough: %.1f of %g frames a second, so picture and sound slow down. Helps: a 64-bit Windows and ffmpeg, HWACCEL=auto and FAST_DECODE=1 (the defaults), a lower FPS, PREVIEW=0, or SYNC_CAPTURE=0 to keep the sound smooth while the picture skips.", now, fps, cfg.FPS)
				}
			} else {
				slowSecs = 0
			}
		}
		if previewOn || redraw || time.Since(lastStatus) >= 2*time.Second {
			lastStatus = time.Now()
			state := snd.Status()
			if frame == nil && seq == 0 {
				state += ", waiting for video"
			}
			playing := src.Desc
			if player != nil {
				playing = player.NowPlaying()
			}
			if f := ctl.flashText(); f != "" {
				playing = f
			}
			extra := ""
			if player != nil && player.Shuffling() {
				extra += " | shuffle"
			}
			if message != "" {
				extra += " | MESSAGE ON"
			}
			status := fmt.Sprintf(" %s | %4.1f fps | %s%s | H help | sat %.1f con %.1f bri %+d ", state, fps, fit(playing, 34), extra, sat, cn, bri)
			label, text, typing := ctl.promptLine()
			promptText := ""
			if typing {
				// Show the end of a long entry so the cursor stays visible.
				room := cfg.Cols - len([]rune(label)) - 2
				t := []rune(text)
				if room > 0 && len(t) > room {
					t = t[len(t)-room:]
				}
				promptText = "\x1b[1;33m" + label + "\x1b[0m" + string(t) + "\x1b[7m \x1b[0m"
			}
			if previewOn {
				line2 := "\x1b[2m" + fit(log.lastMsg(), cfg.Cols) + "\x1b[0m"
				if typing {
					line2 = promptText
				} else if message != "" {
					line2 = "\x1b[1;36m" + fit("Message on screen: "+message+"  (X clears)", cfg.Cols) + "\x1b[0m"
				}
				fmt.Fprintf(&sb, "\x1b[%d;1H\x1b[K\x1b[7m%s\x1b[0m\x1b[%d;1H\x1b[K%s", cfg.Rows+1, fit(status, cfg.Cols), cfg.Rows+2, line2)
			} else if interactive {
				if typing {
					fmt.Fprintf(&sb, "\r%s%s", clearLine(), promptText)
				} else {
					fmt.Fprintf(&sb, "\r%s%s", clearLine(), fit(status, 79))
				}
			}
		}
		if sb.Len() > 0 {
			sw.Frame(sb.String())
		}

		if maxFrames > 0 && sentFrames >= maxFrames {
			time.Sleep(300 * time.Millisecond) // let the last frame flush
			return 0
		}
	}
}
