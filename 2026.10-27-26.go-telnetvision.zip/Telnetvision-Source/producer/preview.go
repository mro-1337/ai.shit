package main

import (
	"strconv"
	"strings"
)

var (
	rampASCIIGlyphs  = []rune(" .:-=+*#%@")
	rampShadesGlyphs = []rune(" ░▒▓█")
)

// renderPreview draws the frame exactly as callers get it (half-blocks or a
// brightness ramp) using 24-bit color, starting at the top-left corner.
func renderPreview(b *strings.Builder, px []byte, cols, rows int, mode, ramp string, caption []byte) {
	b.WriteString("\x1b[H")
	glyphs := rampASCIIGlyphs
	if ramp == "shades" {
		glyphs = rampShadesGlyphs
	}
	num := func(v byte) { b.WriteString(strconv.Itoa(int(v))) }
	for y := 0; y < rows; y++ {
		lastFG, lastBG := -1, -1
		for x := 0; x < cols; x++ {
			t := (2*y*cols + x) * 3
			u := ((2*y+1)*cols + x) * 3
			if mode == "ramp" {
				r := byte((int(px[t]) + int(px[u])) / 2)
				g := byte((int(px[t+1]) + int(px[u+1])) / 2)
				bl := byte((int(px[t+2]) + int(px[u+2])) / 2)
				fg := int(r)<<16 | int(g)<<8 | int(bl)
				if fg != lastFG {
					b.WriteString("\x1b[38;2;")
					num(r)
					b.WriteByte(';')
					num(g)
					b.WriteByte(';')
					num(bl)
					b.WriteByte('m')
					lastFG = fg
				}
				luma := (299*int(r) + 587*int(g) + 114*int(bl)) / 1000
				b.WriteRune(glyphs[luma*(len(glyphs)-1)/255])
				continue
			}
			fg := int(px[t])<<16 | int(px[t+1])<<8 | int(px[t+2])
			bg := int(px[u])<<16 | int(px[u+1])<<8 | int(px[u+2])
			if fg != lastFG {
				b.WriteString("\x1b[38;2;")
				num(px[t])
				b.WriteByte(';')
				num(px[t+1])
				b.WriteByte(';')
				num(px[t+2])
				b.WriteByte('m')
				lastFG = fg
			}
			if bg != lastBG {
				b.WriteString("\x1b[48;2;")
				num(px[u])
				b.WriteByte(';')
				num(px[u+1])
				b.WriteByte(';')
				num(px[u+2])
				b.WriteByte('m')
				lastBG = bg
			}
			b.WriteString("▀")
		}
		b.WriteString("\x1b[0m\r\n")
	}
	if len(caption) > 0 {
		c := []rune(strings.ReplaceAll(string(caption), "\n", " "))
		if len(c) > cols {
			c = c[:cols]
		}
		pad := (cols - len(c)) / 2
		bar := strings.Repeat(" ", pad) + string(c) + strings.Repeat(" ", cols-len(c)-pad)
		b.WriteString("\x1b[" + strconv.Itoa(rows) + ";1H\x1b[0;37;44m" + bar + "\x1b[0m")
	}
}
