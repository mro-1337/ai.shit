package main

// screenWriter owns the console window. Everything shown locally goes
// through it, on its own goroutine, so the stream to viewers never waits
// on the window: a window that's frozen (a text selection, a dragged
// scroll bar, a slow remote desktop) just shows a stale picture while
// frames keep going out. Text lines are queued in order; the preview /
// status line is a single slot that always holds only the newest frame.

import (
	"os"
	"strings"
	"sync"
	"time"
)

type screenWriter struct {
	mu       sync.Mutex
	cond     *sync.Cond
	raw      []string
	frame    string
	hasFrame bool
	closed   bool
	done     chan struct{}
}

func newScreenWriter() *screenWriter {
	w := &screenWriter{done: make(chan struct{})}
	w.cond = sync.NewCond(&w.mu)
	go w.run()
	return w
}

// Raw queues text to print in order (log lines, mode switches). A pending
// frame is dropped: it was drawn for the screen as it was before this.
func (w *screenWriter) Raw(s string) {
	w.mu.Lock()
	w.raw = append(w.raw, s)
	if len(w.raw) > 500 {
		w.raw = w.raw[len(w.raw)-500:]
	}
	w.frame, w.hasFrame = "", false
	w.mu.Unlock()
	w.cond.Signal()
}

// Frame replaces whatever picture/status is waiting to be drawn.
func (w *screenWriter) Frame(s string) {
	w.mu.Lock()
	w.frame, w.hasFrame = s, true
	w.mu.Unlock()
	w.cond.Signal()
}

func (w *screenWriter) run() {
	defer close(w.done)
	for {
		w.mu.Lock()
		for len(w.raw) == 0 && !w.hasFrame && !w.closed {
			w.cond.Wait()
		}
		if len(w.raw) == 0 && !w.hasFrame && w.closed {
			w.mu.Unlock()
			return
		}
		var b strings.Builder
		for _, r := range w.raw {
			b.WriteString(r)
		}
		w.raw = w.raw[:0]
		if w.hasFrame {
			b.WriteString(w.frame)
			w.frame, w.hasFrame = "", false
		}
		w.mu.Unlock()
		os.Stdout.WriteString(b.String())
	}
}

// Close writes what's pending, waiting at most d (the window may be frozen).
func (w *screenWriter) Close(d time.Duration) {
	w.mu.Lock()
	w.closed = true
	w.mu.Unlock()
	w.cond.Signal()
	select {
	case <-w.done:
	case <-time.After(d):
	}
}
