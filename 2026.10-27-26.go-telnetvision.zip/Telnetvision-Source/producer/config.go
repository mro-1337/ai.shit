package main

import (
	"bufio"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

// Config holds every setting. Keys in the config file use the same names as
// the upstream .env file, so an existing .env can be dropped in unchanged.
type Config struct {
	Host     string // BBS_HOST
	Port     int    // BBS_PORT
	Token    string // TOKEN
	Channel  string // CHANNEL
	TLS      bool   // TLS
	Insecure bool   // INSECURE

	Source     string // SOURCE: camera | camera:<name> | screen | test | <file> | <folder> | <url> | -
	Shuffle    bool   // SHUFFLE: play a folder in random order
	Loop       bool   // LOOP: start a folder playlist over at the end
	MessageSec int    // MESSAGE_SECONDS: how long a typed message stays up (0 = until cleared)
	ShowTitle  bool   // SHOW_TITLE: send the movie's name for viewers' title bar
	Title      string // TITLE: name to show for a camera, the screen or a stream
	InSize     string // IN_SIZE: WxH of raw rgb24 frames when SOURCE=-
	Flip       string // FLIP: auto | 1 | 0

	Cols int     // COLS
	Rows int     // ROWS
	FPS  float64 // FPS

	Saturation float64 // SATURATION
	Contrast   float64 // CONTRAST
	Brightness int     // BRIGHTNESS
	Mode       string  // MODE: half | ramp
	Ramp       string  // RAMP: ascii | shades

	CaptionFile   string // CAPTION_FILE
	Subtitles     string // SUBTITLES: auto | off | cc | track | <file.srt/.vtt>
	SubtitleTrack string // SUBTITLE_TRACK: number or language code

	Audio         bool   // AUDIO
	AudioSource   string // AUDIO_SOURCE: auto | mic | mic:<name> | <file/url>
	AudioRate     int    // AUDIO_RATE
	AudioChannels int    // AUDIO_CHANNELS
	AudioChunkMs  int    // AUDIO_CHUNK_MS
	AudioOffsetMs int    // AUDIO_OFFSET_MS
	AudioCodec    string // AUDIO_CODEC: adpcm | ulaw | pcm
	SyncCapture   bool   // SYNC_CAPTURE: picture and sound from one ffmpeg
	FeedCompress  bool   // FEED_COMPRESS: packed pictures to tvserver
	HWAccel       string // HWACCEL: auto | off | dxva2 | d3d11va | ...
	FastDecode    bool   // FAST_DECODE: cheaper decoding of movies
	SixelWidth    int    // SIXEL_WIDTH: pixels across for sixel viewers (0 = off)
	FeedColorBits int    // FEED_COLOR_BITS: 8 = exact, 6 = default

	FFmpeg  string // FFMPEG: path to ffmpeg.exe (default: next to this program, then PATH)
	Preview bool   // PREVIEW: live mirror in this window

	SendTimeout       float64 // SEND_TIMEOUT seconds
	ReconnectMaxDelay float64 // RECONNECT_MAX_DELAY seconds
}

func defaultConfig() Config {
	return Config{
		Port: 7600, Channel: "cam", TLS: true, Insecure: true,
		Source: "camera", InSize: "640x480", Flip: "auto", Loop: true, MessageSec: 15, ShowTitle: true,
		Cols: 80, Rows: 24, FPS: 15,
		Saturation: 1, Contrast: 1, Mode: "half", Ramp: "ascii", Subtitles: "auto",
		AudioSource: "auto", AudioCodec: soundADPCM, SyncCapture: true, FeedCompress: true, FeedColorBits: 6, HWAccel: "auto", FastDecode: true, SixelWidth: 160, AudioRate: 22050, AudioChannels: 1, AudioChunkMs: 80,
		Preview: true, SendTimeout: 15, ReconnectMaxDelay: 30,
	}
}

// exeDir is the folder this program lives in; config and ffmpeg.exe are
// looked for there so a double-click works regardless of the working dir.
func exeDir() string {
	p, err := os.Executable()
	if err != nil {
		return "."
	}
	if r, err := filepath.EvalSymlinks(p); err == nil {
		p = r
	}
	return filepath.Dir(p)
}

func parseBool(v string) (bool, error) {
	switch strings.ToLower(strings.TrimSpace(v)) {
	case "1", "y", "yes", "true", "on":
		return true, nil
	case "0", "n", "no", "false", "off", "":
		return false, nil
	}
	return false, fmt.Errorf("not a yes/no value: %q", v)
}

// set applies one KEY=value pair. Unknown keys are ignored so upstream .env
// files (which also carry caption-mic settings) load without complaint.
func (c *Config) set(key, val string) error {
	var err error
	k := strings.ToUpper(strings.TrimSpace(key))
	val = os.ExpandEnv(strings.TrimSpace(val))
	val = expandPercent(val)
	switch k {
	case "BBS_HOST", "HOST":
		c.Host = val
	case "BBS_PORT", "PORT":
		c.Port, err = strconv.Atoi(val)
	case "TOKEN":
		c.Token = val
	case "CHANNEL":
		c.Channel = val
	case "TLS":
		c.TLS, err = parseBool(val)
	case "INSECURE":
		c.Insecure, err = parseBool(val)
	case "SOURCE":
		c.Source = val
	case "SHUFFLE":
		c.Shuffle, err = parseBool(val)
	case "LOOP":
		c.Loop, err = parseBool(val)
	case "MESSAGE_SECONDS":
		c.MessageSec, err = strconv.Atoi(val)
	case "SHOW_TITLE":
		c.ShowTitle, err = parseBool(val)
	case "TITLE":
		c.Title = val
	case "IN_SIZE":
		c.InSize = val
	case "FLIP":
		switch strings.ToLower(val) {
		case "auto", "":
			c.Flip = "auto"
		default:
			var b bool
			b, err = parseBool(val)
			c.Flip = map[bool]string{true: "1", false: "0"}[b]
		}
	case "COLS":
		c.Cols, err = strconv.Atoi(val)
	case "ROWS":
		c.Rows, err = strconv.Atoi(val)
	case "FPS":
		c.FPS, err = strconv.ParseFloat(val, 64)
	case "SATURATION":
		c.Saturation, err = strconv.ParseFloat(val, 64)
	case "CONTRAST":
		c.Contrast, err = strconv.ParseFloat(val, 64)
	case "BRIGHTNESS":
		c.Brightness, err = strconv.Atoi(val)
	case "MODE":
		c.Mode = strings.ToLower(val)
	case "RAMP":
		c.Ramp = strings.ToLower(val)
	case "CAPTION_FILE":
		c.CaptionFile = val
	case "SUBTITLES":
		c.Subtitles = val
	case "SUBTITLE_TRACK":
		c.SubtitleTrack = val
	case "AUDIO":
		c.Audio, err = parseBool(val)
	case "AUDIO_SOURCE":
		c.AudioSource = val
	case "AUDIO_RATE":
		c.AudioRate, err = strconv.Atoi(val)
	case "AUDIO_CHANNELS":
		c.AudioChannels, err = strconv.Atoi(val)
	case "AUDIO_CHUNK_MS":
		c.AudioChunkMs, err = strconv.Atoi(val)
	case "AUDIO_OFFSET_MS":
		c.AudioOffsetMs, err = strconv.Atoi(val)
	case "SIXEL_WIDTH":
		c.SixelWidth, err = strconv.Atoi(val)
	case "HWACCEL":
		c.HWAccel = val
	case "FAST_DECODE":
		c.FastDecode, err = parseBool(val)
	case "FEED_COMPRESS":
		c.FeedCompress, err = parseBool(val)
	case "FEED_COLOR_BITS":
		c.FeedColorBits, err = strconv.Atoi(val)
	case "SYNC_CAPTURE":
		c.SyncCapture, err = parseBool(val)
	case "AUDIO_CODEC", "AUDIO_COMPRESSION":
		c.AudioCodec, _ = normalizeSoundCodec(val) // anything unknown: adpcm
	case "FFMPEG":
		c.FFmpeg = val
	case "PREVIEW", "MIRROR":
		c.Preview, err = parseBool(val)
	case "SEND_TIMEOUT":
		c.SendTimeout, err = strconv.ParseFloat(val, 64)
	case "RECONNECT_MAX_DELAY":
		c.ReconnectMaxDelay, err = strconv.ParseFloat(val, 64)
	}
	if err != nil {
		return fmt.Errorf("%s: %v", k, err)
	}
	return nil
}

// expandPercent expands Windows-style %VAR% references (e.g. %TEMP%).
func expandPercent(s string) string {
	for {
		i := strings.Index(s, "%")
		if i < 0 {
			return s
		}
		j := strings.Index(s[i+1:], "%")
		if j < 0 {
			return s
		}
		name := s[i+1 : i+1+j]
		v, ok := os.LookupEnv(name)
		if !ok || name == "" {
			return s
		}
		s = s[:i] + v + s[i+2+j:]
	}
}

// loadFile reads KEY=value lines; '#' and ';' start comments, [sections]
// are ignored, and a matching pair of surrounding quotes is stripped.
func (c *Config) loadFile(path string) error {
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	n := 0
	for sc.Scan() {
		n++
		line := strings.TrimSpace(strings.TrimPrefix(sc.Text(), "\ufeff"))
		if line == "" || line[0] == '#' || line[0] == ';' || line[0] == '[' {
			continue
		}
		k, v, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		v = strings.TrimSpace(v)
		if len(v) >= 2 && (v[0] == '"' && v[len(v)-1] == '"' || v[0] == '\'' && v[len(v)-1] == '\'') {
			v = v[1 : len(v)-1]
		} else if i := strings.Index(v, " #"); i >= 0 {
			v = strings.TrimSpace(v[:i]) // trailing comment on an unquoted value
		}
		if err := c.set(k, v); err != nil {
			return fmt.Errorf("%s line %d: %v", filepath.Base(path), n, err)
		}
	}
	return sc.Err()
}

func yn(b bool) string {
	if b {
		return "1"
	}
	return "0"
}

// iniAliases are older spellings the loader also accepts.
var iniAliases = map[string]string{"host": "bbs_host", "port": "bbs_port", "mirror": "preview", "audio_compression": "audio_codec"}

// sameSetting reports whether an existing value already means v.
func sameSetting(old, v string) bool {
	o := expandPercent(os.ExpandEnv(old))
	if strings.EqualFold(o, v) {
		return true
	}
	if a, err1 := parseBool(o); err1 == nil {
		if b, err2 := parseBool(v); err2 == nil && o != "" && v != "" {
			return a == b
		}
	}
	if a, err1 := strconv.ParseFloat(o, 64); err1 == nil {
		if b, err2 := strconv.ParseFloat(v, 64); err2 == nil {
			return a == b
		}
	}
	return false
}

// save writes the settings. An existing file is edited in place: only
// values that changed are rewritten, missing settings are added, and
// everything else in it (comments, other keys) is kept.
func (c *Config) save(path string) error {
	tmpl := c.template()
	old, err := os.ReadFile(path)
	if err != nil {
		return os.WriteFile(path, []byte(tmpl), 0o600)
	}
	data, _, changed := mergeINI(old, tmpl, iniAliases, nil, true, true, "", sameSetting)
	if !changed {
		return nil
	}
	return writeINISafely(path, data)
}

// template is the full, commented settings file for these values.
func (c *Config) template() string {
	var b strings.Builder
	w := func(format string, a ...any) { fmt.Fprintf(&b, format+"\r\n", a...) }
	w("# Telnetvision producer settings. Edit in Notepad, or run:  telnetvision.exe --setup")
	w("")
	w("# The server (tvserver.exe, or the BBS relay service.exe), its feed port, and its token.")
	w("BBS_HOST=%s", c.Host)
	w("BBS_PORT=%d", c.Port)
	w("TOKEN=%s", c.Token)
	w("# Must match channel in tvserver.ini (or door.ini).")
	w("CHANNEL=%s", c.Channel)
	w("# TLS=1 encrypts. INSECURE=1 accepts self-signed certs (like tvserver.exe's automatic one).")
	w("TLS=%s", yn(c.TLS))
	w("INSECURE=%s", yn(c.Insecure))
	w("# Pack pictures to a quarter-to-half their size on the way to tvserver (it says")
	w("# when it understands them; the classic relay gets plain pictures). 1 = on.")
	w("FEED_COMPRESS=%s", yn(c.FeedCompress))
	w("# Viewers whose terminal shows sixel graphics (SyncTERM, IcyTerm, ...) can pick it")
	w("# in tvserver's S menu: real pixels instead of characters. This many pixels across")
	w("# are sent for them, only while someone is watching that way. 0 = never.")
	w("SIXEL_WIDTH=%d", c.SixelWidth)
	w("# Colour precision of packed pictures: 6 bits per colour looks the same and packs")
	w("# much smaller; 8 = exact; 5 = smallest (a little banding on 24-bit screens).")
	w("FEED_COLOR_BITS=%d", c.FeedColorBits)
	w("")
	w("# What to send:  camera | camera:<device name> | screen | test | C:\\path\\video.mp4 | rtsp://... | http://...")
	w("#   or a folder, e.g. C:\\Movies - plays every video in it and its subfolders, in order.")
	w("SOURCE=%s", c.Source)
	w("# Folder playlists: SHUFFLE=1 plays them in random order; LOOP=0 stops at the end.")
	w("SHUFFLE=%s", yn(c.Shuffle))
	w("LOOP=%s", yn(c.Loop))
	w("# Mirror left/right: auto (only the default webcam), 1, or 0.")
	w("FLIP=%s", c.Flip)
	w("")
	w("# Picture size in character cells (80x24 = standard BBS screen) and frames per second.")
	w("COLS=%d", c.Cols)
	w("ROWS=%d", c.Rows)
	w("FPS=%s", strconv.FormatFloat(c.FPS, 'f', -1, 64))
	w("")
	w("# Starting color grade and render style (all adjustable live with keys).")
	w("SATURATION=%s", strconv.FormatFloat(c.Saturation, 'f', -1, 64))
	w("CONTRAST=%s", strconv.FormatFloat(c.Contrast, 'f', -1, 64))
	w("BRIGHTNESS=%d", c.Brightness)
	w("MODE=%s", c.Mode)
	w("RAMP=%s", c.Ramp)
	w("")
	w("# Subtitles / closed captions from the video itself:")
	w("#   auto  = use a .srt/.vtt next to the file, a subtitle track, or TV closed captions")
	w("#   off   = none     cc = force closed captions     track = force a subtitle track")
	w("#   or the path of a .srt / .vtt file to use with this video")
	w("SUBTITLES=%s", c.Subtitles)
	w("# Which subtitle track when there are several: a number (0 = first) or a language (eng, spa).")
	w("SUBTITLE_TRACK=%s", c.SubtitleTrack)
	w("# Live captions: the last line of this text file is shown, ahead of the above")
	w("# (e.g. speech-to-text). Leave blank for none.")
	w("CAPTION_FILE=%s", c.CaptionFile)
	w("")
	w("# Messages you type with T in this window stay up this many seconds (0 = until cleared).")
	w("MESSAGE_SECONDS=%d", c.MessageSec)
	w("")
	w("# Title bar on viewers' screens: the movie's name (from its file name).")
	w("# TITLE is shown instead for a camera, the screen or a stream (blank = no bar then).")
	w("SHOW_TITLE=%s", yn(c.ShowTitle))
	w("TITLE=%s", c.Title)
	w("")
	w("# Sound for SyncTERM 1.10a+ viewers.  AUDIO_SOURCE: auto | mic | mic:<device name> | <file or URL>")
	w("AUDIO=%s", yn(c.Audio))
	w("AUDIO_SOURCE=%s", c.AudioSource)
	w("# With ADPCM: 22050 Hz mono needs ~0.14 Mbit/s per listener; 44100 Hz stereo ~0.5 Mbit/s.")
	w("AUDIO_RATE=%d", c.AudioRate)
	w("AUDIO_CHANNELS=%d", c.AudioChannels)
	w("# Sound compression, all played by SyncTERM:")
	w("#   adpcm = 4-bit IMA ADPCM, 1/4 the size (default)   ulaw = 8-bit, 1/2 the size   pcm = none")
	w("# Viewers can pick lower quality for themselves with S in tvserver.")
	w("AUDIO_CODEC=%s", c.AudioCodec)
	w("# Sound chunk length in ms (40-200): smaller = less delay, more data overhead.")
	w("AUDIO_CHUNK_MS=%d", c.AudioChunkMs)
	w("# 1 = take picture and sound from one ffmpeg, stamped by the same clock, so")
	w("# they stay in sync. 0 = capture them separately, as older versions did")
	w("# (try 0 if the picture lags on a slower PC; AUDIO_OFFSET_MS can then line them up).")
	w("SYNC_CAPTURE=%s", yn(c.SyncCapture))
	w("# Lip-sync trim: positive = audio earlier.")
	w("AUDIO_OFFSET_MS=%d", c.AudioOffsetMs)
	w("")
	w("# Movies and streams: HWACCEL=auto lets the graphics card decode them (much less")
	w("# work for the processor; ffmpeg uses the processor if the card can't). off = never.")
	w("HWACCEL=%s", c.HWAccel)
	w("# FAST_DECODE=1 skips decoding work that can't be seen at this size (~25%% less).")
	w("FAST_DECODE=%s", yn(c.FastDecode))
	w("")
	w("# Leave blank to use ffmpeg.exe next to this program, or on PATH.")
	w("FFMPEG=%s", c.FFmpeg)
	w("# Live preview in this window.")
	w("PREVIEW=%s", yn(c.Preview))
	return b.String()
}

func (c *Config) validate() error {
	var probs []string
	if c.Host == "" {
		probs = append(probs, "BBS_HOST is not set")
	}
	if c.Port <= 0 || c.Port > 65535 {
		probs = append(probs, "BBS_PORT must be 1-65535")
	}
	if c.Token == "" {
		probs = append(probs, "TOKEN is not set")
	}
	if c.Channel == "" {
		c.Channel = "cam"
	}
	if c.Cols < 8 || c.Cols > 400 || c.Rows < 4 || c.Rows > 200 {
		probs = append(probs, "COLS must be 8-400 and ROWS 4-200")
	}
	if c.FPS <= 0 || c.FPS > 60 {
		probs = append(probs, "FPS must be between 0 and 60")
	}
	if c.Mode != "half" && c.Mode != "ramp" {
		c.Mode = "half"
	}
	if c.Ramp != "ascii" && c.Ramp != "shades" {
		c.Ramp = "ascii"
	}
	if c.AudioChunkMs < 40 {
		c.AudioChunkMs = 40
	}
	if c.AudioChunkMs > 200 {
		c.AudioChunkMs = 200
	}
	if c.AudioChannels < 1 || c.AudioChannels > 2 {
		c.AudioChannels = 2
	}
	if c.AudioRate < 8000 {
		c.AudioRate = 44100
	}
	if len(probs) > 0 {
		return fmt.Errorf("%s", strings.Join(probs, "; "))
	}
	return nil
}

func parseSize(s string) (int, int, error) {
	w, h, ok := strings.Cut(strings.ToLower(s), "x")
	if !ok {
		return 0, 0, fmt.Errorf("size must look like 640x480, got %q", s)
	}
	wi, err1 := strconv.Atoi(w)
	hi, err2 := strconv.Atoi(h)
	if err1 != nil || err2 != nil || wi <= 0 || hi <= 0 {
		return 0, 0, fmt.Errorf("size must look like 640x480, got %q", s)
	}
	return wi, hi, nil
}
