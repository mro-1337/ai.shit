package main

import (
	"encoding/hex"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

// TestWireMatchesPython compares our messages with upstream wire.py output.
// Skipped when python3 or the upstream checkout isn't available.
func TestWireMatchesPython(t *testing.T) {
	up := os.Getenv("UPSTREAM")
	if up == "" {
		t.Skip("set UPSTREAM to the telnetvision checkout")
	}
	py := `
import sys, struct; sys.path.insert(0, sys.argv[1]); import wire
class S:
    def __init__(s): s.b=b""
    def sendall(s,d): s.b+=d
s=S(); wire.hello_producer(s,"tok123","cam",wire.CAP_AUDIO); print(s.b.hex())
s=S(); wire.hello_producer(s,"tok123","cam"); print(s.b.hex())
s=S(); wire.send_msg(s, wire.frame_payload(2,1,bytes(range(12)),1,1,"hi ✓".encode(),123456789)); print(s.b.hex())
s=S(); wire.send_msg(s, wire.audio_payload(2,2,44100,7,999,80,b"RIFFxx")); print(s.b.hex())
`
	out, err := exec.Command("python3", "-c", py, up).Output()
	if err != nil {
		t.Skip("python3 unavailable:", err)
	}
	want := strings.Fields(string(out))
	h1, _ := helloProducer("tok123", "cam", capAudio)
	h2, _ := helloProducer("tok123", "cam", 0)
	px := make([]byte, 12)
	for i := range px {
		px[i] = byte(i)
	}
	got := []string{
		hex.EncodeToString(h1),
		hex.EncodeToString(h2),
		hex.EncodeToString(framePayload(2, 1, 1, 1, []byte("hi ✓"), px, 123456789, "")),
		hex.EncodeToString(audioPayload(2, 2, 44100, 7, 999, 80, []byte("RIFFxx"))),
	}
	for i := range got {
		if got[i] != want[i] {
			t.Errorf("message %d differs:\n go %s\n py %s", i, got[i], want[i])
		}
	}
}

func TestWAVHeader(t *testing.T) {
	w := wavEncode(make([]byte, 100), 44100, 2)
	if len(w) != 144 || string(w[:4]) != "RIFF" || string(w[8:16]) != "WAVEfmt " || string(w[36:40]) != "data" {
		t.Fatalf("bad wav header: %x", w[:44])
	}
}

func TestGradeIdentityAndSaturation(t *testing.T) {
	px := []byte{200, 100, 50, 128, 128, 128}
	orig := append([]byte(nil), px...)
	grade(px, 0, 1, 1)
	if string(px) != string(orig) {
		t.Fatal("identity grade changed pixels")
	}
	grade(px, 0, 1, 0) // fully desaturate: channels equal max
	if px[0] != px[1] || px[1] != px[2] {
		t.Fatalf("desaturate failed: %v", px[:3])
	}
	if px[3] != 128 {
		t.Fatal("grey changed")
	}
}

func TestConfigRoundTrip(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "t.ini")
	c := defaultConfig()
	c.Host, c.Token, c.Source, c.Audio, c.CaptionFile = "bbs.example", "abc", "camera:USB Cam", true, `C:\Temp\cap.txt`
	if err := c.save(p); err != nil {
		t.Fatal(err)
	}
	d := defaultConfig()
	if err := d.loadFile(p); err != nil {
		t.Fatal(err)
	}
	if d != c {
		t.Fatalf("round trip mismatch:\n%+v\n%+v", c, d)
	}
	// Upstream .env style: quotes and trailing comments.
	os.WriteFile(p, []byte("BBS_HOST=x.y   # cloud box\nTOKEN=\"q w\"\nCOLS=120\nCAPTURE=2\n"), 0o600)
	e := defaultConfig()
	if err := e.loadFile(p); err != nil || e.Host != "x.y" || e.Token != "q w" || e.Cols != 120 {
		t.Fatalf("env parse: %v %+v", err, e)
	}
}

func TestDeviceParsing(t *testing.T) {
	newFmt := `[dshow @ 0a] "Integrated Webcam" (video)
[dshow @ 0a]   Alternative name "@device_pnp_\\?\usb#vid"
[dshow @ 0a] "Microphone (Realtek Audio)" (audio)
[dshow @ 0a]   Alternative name "@device_cm_{33D9A762}"`
	oldFmt := `[dshow @ 0b] DirectShow video devices (some may be both video and audio devices)
[dshow @ 0b]  "USB2.0 HD UVC WebCam"
[dshow @ 0b]     Alternative name "@device_pnp_x"
[dshow @ 0b] DirectShow audio devices
[dshow @ 0b]  "Line In (USB Audio)"`
	for _, tc := range []struct {
		in   string
		v, a string
	}{{newFmt, "Integrated Webcam", "Microphone (Realtek Audio)"}, {oldFmt, "USB2.0 HD UVC WebCam", "Line In (USB Audio)"}} {
		devs := parseDeviceList([]byte(tc.in))
		if firstDevice(devs, "video") != tc.v || firstDevice(devs, "audio") != tc.a || len(devs) != 2 {
			t.Errorf("parse: %+v", devs)
		}
	}
	devs := []Device{{"Integrated Webcam", "video"}, {"OBS Virtual Camera", "video"}}
	if matchDevice(devs, "video", "obs") != "OBS Virtual Camera" {
		t.Error("substring match failed")
	}
}

func TestResizeArea(t *testing.T) {
	src := []byte{0, 0, 0, 100, 100, 100, 200, 200, 200, 255, 255, 255}
	d := resizeArea(src, 2, 2, 1, 1)
	if d[0] != 138 {
		t.Fatalf("got %d", d[0])
	}
}
