package main

import (
	"crypto/tls"
	"encoding/binary"
	"fmt"
	"io"
	"net"
	"strconv"
	"sync"
	"sync/atomic"
	"time"
)

// Sender owns the single connection to the relay. Audio outranks video:
// audio chunks queue in order (bounded, drop-oldest) while only the newest
// unsent frame is kept, so a slow uplink sheds video instead of delaying
// sound. It also owns connect / reconnect with exponential backoff, so the
// rest of the program never blocks on the network.
type Sender struct {
	cfg  *Config
	caps byte

	mu    sync.Mutex
	cond  *sync.Cond
	audio [][]byte
	video []byte
	hi    []byte // newest sharper picture for sixel viewers, sent after video
	quit  bool

	connMu sync.Mutex
	conn   net.Conn

	connected atomic.Bool
	zframes   atomic.Bool   // this server takes compressed frames (FRAME_Z)
	srvCaps   atomic.Uint32 // what the server's WELCOME offered
	wantHi    atomic.Bool   // the server has sixel viewers: send FRAME_HI
	zipped    atomic.Int64  // percent of the plain size the frames took, for the UI
	sent      atomic.Uint64 // frames written
	status    atomic.Value  // string, for the UI
	logf      func(string, ...any)
}

func NewSender(cfg *Config, caps byte, logf func(string, ...any)) *Sender {
	s := &Sender{cfg: cfg, caps: caps, logf: logf}
	s.cond = sync.NewCond(&s.mu)
	s.status.Store("connecting")
	return s
}

// ServerOffers reports whether the server's WELCOME offered cap.
func (s *Sender) ServerOffers(cap byte) bool { return s.srvCaps.Load()&uint32(cap) != 0 }

func (s *Sender) Status() string { return s.status.Load().(string) }

func (s *Sender) SendAudio(msg []byte) {
	s.mu.Lock()
	s.audio = append(s.audio, msg)
	if len(s.audio) > 32 {
		s.audio = s.audio[1:]
	}
	s.mu.Unlock()
	s.cond.Signal()
}

// WantsHi reports whether the server is asking for sharper pictures.
func (s *Sender) WantsHi() bool { return s.wantHi.Load() && s.zframes.Load() }

func (s *Sender) SendHi(msg []byte) {
	s.mu.Lock()
	s.hi = msg
	s.mu.Unlock()
	s.cond.Signal()
}

func (s *Sender) SendVideo(msg []byte) {
	s.mu.Lock()
	s.video = msg // replace any unsent frame (drop-to-latest)
	s.mu.Unlock()
	s.cond.Signal()
}

// Stop wakes the sender and closes the live connection so a blocked write
// returns immediately.
func (s *Sender) Stop() {
	s.mu.Lock()
	s.quit = true
	s.mu.Unlock()
	s.cond.Broadcast()
	s.connMu.Lock()
	if s.conn != nil {
		s.conn.Close()
	}
	s.connMu.Unlock()
}

func (s *Sender) stopped() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.quit
}

func (s *Sender) dial() (net.Conn, error) {
	addr := net.JoinHostPort(s.cfg.Host, strconv.Itoa(s.cfg.Port))
	d := net.Dialer{Timeout: 10 * time.Second, KeepAlive: 15 * time.Second}
	raw, err := d.Dial("tcp", addr)
	if err != nil {
		return nil, err
	}
	if tc, ok := raw.(*net.TCPConn); ok {
		tc.SetNoDelay(true) // audio chunks are small and frequent
		// Shallow kernel send queue so frames can't pile up ahead of audio.
		tc.SetWriteBuffer(32768)
	}
	conn := raw
	if s.cfg.TLS {
		tcfg := &tls.Config{ServerName: s.cfg.Host, InsecureSkipVerify: s.cfg.Insecure}
		tc := tls.Client(raw, tcfg)
		tc.SetDeadline(time.Now().Add(15 * time.Second))
		if err := tc.Handshake(); err != nil {
			raw.Close()
			return nil, fmt.Errorf("TLS handshake: %w", err)
		}
		tc.SetDeadline(time.Time{})
		conn = tc
	}
	hello, err := helloProducer(s.cfg.Token, s.cfg.Channel, s.caps)
	if err != nil {
		conn.Close()
		return nil, err
	}
	conn.SetWriteDeadline(time.Now().Add(15 * time.Second))
	if _, err := conn.Write(hello); err != nil {
		conn.Close()
		return nil, fmt.Errorf("sending hello: %w", err)
	}
	return conn, nil
}

func (s *Sender) maxDelay() time.Duration {
	d := time.Duration(s.cfg.ReconnectMaxDelay * float64(time.Second))
	if d < time.Second {
		d = time.Second
	}
	return d
}

// wait sleeps in slices so quitting stays responsive, then doubles *delay.
func (s *Sender) wait(delay *time.Duration) {
	s.status.Store(fmt.Sprintf("retry in %ds", int(delay.Seconds())))
	for t := time.Duration(0); t < *delay && !s.stopped(); t += 100 * time.Millisecond {
		time.Sleep(100 * time.Millisecond)
	}
	*delay *= 2
	if *delay > s.maxDelay() {
		*delay = s.maxDelay()
	}
}

// connect retries dial with exponential backoff until success or Stop.
func (s *Sender) connect(label string, delay *time.Duration) net.Conn {
	for !s.stopped() {
		s.status.Store(label)
		conn, err := s.dial()
		if err == nil {
			return conn
		}
		s.logf("%s to %s:%d failed (%v); retrying in %ds", label, s.cfg.Host, s.cfg.Port, err, int(delay.Seconds()))
		s.wait(delay)
	}
	return nil
}

func (s *Sender) Run() {
	label := "connecting"
	// The delay only resets after a connection proves healthy, so a relay
	// that keeps refusing us (wrong token, another producer on the same
	// channel) is retried politely instead of in a tight loop.
	delay := time.Second
	for !s.stopped() {
		conn := s.connect(label, &delay)
		if conn == nil {
			return
		}
		started := time.Now()
		s.connMu.Lock()
		s.conn = conn
		s.connMu.Unlock()
		s.connected.Store(true)
		s.status.Store("connected")
		s.logf("connected to %s:%d channel=%s", s.cfg.Host, s.cfg.Port, s.cfg.Channel)

		// tvserver answers with a WELCOME saying what it understands; the
		// classic relay never writes to a producer. Either way a read
		// ending means the connection was closed.
		s.zframes.Store(false)
		s.srvCaps.Store(0)
		s.wantHi.Store(false)
		dead := make(chan struct{})
		go func() {
			var lb [4]byte
			if _, err := io.ReadFull(conn, lb[:]); err == nil {
				if n := binary.BigEndian.Uint32(lb[:]); n >= 1 && n < 1024 {
					b := make([]byte, n)
					if _, err := io.ReadFull(conn, b); err == nil && b[0] == msgWelcome && n >= 2 {
						s.srvCaps.Store(uint32(b[1]))
						if b[1]&capZFrames != 0 && s.cfg.FeedCompress {
							s.zframes.Store(true)
							s.logf("server takes compressed pictures: sending them packed (FEED_COMPRESS)")
						}
					}
				}
				// Later messages: WANT_HI switches the sharper pictures on/off.
				for {
					var lb [4]byte
					if _, err := io.ReadFull(conn, lb[:]); err != nil {
						break
					}
					n := binary.BigEndian.Uint32(lb[:])
					if n == 0 || n > 4096 {
						break
					}
					b := make([]byte, n)
					if _, err := io.ReadFull(conn, b); err != nil {
						break
					}
					if b[0] == msgWantHi && n >= 2 {
						s.wantHi.Store(b[1] != 0)
					}
				}
			}
			close(dead)
			s.cond.Broadcast()
		}()

		err := s.pump(conn, dead)
		s.connected.Store(false)
		conn.Close()
		s.connMu.Lock()
		s.conn = nil
		s.connMu.Unlock()
		if s.stopped() {
			return
		}
		label = "reconnecting"
		// Stale media from before the drop is useless to callers.
		s.mu.Lock()
		s.audio, s.video, s.hi = nil, nil, nil
		s.mu.Unlock()
		if time.Since(started) >= 10*time.Second {
			delay = time.Second
			s.logf("connection lost (%v); reconnecting", err)
			continue
		}
		s.logf("connection lost (%v); retrying in %ds", err, int(delay.Seconds()))
		s.wait(&delay)
	}
}

func (s *Sender) pump(conn net.Conn, dead chan struct{}) error {
	timeout := time.Duration(s.cfg.SendTimeout * float64(time.Second))
	zip := newFrameZipper(s.cfg.FeedColorBits) // fresh per connection: deltas start over
	for {
		s.mu.Lock()
		for len(s.audio) == 0 && s.video == nil && s.hi == nil && !s.quit && !isClosed(dead) {
			s.cond.Wait()
		}
		if s.quit {
			s.mu.Unlock()
			return nil
		}
		if isClosed(dead) {
			s.mu.Unlock()
			return fmt.Errorf("relay closed the connection (relay restarted, wrong TOKEN, or another producer took channel %q)", s.cfg.Channel)
		}
		var msg []byte
		isVideo := false
		switch {
		case len(s.audio) > 0:
			msg, s.audio = s.audio[0], s.audio[1:]
		case s.video != nil:
			msg, s.video, isVideo = s.video, nil, true
		default:
			msg, s.hi = s.hi, nil
		}
		s.mu.Unlock()

		if msg[4] == msgFrameHi && !s.zframes.Load() {
			continue // only tvserver understands these
		}
		if (isVideo || msg[4] == msgFrameHi) && s.zframes.Load() {
			msg = zip.zip(msg)
			if zip.plain > 0 {
				s.zipped.Store(zip.sent * 100 / zip.plain)
			}
		}
		if timeout > 0 {
			conn.SetWriteDeadline(time.Now().Add(timeout))
		}
		if _, err := conn.Write(msg); err != nil {
			return err
		}
		if isVideo {
			s.sent.Add(1)
		}
	}
}

func isClosed(c chan struct{}) bool {
	select {
	case <-c:
		return true
	default:
		return false
	}
}
