//go:build windows

package main

import (
	"os"
	"os/exec"
	"strconv"
	"syscall"
	"time"
	"unsafe"
)

var (
	kernel32                          = syscall.NewLazyDLL("kernel32.dll")
	procGetConsoleMode                = kernel32.NewProc("GetConsoleMode")
	procSetConsoleMode                = kernel32.NewProc("SetConsoleMode")
	procSetOutputCP                   = kernel32.NewProc("SetConsoleOutputCP")
	procGetOutputCP                   = kernel32.NewProc("GetConsoleOutputCP")
	procSetConsoleTitle               = kernel32.NewProc("SetConsoleTitleW")
	procGetProcessList                = kernel32.NewProc("GetConsoleProcessList")
	procReadConsoleInput              = kernel32.NewProc("ReadConsoleInputW")
	procGetNumberOfConsoleInputEvents = kernel32.NewProc("GetNumberOfConsoleInputEvents")
)

const (
	enableProcessedInput  = 0x0001
	enableLineInput       = 0x0002
	enableEchoInput       = 0x0004
	enableVTProcessing    = 0x0004 // output handle flag
	enableQuickEdit       = 0x0040
	enableExtendedFlags   = 0x0080
	enableVTInput         = 0x0200
	disableNewlineAutoRet = 0x0008
	createNoWindow        = 0x08000000
)

type consoleState struct {
	inMode, outMode uint32
	cp              uintptr
	haveIn, haveOut bool
}

func getMode(h syscall.Handle) (uint32, bool) {
	var m uint32
	r, _, _ := procGetConsoleMode.Call(uintptr(h), uintptr(unsafe.Pointer(&m)))
	return m, r != 0
}

func setMode(h syscall.Handle, m uint32) bool {
	r, _, _ := procSetConsoleMode.Call(uintptr(h), uintptr(m))
	return r != 0
}

// isConsole reports whether stdin and stdout are an interactive console.
func isConsole() bool {
	_, a := getMode(syscall.Handle(os.Stdin.Fd()))
	_, b := getMode(syscall.Handle(os.Stdout.Fd()))
	return a && b
}

// setupConsole switches to UTF-8 output and enables ANSI escape processing.
// vt is false on consoles without VT support (pre-Windows 10).
func setupConsole() (st *consoleState, vt bool) {
	st = &consoleState{}
	st.cp, _, _ = procGetOutputCP.Call()
	procSetOutputCP.Call(65001)
	out := syscall.Handle(os.Stdout.Fd())
	if m, ok := getMode(out); ok {
		st.outMode, st.haveOut = m, true
		vt = setMode(out, m|enableVTProcessing|disableNewlineAutoRet) || setMode(out, m|enableVTProcessing)
	}
	return st, vt
}

// rawInput turns off line buffering and echo so single keys arrive at once.
// Ctrl+C keeps working (processed input stays on).
//
// It also turns off Quick Edit. With Quick Edit on, a click in the window
// starts a text selection that freezes everything the program writes
// (and swallows Esc to end the selection), and turns off VT input so
// keys arrive as plain key events.
func (st *consoleState) rawInput() {
	in := syscall.Handle(os.Stdin.Fd())
	if m, ok := getMode(in); ok {
		st.inMode, st.haveIn = m, true
		nm := (m | enableProcessedInput | enableExtendedFlags) &^
			(enableLineInput | enableEchoInput | enableQuickEdit | enableVTInput)
		if !setMode(in, nm) {
			setMode(in, (m|enableProcessedInput)&^(enableLineInput|enableEchoInput))
		}
	}
}

// inputRecord is the Win32 INPUT_RECORD for a KEY_EVENT (20 bytes on both
// 32- and 64-bit Windows).
type inputRecord struct {
	eventType uint16
	_         uint16
	keyDown   int32
	repeat    uint16
	vk        uint16
	scan      uint16
	char      uint16
	ctrlState uint32
}

const (
	keyEvent = 0x0001
	vkEscape = 0x1B
	vkReturn = 0x0D
	vkBack   = 0x08
)

// readKeys delivers key presses as bytes (UTF-8 for typed text, 27 for
// Esc, '\r' for Enter, 8 for Backspace) straight from the console's key
// events, so Esc is never lost to character translation. It returns when
// the console can't be read.
func readKeys(deliver func([]byte) bool) {
	in := syscall.Handle(os.Stdin.Fd())
	recs := make([]inputRecord, 32)
	var hi uint16 // pending high surrogate
	for {
		var n uint32
		r, _, _ := procReadConsoleInput.Call(uintptr(in), uintptr(unsafe.Pointer(&recs[0])), uintptr(len(recs)), uintptr(unsafe.Pointer(&n)))
		if r == 0 {
			return
		}
		out := keyBytes(recs[:n], &hi)
		// A file dropped on the window arrives as a burst of key events,
		// sometimes split across reads: collect the whole burst so it can be
		// recognised as one piece of text (see controls.paste).
		if len(out) > 0 {
			for tries := 0; tries < 50; tries++ {
				time.Sleep(15 * time.Millisecond)
				var pending uint32
				procGetNumberOfConsoleInputEvents.Call(uintptr(in), uintptr(unsafe.Pointer(&pending)))
				if pending == 0 {
					break
				}
				r, _, _ := procReadConsoleInput.Call(uintptr(in), uintptr(unsafe.Pointer(&recs[0])), uintptr(len(recs)), uintptr(unsafe.Pointer(&n)))
				if r == 0 {
					break
				}
				out = append(out, keyBytes(recs[:n], &hi)...)
			}
		}
		if len(out) > 0 && !deliver(out) {
			return
		}
	}
}

// keyBytes turns console key events into the bytes they type.
func keyBytes(recs []inputRecord, hi *uint16) []byte {
	var out []byte
	for _, rec := range recs {
		if rec.eventType != keyEvent || rec.keyDown == 0 {
			continue
		}
		var b []byte
		switch {
		case rec.vk == vkEscape:
			b = []byte{27}
		case rec.vk == vkReturn:
			b = []byte{'\r'}
		case rec.vk == vkBack:
			b = []byte{8}
		case rec.char >= 0xD800 && rec.char < 0xDC00:
			*hi = rec.char
			continue
		case rec.char >= 0xDC00 && rec.char < 0xE000 && *hi != 0:
			rn := (rune(*hi)-0xD800)<<10 + (rune(rec.char) - 0xDC00) + 0x10000
			*hi = 0
			b = []byte(string(rn))
		case rec.char != 0:
			b = []byte(string(rune(rec.char)))
		default:
			continue // Shift, Ctrl, arrows and other keys without a character
		}
		reps := int(rec.repeat)
		if reps < 1 {
			reps = 1
		}
		for i := 0; i < reps; i++ {
			out = append(out, b...)
		}
	}
	return out
}

func (st *consoleState) restore() {
	if st == nil {
		return
	}
	if st.haveIn {
		m := st.inMode
		if m&enableQuickEdit != 0 {
			m |= enableExtendedFlags // needed for Quick Edit to be switched back on
		}
		setMode(syscall.Handle(os.Stdin.Fd()), m)
	}
	if st.haveOut {
		setMode(syscall.Handle(os.Stdout.Fd()), st.outMode)
	}
	if st.cp != 0 {
		procSetOutputCP.Call(st.cp)
	}
}

func setTitle(s string) {
	p, err := syscall.UTF16PtrFromString(s)
	if err == nil {
		procSetConsoleTitle.Call(uintptr(unsafe.Pointer(p)))
	}
}

// launchedByDoubleClick: when Explorer starts a console program, the
// console holds only this one process. From cmd.exe it holds two or more.
func launchedByDoubleClick() bool {
	var ids [4]uint32
	n, _, _ := procGetProcessList.Call(uintptr(unsafe.Pointer(&ids[0])), 4)
	return n == 1
}

// hideWindow keeps ffmpeg off our console: no flashing window, and it
// can't swallow our keystrokes or Ctrl+C. We stop it ourselves.
func hideWindow(cmd *exec.Cmd) {
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: createNoWindow}
}

// killTree stops ffmpeg and anything it started (taskkill /T), then makes
// sure the process itself is gone.
func killTree(cmd *exec.Cmd) error {
	if cmd.Process == nil {
		return nil
	}
	tk := exec.Command("taskkill", "/T", "/F", "/PID", strconv.Itoa(cmd.Process.Pid))
	hideWindow(tk)
	tk.Run()
	return cmd.Process.Kill()
}
