module telnetvision/producer

go 1.22
