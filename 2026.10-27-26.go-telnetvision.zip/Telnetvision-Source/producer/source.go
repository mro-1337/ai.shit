package main

import (
	"bufio"
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"
)

// ffmpegCommand starts ffmpeg tied to ctx. When ctx ends, ffmpeg and
// anything it started are stopped (killTree), and Wait gives up on its
// output pipes after a few seconds, so skipping or switching sources can
// never hang - even with an ffmpeg.exe that is a launcher for another one
// (package-manager shims do that).
func ffmpegCommand(ctx context.Context, ffmpeg string, args ...string) *exec.Cmd {
	cmd := exec.CommandContext(ctx, ffmpeg, args...)
	hideWindow(cmd)
	cmd.Cancel = func() error { return killTree(cmd) }
	cmd.WaitDelay = 3 * time.Second
	return cmd
}

// findFFmpeg returns the ffmpeg to run: the configured path, else
// ffmpeg.exe next to this program, else the one on PATH.
func findFFmpeg(cfg *Config) (string, error) {
	if cfg.FFmpeg != "" {
		if _, err := os.Stat(cfg.FFmpeg); err == nil {
			return cfg.FFmpeg, nil
		}
		if p, err := exec.LookPath(cfg.FFmpeg); err == nil {
			return p, nil
		}
		return "", fmt.Errorf("FFMPEG=%s was not found", cfg.FFmpeg)
	}
	name := "ffmpeg"
	if runtime.GOOS == "windows" {
		name = "ffmpeg.exe"
	}
	local := filepath.Join(exeDir(), name)
	if _, err := os.Stat(local); err == nil {
		return local, nil
	}
	if p, err := exec.LookPath("ffmpeg"); err == nil {
		return p, nil
	}
	return "", errors.New("ffmpeg.exe was not found. Put ffmpeg.exe in the same folder as telnetvision.exe")
}

// Device is a DirectShow capture device.
type Device struct {
	Name string
	Kind string // "video" or "audio"
}

var quoted = regexp.MustCompile(`"([^"]+)"`)

// listDevices asks ffmpeg for the DirectShow device list (Windows only).
// Handles both the newer "name" (video) format and the older section-header
// format ("DirectShow video devices" / "DirectShow audio devices").
func listDevices(ffmpeg string) ([]Device, error) {
	if runtime.GOOS != "windows" {
		return nil, nil
	}
	cmd := exec.Command(ffmpeg, "-hide_banner", "-nostdin", "-list_devices", "true", "-f", "dshow", "-i", "dummy")
	hideWindow(cmd)
	out, _ := cmd.CombinedOutput() // always exits non-zero ("dummy" isn't a device)
	return parseDeviceList(out), nil
}

func parseDeviceList(out []byte) []Device {
	var devs []Device
	section := ""
	sc := bufio.NewScanner(bytes.NewReader(out))
	for sc.Scan() {
		line := sc.Text()
		low := strings.ToLower(line)
		switch {
		case strings.Contains(low, "directshow video devices"):
			section = "video"
			continue
		case strings.Contains(low, "directshow audio devices"):
			section = "audio"
			continue
		case strings.Contains(low, "alternative name"):
			continue
		}
		m := quoted.FindStringSubmatch(line)
		if m == nil {
			continue
		}
		kind := section
		if strings.Contains(low, "(video)") {
			kind = "video"
		} else if strings.Contains(low, "(audio)") {
			kind = "audio"
		} else if strings.Contains(low, "(none)") {
			continue
		}
		if kind == "" {
			continue
		}
		devs = append(devs, Device{Name: m[1], Kind: kind})
	}
	return devs
}

func firstDevice(devs []Device, kind string) string {
	for _, d := range devs {
		if d.Kind == kind {
			return d.Name
		}
	}
	return ""
}

// matchDevice resolves a full name or case-insensitive substring.
func matchDevice(devs []Device, kind, want string) string {
	for _, d := range devs {
		if d.Kind == kind && d.Name == want {
			return d.Name
		}
	}
	low := strings.ToLower(want)
	for _, d := range devs {
		if d.Kind == kind && strings.Contains(strings.ToLower(d.Name), low) {
			return d.Name
		}
	}
	return ""
}

func isURL(s string) bool {
	return strings.Contains(s, "://")
}

// videoInputArgs turns SOURCE into ffmpeg input arguments. It returns
// whether the image should be mirrored when FLIP=auto.
func videoInputArgs(cfg *Config, ffmpeg string) (args []string, autoFlip bool, desc string, err error) {
	src := strings.TrimSpace(cfg.Source)
	low := strings.ToLower(src)
	fps := strconv.FormatFloat(cfg.FPS, 'f', -1, 64)
	switch {
	case low == "camera" || strings.HasPrefix(low, "camera:") || isDigits(src):
		if runtime.GOOS != "windows" {
			if runtime.GOOS == "linux" {
				dev := "/dev/video0"
				if isDigits(src) {
					dev = "/dev/video" + src
				}
				return []string{"-f", "v4l2", "-i", dev}, low == "camera", "webcam " + dev, nil
			}
			return []string{"-f", "avfoundation", "-framerate", "30", "-i", "0"}, low == "camera", "webcam", nil
		}
		devs, _ := listDevices(ffmpeg)
		name := ""
		switch {
		case strings.HasPrefix(low, "camera:"):
			want := strings.TrimSpace(src[len("camera:"):])
			if name = matchDevice(devs, "video", want); name == "" {
				return nil, false, "", fmt.Errorf("no camera matching %q (run with --list-devices to see them)", want)
			}
		case isDigits(src):
			idx, _ := strconv.Atoi(src)
			var vids []string
			for _, d := range devs {
				if d.Kind == "video" {
					vids = append(vids, d.Name)
				}
			}
			if idx >= len(vids) {
				return nil, false, "", fmt.Errorf("camera #%s not found; %d camera(s) detected", src, len(vids))
			}
			name = vids[idx]
		default:
			if name = firstDevice(devs, "video"); name == "" {
				return nil, false, "", errors.New("no webcam or capture device was found")
			}
		}
		return []string{"-f", "dshow", "-rtbufsize", "32M", "-i", "video=" + name}, low == "camera", "camera \"" + name + "\"", nil
	case low == "screen" || low == "desktop":
		if runtime.GOOS == "windows" {
			return []string{"-f", "gdigrab", "-framerate", fps, "-draw_mouse", "1", "-i", "desktop"}, false, "screen capture", nil
		}
		return []string{"-f", "x11grab", "-framerate", fps, "-i", os.Getenv("DISPLAY")}, false, "screen capture", nil
	case isURL(src):
		return append(decodeArgs(cfg), "-fflags", "+discardcorrupt+nobuffer", "-err_detect", "ignore_err", "-i", src), false, src, nil
	default:
		if _, err := os.Stat(src); err != nil {
			return nil, false, "", fmt.Errorf("SOURCE %q is not a file, URL, camera, screen or test", src)
		}
		// Files play at real speed and loop forever.
		return append(decodeArgs(cfg), "-re", "-stream_loop", "-1", "-i", src), false, "file " + filepath.Base(src), nil
	}
}

// decodeArgs make decoding a movie cheaper, since all we keep is a picture
// a few dozen characters wide:
//   - the graphics card decodes it when it can (HWACCEL=auto; ffmpeg falls
//     back to the processor by itself if it can't), and
//   - the decoder skips its smoothing (deblocking) pass and takes its fast
//     shortcuts (FAST_DECODE=1): about a quarter less work, and no
//     visible difference once shrunk to 80x48.
func decodeArgs(cfg *Config) []string {
	var a []string
	if hw := strings.ToLower(strings.TrimSpace(cfg.HWAccel)); hw != "" && hw != "off" && hw != "0" && hw != "no" {
		a = append(a, "-hwaccel", hw)
	}
	if cfg.FastDecode {
		a = append(a, "-skip_loop_filter", "all", "-flags2", "fast")
	}
	return a
}

func isDigits(s string) bool {
	if s == "" {
		return false
	}
	for _, r := range s {
		if r < '0' || r > '9' {
			return false
		}
	}
	return true
}

// VideoSource delivers RGB24 frames of cols x 2*rows pixels. Only the
// newest frame is kept, so a slow consumer never builds latency.
type VideoSource struct {
	W, H      int
	HiW, HiH  int    // sharper copy for sixel viewers (0 = none)
	latestHi  []byte // the sharper copy of latest
	Desc      string
	mu        sync.Mutex
	cond      *sync.Cond
	latest    []byte
	latestPTS int64 // the frame's place in the movie (ms on the shared clock), or -1
	seq       uint64
	err       error
	done      bool
}

func newVideoSource(w, h int) *VideoSource {
	v := &VideoSource{W: w, H: h}
	v.cond = sync.NewCond(&v.mu)
	return v
}

func (v *VideoSource) put(frame []byte) { v.putPTS(frame, -1) }

// putPTS stores a frame stamped with its time in the movie, so it stays in
// step with sound stamped the same way, however late it is delivered.
func (v *VideoSource) putPTS(frame []byte, pts int64) { v.putHi(frame, nil, pts) }

// putHi stores a frame with its sharper copy (nil if none).
func (v *VideoSource) putHi(frame, hi []byte, pts int64) {
	v.mu.Lock()
	v.latestHi = hi
	v.latest = frame
	v.latestPTS = pts
	v.seq++
	v.mu.Unlock()
	v.cond.Broadcast()
}

func (v *VideoSource) fail(err error, final bool) {
	v.mu.Lock()
	v.err = err
	if final {
		v.done = true
	}
	v.mu.Unlock()
	v.cond.Broadcast()
}

// Next blocks until a frame newer than lastSeq arrives (or the source ends).
func (v *VideoSource) Next(lastSeq uint64, timeout time.Duration) ([]byte, uint64, int64, error) {
	deadline := time.Now().Add(timeout)
	t := time.AfterFunc(timeout, v.cond.Broadcast)
	defer t.Stop()
	v.mu.Lock()
	defer v.mu.Unlock()
	for v.seq == lastSeq && !v.done && time.Now().Before(deadline) {
		v.cond.Wait()
	}
	if v.seq == lastSeq {
		if v.done {
			return nil, lastSeq, -1, v.err
		}
		return nil, lastSeq, -1, nil
	}
	out := make([]byte, len(v.latest))
	copy(out, v.latest)
	return out, v.seq, v.latestPTS, nil
}

// Hi returns a copy of the sharper picture that goes with frame seq, if any.
func (v *VideoSource) Hi(seq uint64) []byte {
	v.mu.Lock()
	defer v.mu.Unlock()
	if v.seq != seq || v.latestHi == nil {
		return nil
	}
	return append([]byte(nil), v.latestHi...)
}

// HasFrames reports whether any picture has been produced yet.
func (v *VideoSource) HasFrames() bool {
	v.mu.Lock()
	defer v.mu.Unlock()
	return v.seq > 0
}

func (v *VideoSource) LastError() error {
	v.mu.Lock()
	defer v.mu.Unlock()
	return v.err
}

// tailBuffer keeps the last few lines ffmpeg wrote to stderr for error messages.
type tailBuffer struct {
	mu    sync.Mutex
	lines []string
}

func (t *tailBuffer) Write(p []byte) (int, error) {
	t.mu.Lock()
	for _, l := range strings.Split(strings.ReplaceAll(string(p), "\r", "\n"), "\n") {
		if l = strings.TrimSpace(l); l != "" {
			t.lines = append(t.lines, l)
		}
	}
	if len(t.lines) > 6 {
		t.lines = t.lines[len(t.lines)-6:]
	}
	t.mu.Unlock()
	return len(p), nil
}

func (t *tailBuffer) String() string {
	t.mu.Lock()
	defer t.mu.Unlock()
	if len(t.lines) == 0 {
		return ""
	}
	return t.lines[len(t.lines)-1]
}

// runFFmpegVideo runs ffmpeg in a loop, restarting it with backoff when the
// source drops (camera unplugged, stream hiccup). Stops when ctx ends.
// runFFmpegVideo plays one video source through ffmpeg.
//
// once=true is for files in a playlist: play to the end and return nil, or
// return an error if the file wouldn't play. once=false is for live
// sources and single looping files: restart with backoff when the source
// drops, until ctx ends; it returns an error only if the source never
// produced a picture after several tries (wrong device name, bad URL).
// avOut asks runFFmpegVideo to take the sound from the same ffmpeg as the
// picture, so both are stamped with the movie's own time.
type avOut struct {
	clock0 time.Time
	snd    *Sender
}

func runFFmpegVideo(ctx context.Context, v *VideoSource, ffmpeg string, input []string, flip bool, fps float64, subs *Subtitles, cfg *Config, once bool, av *avOut, logf func(string, ...any)) error {
	// With a sharper copy for sixel viewers, ffmpeg makes that one and the
	// usual small picture is averaged down from it here.
	outW, outH := v.W, v.H
	if v.HiW > 0 {
		outW, outH = v.HiW, v.HiH
	}
	vf := fmt.Sprintf("fps=%s,scale=%d:%d:flags=area", strconv.FormatFloat(fps, 'f', -1, 64), outW, outH)
	if flip {
		vf += ",hflip" // after shrinking: far less work
	}
	if once {
		input = withoutLoop(input)
	}
	frameBytes := outW * outH * 3
	backoff := time.Second
	everWorked := false
	for ctx.Err() == nil {
		// Subtitles ride the same ffmpeg run: video to our pipe, captions
		// as SRT to a local socket.
		in, vmap, subOut := input, []string(nil), []string(nil)
		var ln net.Listener
		if subs != nil {
			var err error
			if ln, err = net.Listen("tcp", "127.0.0.1:0"); err != nil {
				logf("subtitles: can't open a local port (%v); continuing without", err)
				subs = nil
			} else {
				in, vmap, subOut = subs.ffmpegArgs(cfg, input, ln.Addr().(*net.TCPAddr).Port)
			}
		}
		args := append([]string{"-hide_banner", "-loglevel", "error", "-nostdin"}, in...)
		args = append(args, vmap...)
		args = append(args, "-an", "-sn", "-vf", vf, "-pix_fmt", "rgb24", "-f", "rawvideo", "-")
		args = append(args, subOut...)

		// Sound from this same ffmpeg, as a second output on a local socket.
		var clk *mediaClock
		var aln net.Listener
		if av != nil {
			var err error
			if aln, err = net.Listen("tcp", "127.0.0.1:0"); err == nil {
				clk = &mediaClock{clock0: av.clock0}
				args = append(args, "-map", "0:a:0", "-vn", "-sn",
					"-ac", strconv.Itoa(cfg.AudioChannels), "-ar", strconv.Itoa(cfg.AudioRate),
					"-f", "s16le", fmt.Sprintf("tcp://127.0.0.1:%d?tcp_nodelay=1", aln.Addr().(*net.TCPAddr).Port))
			} else {
				logf("sound: can't open a local port (%v)", err)
			}
		}

		tail := &tailBuffer{}
		cmd := ffmpegCommand(ctx, ffmpeg, args...)
		cmd.Stderr = tail
		out, err := cmd.StdoutPipe()
		if err == nil {
			err = cmd.Start()
		}
		if err != nil {
			if ln != nil {
				ln.Close()
			}
			return fmt.Errorf("cannot run ffmpeg: %v", err)
		}
		audioDone := make(chan struct{})
		if aln != nil {
			go func() {
				defer close(audioDone)
				readMediaAudio(ctx, aln, cfg, newAudioStamper(cfg, av.clock0, av.snd, clk))
			}()
		} else {
			close(audioDone)
		}
		if ln != nil {
			go func(ln net.Listener, s *Subtitles) {
				defer ln.Close()
				if tl, ok := ln.(*net.TCPListener); ok {
					tl.SetDeadline(time.Now().Add(60 * time.Second))
				}
				conn, err := ln.Accept()
				if err != nil {
					return
				}
				s.readSRT(conn, logf)
			}(ln, subs)
		}
		r := bufio.NewReaderSize(out, frameBytes*2)
		got := 0
		for ctx.Err() == nil {
			buf := make([]byte, frameBytes)
			if err := readFull(r, buf); err != nil {
				break
			}
			if got == 0 {
				subs.startRun(time.Now())
			}
			pts := int64(-1)
			if clk != nil {
				// Frame N of a constant-rate stream is N/fps into the movie.
				pts = clk.anchor() + int64(float64(got)*1000/fps)
			}
			if v.HiW > 0 {
				v.putHi(resizeArea(buf, outW, outH, v.W, v.H), buf, pts)
			} else {
				v.putPTS(buf, pts)
			}
			got++
			everWorked = true
			backoff = time.Second
		}
		if ctx.Err() == nil {
			io.Copy(io.Discard, out) // let ffmpeg finish cleanly
		}
		cmd.Wait()
		if ln != nil {
			ln.Close()
		}
		if aln != nil {
			aln.Close()
		}
		<-audioDone
		if ctx.Err() != nil {
			return nil
		}
		why := tail.String()
		if why == "" {
			why = "source ended"
		}
		if subs != nil && got == 0 {
			// Don't let a subtitle problem take the picture down with it.
			logf("subtitles: couldn't read them from this source (%s); continuing without", why)
			subs = nil
			continue
		}
		if once {
			if got == 0 {
				return errors.New(why)
			}
			return nil // played to the end
		}
		if !everWorked && got == 0 && backoff >= 4*time.Second {
			return fmt.Errorf("video source failed: %s", why)
		}
		v.fail(fmt.Errorf("video: %s", why), false)
		if subs != nil && subs.mode == "cc" && fileExists(cfg.Source) && why == "source ended" {
			continue // captioned files play through and restart (no loop option there)
		}
		logf("video source stopped (%s); restarting in %ds", why, int(backoff.Seconds()))
		select {
		case <-ctx.Done():
			return nil
		case <-time.After(backoff):
		}
		backoff *= 2
		if backoff > 30*time.Second {
			backoff = 30 * time.Second
		}
	}
	return nil
}

// readMediaAudio receives the sound ffmpeg writes to the local socket and
// sends it on, stamped by movie time.
func readMediaAudio(ctx context.Context, ln net.Listener, cfg *Config, st *audioStamper) {
	if tl, ok := ln.(*net.TCPListener); ok {
		tl.SetDeadline(time.Now().Add(60 * time.Second))
	}
	conn, err := ln.Accept()
	if err != nil {
		return
	}
	defer conn.Close()
	stop := context.AfterFunc(ctx, func() { conn.Close() })
	defer stop()
	cb := chunkBytes(cfg)
	r := bufio.NewReaderSize(conn, cb*2)
	for ctx.Err() == nil {
		pcm := make([]byte, cb)
		if err := readFull(r, pcm); err != nil {
			return
		}
		st.emit(pcm)
	}
}

// withoutLoop drops "-stream_loop -1" so a playlist file plays once.
func withoutLoop(in []string) []string {
	out := make([]string, 0, len(in))
	for i := 0; i < len(in); i++ {
		if in[i] == "-stream_loop" && i+1 < len(in) {
			i++
			continue
		}
		out = append(out, in[i])
	}
	return out
}

// runTestPattern generates the animated test card at the configured fps.
func runTestPattern(ctx context.Context, v *VideoSource, cols, rows int, fps float64) {
	tick := time.NewTicker(time.Duration(float64(time.Second) / fps))
	defer tick.Stop()
	n := 0
	for {
		buf := make([]byte, cols*2*rows*3)
		testFrame(buf, cols, rows, n)
		v.put(buf)
		n++
		select {
		case <-ctx.Done():
			return
		case <-tick.C:
		}
	}
}

// runStdin reads raw rgb24 frames of inW x inH from stdin and downscales.
func runStdin(ctx context.Context, v *VideoSource, inW, inH int) {
	r := bufio.NewReaderSize(os.Stdin, inW*inH*3)
	for ctx.Err() == nil {
		buf := make([]byte, inW*inH*3)
		if err := readFull(r, buf); err != nil {
			v.fail(errors.New("stdin ended"), true)
			return
		}
		v.put(resizeArea(buf, inW, inH, v.W, v.H))
	}
}

// resizeArea is a box-filter downscale (like cv2.INTER_AREA) for RGB24.
func resizeArea(src []byte, sw, sh, dw, dh int) []byte {
	if sw == dw && sh == dh {
		return src
	}
	dst := make([]byte, dw*dh*3)
	for dy := 0; dy < dh; dy++ {
		y0, y1 := dy*sh/dh, (dy+1)*sh/dh
		if y1 <= y0 {
			y1 = y0 + 1
		}
		for dx := 0; dx < dw; dx++ {
			x0, x1 := dx*sw/dw, (dx+1)*sw/dw
			if x1 <= x0 {
				x1 = x0 + 1
			}
			var r, g, b, n int
			for y := y0; y < y1 && y < sh; y++ {
				for x := x0; x < x1 && x < sw; x++ {
					i := (y*sw + x) * 3
					r += int(src[i])
					g += int(src[i+1])
					b += int(src[i+2])
					n++
				}
			}
			o := (dy*dw + dx) * 3
			if n > 0 {
				dst[o], dst[o+1], dst[o+2] = byte(r/n), byte(g/n), byte(b/n)
			}
		}
	}
	return dst
}

// readCaption returns the last non-empty line (max 240 chars) of a file.
func readCaption(path string) []byte {
	if path == "" {
		return nil
	}
	f, err := os.Open(path)
	if err != nil {
		return nil
	}
	defer f.Close()
	if st, err := f.Stat(); err == nil && st.Size() > 512 {
		f.Seek(st.Size()-512, io.SeekStart)
	}
	tail, _ := io.ReadAll(io.LimitReader(f, 512))
	lines := strings.Split(strings.ReplaceAll(string(tail), "\r", ""), "\n")
	for i := len(lines) - 1; i >= 0; i-- {
		l := strings.TrimSpace(lines[i])
		if l == "" {
			continue
		}
		l = strings.ToValidUTF8(l, "?")
		if r := []rune(l); len(r) > 240 {
			l = string(r[:240])
		}
		return []byte(l)
	}
	return nil
}
