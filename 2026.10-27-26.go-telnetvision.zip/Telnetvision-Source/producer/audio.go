package main

import (
	"bufio"
	"context"
	"fmt"
	"io"
	"os"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// audioInputArgs resolves AUDIO_SOURCE into ffmpeg input arguments.
//
//	auto       : a file/URL video source's own sound track, else the first mic
//	mic        : first microphone / audio capture device
//	mic:<name> : a specific device (full name or part of it)
//	other      : any ffmpeg input (file or URL)
func audioInputArgs(cfg *Config, ffmpeg string) ([]string, string, error) {
	src := strings.TrimSpace(cfg.AudioSource)
	low := strings.ToLower(src)
	if low == "" || low == "auto" {
		vs := strings.ToLower(cfg.Source)
		isAV := !(vs == "camera" || strings.HasPrefix(vs, "camera:") || vs == "screen" ||
			vs == "desktop" || vs == "test" || vs == "-" || isDigits(vs))
		if isAV {
			src, low = cfg.Source, strings.ToLower(cfg.Source)
		} else {
			src, low = "mic", "mic"
		}
	}
	if low == "mic" || strings.HasPrefix(low, "mic:") || strings.HasPrefix(src, ":") {
		want := ""
		if strings.HasPrefix(low, "mic:") {
			want = strings.TrimSpace(src[4:])
		} else if strings.HasPrefix(src, ":") {
			want = strings.TrimSpace(src[1:])
		}
		switch runtime.GOOS {
		case "windows":
			devs, _ := listDevices(ffmpeg)
			name := ""
			if want == "" {
				name = firstDevice(devs, "audio")
			} else {
				name = matchDevice(devs, "audio", want)
			}
			if name == "" {
				if want == "" {
					return nil, "", fmt.Errorf("no microphone or audio capture device was found")
				}
				return nil, "", fmt.Errorf("no audio device matching %q (run with --list-devices)", want)
			}
			return []string{"-f", "dshow", "-audio_buffer_size", "50", "-i", "audio=" + name}, "mic \"" + name + "\"", nil
		case "darwin":
			if want == "" {
				want = "0"
			}
			return []string{"-f", "avfoundation", "-i", ":" + want}, "mic", nil
		default:
			if want == "" {
				want = "default"
			}
			return []string{"-f", "pulse", "-i", want}, "mic", nil
		}
	}
	var args []string
	if st, err := os.Stat(src); err == nil && !st.IsDir() {
		args = append(args, "-re", "-stream_loop", "-1")
	}
	return append(args, "-i", src), src, nil
}

// runAudio captures audio with ffmpeg, chops it into chunks, wraps each in
// WAV and sends AUDIO messages stamped on the same clock as video frames.
// pts is derived from the sample count since an anchor so chunks tile the
// timeline exactly; it re-anchors if capture stalls.
// audioSeq numbers every sound chunk sent, across sources.
var audioSeq atomic.Uint32

// audioStamper turns PCM chunks into AUDIO messages with timestamps.
//
// Stamped by movie time (media=true) when the sound comes out of the same
// ffmpeg as the picture: chunk pts = when the movie started + samples so
// far, the same clock the picture's frames use, so the two stay together.
// Otherwise (a microphone on its own) it's stamped by capture time, with
// the sample count keeping chunks evenly spaced.
type audioStamper struct {
	cfg     *Config
	clock0  time.Time
	snd     *Sender
	media   *mediaClock // nil: stamp by capture time
	anchor  int64       // capture-time anchor, -1 = not set
	samples int64
	usCarry int64
}

func newAudioStamper(cfg *Config, clock0 time.Time, snd *Sender, media *mediaClock) *audioStamper {
	return &audioStamper{cfg: cfg, clock0: clock0, snd: snd, media: media, anchor: -1}
}

func (a *audioStamper) emit(pcm []byte) {
	rate, ch, chunkMs := a.cfg.AudioRate, a.cfg.AudioChannels, a.cfg.AudioChunkMs
	var pts int64
	if a.media != nil {
		pts = a.media.anchor() + a.samples*1000/int64(rate)
	} else {
		nowMs := time.Since(a.clock0).Milliseconds()
		if a.anchor < 0 {
			a.anchor = max64(0, nowMs-int64(chunkMs))
			a.samples = 0
		}
		pts = a.anchor + a.samples*1000/int64(rate)
		if nowMs-pts > 1000 { // capture stalled: snap to the wall clock
			a.anchor = max64(0, nowMs-int64(chunkMs))
			a.samples = 0
			pts = a.anchor
		}
		if pts > nowMs { // live inputs prime with a burst; never stamp the future
			pts = nowMs
		}
	}
	pts = max64(0, pts+int64(a.cfg.AudioOffsetMs))
	a.samples += int64(len(pcm) / (2 * ch))
	// Whole milliseconds, carrying the remainder so chunk lengths add up
	// exactly (rounding each one down would drift the server's sound clock).
	us := int64(len(pcm)/(2*ch))*1000000/int64(rate) + a.usCarry
	dur := uint32(us / 1000)
	a.usCarry = us % 1000
	a.snd.SendAudio(audioPayload(audioCodecWAV, byte(ch), uint32(rate), audioSeq.Add(1)-1, uint64(pts), dur, encodeSoundClip(a.cfg.AudioCodec, pcm, rate, ch)))
}

// chunkBytes is the size of one sound chunk.
func chunkBytes(cfg *Config) int {
	per := cfg.AudioRate * cfg.AudioChunkMs / 1000
	if cfg.AudioCodec == soundADPCM {
		per = imaChunkSamples(per, cfg.AudioChannels) // whole ADPCM blocks, no padding
	}
	return per * cfg.AudioChannels * 2
}

// mediaClock is when the current movie (one ffmpeg run) started, on the
// shared clock: set by whichever of picture or sound arrives first.
type mediaClock struct {
	once   sync.Once
	ms     int64
	clock0 time.Time
}

func (m *mediaClock) anchor() int64 {
	m.once.Do(func() { m.ms = time.Since(m.clock0).Milliseconds() })
	return m.ms
}

// runAudio captures sound with its own ffmpeg (a microphone, or a sound
// source separate from the picture), stamped by capture time.
func runAudio(ctx context.Context, cfg *Config, ffmpeg string, input []string, clock0 time.Time, snd *Sender, logf func(string, ...any)) {
	rate, ch := cfg.AudioRate, cfg.AudioChannels
	cb := chunkBytes(cfg)
	args := append([]string{"-hide_banner", "-loglevel", "error", "-nostdin"}, input...)
	args = append(args, "-vn", "-f", "s16le", "-ar", strconv.Itoa(rate), "-ac", strconv.Itoa(ch), "-")

	st := newAudioStamper(cfg, clock0, snd, nil)
	backoff := time.Second
	for ctx.Err() == nil {
		tail := &tailBuffer{}
		cmd := ffmpegCommand(ctx, ffmpeg, args...)
		cmd.Stderr = tail
		out, err := cmd.StdoutPipe()
		if err == nil {
			err = cmd.Start()
		}
		if err != nil {
			logf("audio: cannot run ffmpeg (%v); audio disabled", err)
			return
		}
		r := bufio.NewReaderSize(out, cb*2)
		for ctx.Err() == nil {
			pcm := make([]byte, cb)
			if err := readFull(r, pcm); err != nil {
				break
			}
			backoff = time.Second
			st.emit(pcm)
		}
		if ctx.Err() == nil {
			io.Copy(io.Discard, out)
		}
		cmd.Wait()
		if ctx.Err() != nil {
			return
		}
		why := tail.String()
		if why == "" {
			why = "audio source ended"
		}
		logf("audio stopped (%s); restarting in %ds", why, int(backoff.Seconds()))
		st.anchor = -1 // capture gap: re-anchor pts
		select {
		case <-ctx.Done():
			return
		case <-time.After(backoff):
		}
		backoff *= 2
		if backoff > 30*time.Second {
			backoff = 30 * time.Second
		}
	}
}

func max64(a, b int64) int64 {
	if a > b {
		return a
	}
	return b
}
