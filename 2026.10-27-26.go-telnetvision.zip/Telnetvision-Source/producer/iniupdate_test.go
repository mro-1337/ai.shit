package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// The template's values must be exactly the built-in defaults, so adding a
// missing setting can never change how the program behaves.
func TestTemplateIsNeutral(t *testing.T) {
	d := defaultConfig()
	p := filepath.Join(t.TempDir(), "t.ini")
	os.WriteFile(p, []byte(d.template()), 0o600)
	got := defaultConfig()
	if err := got.loadFile(p); err != nil {
		t.Fatal(err)
	}
	if got != d {
		t.Fatalf("template changes settings:\n%+v\n%+v", got, d)
	}
}

const oldINI = "# my own note at the top\r\n" +
	"BBS_HOST=bbs.example.com\r\n" +
	"BBS_PORT=7600\r\n" +
	"TOKEN=abc123\r\n" +
	"TLS=yes\r\n" +
	"SOURCE=camera:SplitCam   # the virtual cam\r\n" +
	"AUDIO=1\r\n" +
	"AUDIO_SOURCE=mic:SplitCam Audio Mixer\r\n" +
	"AUDIO_RATE=44100\r\n" +
	"CAPTION_FILE=%TEMP%\\caption.txt\r\n" +
	"CAPTURE=2\r\n" +
	"# FPS=10\r\n"

func TestMergeKeepsEverythingAndAddsMissing(t *testing.T) {
	d := defaultConfig()
	out, added, changed := mergeINI([]byte(oldINI), d.template(), iniAliases, nil, false, true, "# --- new ---", nil)
	if !changed || !strings.HasPrefix(string(out), oldINI) {
		t.Fatalf("original text not kept byte for byte:\n%s", out)
	}
	for _, a := range added {
		if a == "FPS" {
			t.Error("FPS is commented out by the user; it must not be added back")
		}
	}
	for _, k := range []string{"SUBTITLES", "SUBTITLE_TRACK", "COLS", "PREVIEW"} {
		if !strings.Contains(strings.Join(added, ","), k) {
			t.Errorf("%s not added (added: %v)", k, added)
		}
	}
	for _, k := range []string{"BBS_HOST", "TOKEN", "TLS", "SOURCE", "AUDIO_RATE", "CAPTION_FILE"} {
		for _, a := range added {
			if a == k {
				t.Errorf("%s was already there but got added again", k)
			}
		}
	}
	if strings.Contains(string(out), "\n") && strings.Count(string(out), "\r\n") != strings.Count(string(out), "\n") {
		t.Error("mixed line endings")
	}
	// Running again changes nothing.
	if _, a2, ch2 := mergeINI(out, d.template(), iniAliases, nil, false, true, "# --- new ---", nil); ch2 || len(a2) > 0 {
		t.Fatalf("second run changed the file: %v", a2)
	}
	// The user's values still load as before.
	p := filepath.Join(t.TempDir(), "u.ini")
	os.WriteFile(p, out, 0o600)
	c := defaultConfig()
	if err := c.loadFile(p); err != nil {
		t.Fatal(err)
	}
	if c.Host != "bbs.example.com" || c.Source != "camera:SplitCam" || c.AudioRate != 44100 || !c.TLS || c.AudioSource != "mic:SplitCam Audio Mixer" {
		t.Fatalf("user values lost: %+v", c)
	}
}

func TestAliasesAndLF(t *testing.T) {
	in := "HOST=x\nPORT=1\nMIRROR=0\n"
	d := defaultConfig()
	out, added, _ := mergeINI([]byte(in), d.template(), iniAliases, nil, false, true, "", nil)
	for _, a := range added {
		if a == "BBS_HOST" || a == "BBS_PORT" || a == "PREVIEW" {
			t.Errorf("alias not recognised: added %s", a)
		}
	}
	if strings.Contains(string(out), "\r") {
		t.Error("LF file got CRLF lines")
	}
}

// --setup on an existing file: only real changes are rewritten, in place.
func TestSaveEditsInPlace(t *testing.T) {
	os.Setenv("TEMP", `C:\Users\me\AppData\Local\Temp`)
	p := filepath.Join(t.TempDir(), "telnetvision.ini")
	os.WriteFile(p, []byte(oldINI), 0o600)
	c := defaultConfig()
	if err := c.loadFile(p); err != nil {
		t.Fatal(err)
	}
	c.Source = "screen" // the one thing the user changed in setup
	if err := c.save(p); err != nil {
		t.Fatal(err)
	}
	b, _ := os.ReadFile(p)
	s := string(b)
	for _, want := range []string{
		"# my own note at the top\r\n", "TLS=yes\r\n", "SOURCE=screen  # the virtual cam\r\n",
		"CAPTION_FILE=%TEMP%\\caption.txt\r\n", "CAPTURE=2\r\n", "# FPS=10\r\n", "AUDIO_RATE=44100\r\n", "SUBTITLES=auto\r\n",
	} {
		if !strings.Contains(s, want) {
			t.Errorf("missing %q in:\n%s", want, s)
		}
	}
	if bak, err := os.ReadFile(p + ".bak"); err != nil || string(bak) != oldINI {
		t.Error("no exact backup of the old file")
	}
}

func TestCleanProducerINI(t *testing.T) {
	messy := "FPS=10\nHOST=bbs.example.com\nPORT=7600\nTOKEN=abc\nSOURCE=\"C:\\Videos\\My # Movie.mp4\"\nCAPTION_FILE=C:\\cap.txt  # my note\n#AUDIO=1\nMIRROR=0\nWEIRD=1\n"
	def := defaultConfig()
	out, added, moved, changed := cleanINI([]byte(messy), def.template(), iniAliases, nil, "telnetvision")
	if !changed || moved == 0 || len(added) == 0 {
		t.Fatalf("changed=%v moved=%d added=%d", changed, moved, len(added))
	}
	p := filepath.Join(t.TempDir(), "t.ini")
	os.WriteFile(p, out, 0o600)
	c := defaultConfig()
	if err := c.loadFile(p); err != nil {
		t.Fatal(err)
	}
	if c.Host != "bbs.example.com" || c.Port != 7600 || c.FPS != 10 || c.Source != `C:\Videos\My # Movie.mp4` ||
		c.CaptionFile != `C:\cap.txt` || c.Preview || c.Audio {
		t.Fatalf("values not kept: %+v", c)
	}
	s := string(out)
	for _, want := range []string{"BBS_HOST=bbs.example.com", "PREVIEW=0", "# AUDIO=1", "WEIRD=1"} {
		if !strings.Contains(s, want) {
			t.Errorf("missing %q", want)
		}
	}
	if _, _, _, again := cleanINI(out, def.template(), iniAliases, nil, "telnetvision"); again {
		t.Error("not stable")
	}
}
