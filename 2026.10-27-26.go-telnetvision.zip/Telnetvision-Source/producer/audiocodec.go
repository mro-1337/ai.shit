package main

// Sound clip formats SyncTERM's libsndfile plays without extra libraries:
//
//	pcm    plain 16-bit WAV             100%
//	ulaw   8-bit mu-law WAV (G.711)      50%
//	adpcm  4-bit IMA ADPCM WAV           ~26%
//
// Every clip is a complete WAV file on its own, and each one decodes to
// exactly its samples (no encoder padding), so clips played back to back
// join without clicks. Shared by telnetvision.exe and tvserver.exe.

import (
	"encoding/binary"
	"errors"
	"strings"
)

const (
	wavFmtPCM   = 0x0001
	wavFmtULaw  = 0x0007
	wavFmtIMA   = 0x0011
	soundPCM    = "pcm"
	soundULaw   = "ulaw"
	soundADPCM  = "adpcm"
	maxIMABlock = 2048 // samples per block per channel, upper bound
)

// normalizeSoundCodec maps the ways to write a codec name to one of ours.
func normalizeSoundCodec(v string) (string, bool) {
	switch strings.NewReplacer("-", "", "_", "", " ", "").Replace(strings.ToLower(strings.TrimSpace(v))) {
	case "adpcm", "imaadpcm", "ima", "auto", "":
		return soundADPCM, true
	case "ulaw", "mulaw", "μlaw", "g711", "law":
		return soundULaw, true
	case "pcm", "wav", "none", "off", "uncompressed", "raw":
		return soundPCM, true
	}
	return soundADPCM, false
}

var imaIndexTable = [16]int{-1, -1, -1, -1, 2, 4, 6, 8, -1, -1, -1, -1, 2, 4, 6, 8}

var imaStepTable = [89]int{
	7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45,
	50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 130, 143, 157, 173, 190, 209, 230,
	253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963,
	1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327,
	3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442,
	11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794,
	32767,
}

type imaState struct{ pred, index int }

// step decodes one nibble, updating the state; the encoder uses the same
// arithmetic so its idea of the signal never drifts from the decoder's.
func (s *imaState) step(nib int) int {
	st := imaStepTable[s.index]
	d := st >> 3
	if nib&4 != 0 {
		d += st
	}
	if nib&2 != 0 {
		d += st >> 1
	}
	if nib&1 != 0 {
		d += st >> 2
	}
	if nib&8 != 0 {
		s.pred -= d
	} else {
		s.pred += d
	}
	if s.pred > 32767 {
		s.pred = 32767
	} else if s.pred < -32768 {
		s.pred = -32768
	}
	s.index += imaIndexTable[nib]
	if s.index < 0 {
		s.index = 0
	} else if s.index > 88 {
		s.index = 88
	}
	return s.pred
}

func (s *imaState) encode(sample int) int {
	st := imaStepTable[s.index]
	diff := sample - s.pred
	nib := 0
	if diff < 0 {
		nib = 8
		diff = -diff
	}
	if diff >= st {
		nib |= 4
		diff -= st
	}
	if diff >= st>>1 {
		nib |= 2
		diff -= st >> 1
	}
	if diff >= st>>2 {
		nib |= 1
	}
	s.step(nib)
	return nib
}

// imaBlockPlan splits n samples (per channel) into equal blocks whose size
// fits IMA ADPCM exactly (1 + 2k samples for mono, 1 + 8k for stereo), so
// no padding is ever decoded. It returns 0 if n can't be split that way.
func imaBlockPlan(n, ch int) (blocks, spb int) {
	step := 2
	if ch == 2 {
		step = 8
	}
	best := 0
	for m := 1; m <= n; m++ {
		if n%m != 0 {
			continue
		}
		s := n / m
		if s > maxIMABlock || (s-1)%step != 0 {
			continue
		}
		best = m
		break // fewest blocks = least header overhead
	}
	if best == 0 {
		return 0, 0
	}
	return best, n / best
}

// imaChunkSamples nudges a target clip length (per channel) to the nearest
// length that splits into IMA blocks with little overhead (blocks of at
// least ~100 samples).
func imaChunkSamples(target, ch int) int {
	for d := 0; d < target/2; d++ {
		for _, n := range []int{target - d, target + d} {
			if n < 2 {
				continue
			}
			if b, spb := imaBlockPlan(n, ch); b > 0 && spb >= 101 {
				return n
			}
		}
	}
	return target
}

// encodeIMAWAV encodes interleaved 16-bit PCM as an IMA ADPCM WAV file.
// It returns an error when the length can't be blocked exactly.
func encodeIMAWAV(pcm []byte, rate, ch int) ([]byte, error) {
	if ch != 1 && ch != 2 {
		return nil, errors.New("adpcm: 1 or 2 channels only")
	}
	n := len(pcm) / (2 * ch)
	blocks, spb := imaBlockPlan(n, ch)
	if blocks == 0 {
		return nil, errors.New("adpcm: clip length doesn't split into blocks")
	}
	sample := func(i, c int) int { return int(int16(binary.LittleEndian.Uint16(pcm[(i*ch+c)*2:]))) }
	blockAlign := 4*ch + (spb-1)*ch/2
	data := make([]byte, 0, blocks*blockAlign)
	var st [2]imaState
	for b := 0; b < blocks; b++ {
		base := b * spb
		for c := 0; c < ch; c++ {
			// Each block starts with the real sample, so errors never
			// carry from one block (or clip) into the next. The step
			// index carries over: it tracks the signal's loudness.
			st[c].pred = sample(base, c)
			data = binary.LittleEndian.AppendUint16(data, uint16(int16(st[c].pred)))
			data = append(data, byte(st[c].index), 0)
		}
		if ch == 1 {
			for i := 1; i < spb; i += 2 {
				lo := st[0].encode(sample(base+i, 0))
				hi := st[0].encode(sample(base+i+1, 0))
				data = append(data, byte(lo|hi<<4))
			}
		} else {
			for i := 1; i < spb; i += 8 {
				for c := 0; c < 2; c++ {
					for k := 0; k < 8; k += 2 {
						lo := st[c].encode(sample(base+i+k, c))
						hi := st[c].encode(sample(base+i+k+1, c))
						data = append(data, byte(lo|hi<<4))
					}
				}
			}
		}
	}
	out := make([]byte, 0, 60+len(data))
	le := binary.LittleEndian
	out = append(out, "RIFF"...)
	out = le.AppendUint32(out, uint32(4+(8+20)+(8+4)+(8+len(data))))
	out = append(out, "WAVEfmt "...)
	out = le.AppendUint32(out, 20)
	out = le.AppendUint16(out, wavFmtIMA)
	out = le.AppendUint16(out, uint16(ch))
	out = le.AppendUint32(out, uint32(rate))
	out = le.AppendUint32(out, uint32(rate*blockAlign/spb))
	out = le.AppendUint16(out, uint16(blockAlign))
	out = le.AppendUint16(out, 4)
	out = le.AppendUint16(out, 2)
	out = le.AppendUint16(out, uint16(spb))
	out = append(out, "fact"...)
	out = le.AppendUint32(out, 4)
	out = le.AppendUint32(out, uint32(n))
	out = append(out, "data"...)
	out = le.AppendUint32(out, uint32(len(data)))
	return append(out, data...), nil
}

// mu-law (G.711) encode/decode.
func ulawEncode(s int) byte {
	const bias, clip = 0x84, 32635
	sign := 0
	if s < 0 {
		sign, s = 0x80, -s
	}
	if s > clip {
		s = clip
	}
	s += bias
	exp := 7
	for mask := 0x4000; s&mask == 0 && exp > 0; mask >>= 1 {
		exp--
	}
	mant := (s >> (exp + 3)) & 0x0F
	return ^byte(sign | exp<<4 | mant)
}

func ulawDecode(u byte) int {
	u = ^u
	sign := u & 0x80
	exp := int(u>>4) & 7
	mant := int(u & 0x0F)
	s := ((mant << 3) + 0x84) << exp
	s -= 0x84
	if sign != 0 {
		return -s
	}
	return s
}

func encodeULawWAV(pcm []byte, rate, ch int) []byte {
	n := len(pcm) / 2
	data := make([]byte, n)
	for i := 0; i < n; i++ {
		data[i] = ulawEncode(int(int16(binary.LittleEndian.Uint16(pcm[i*2:]))))
	}
	le := binary.LittleEndian
	out := make([]byte, 0, 58+n)
	out = append(out, "RIFF"...)
	out = le.AppendUint32(out, uint32(4+(8+18)+(8+4)+(8+n)))
	out = append(out, "WAVEfmt "...)
	out = le.AppendUint32(out, 18)
	out = le.AppendUint16(out, wavFmtULaw)
	out = le.AppendUint16(out, uint16(ch))
	out = le.AppendUint32(out, uint32(rate))
	out = le.AppendUint32(out, uint32(rate*ch))
	out = le.AppendUint16(out, uint16(ch))
	out = le.AppendUint16(out, 8)
	out = le.AppendUint16(out, 0)
	out = append(out, "fact"...)
	out = le.AppendUint32(out, 4)
	out = le.AppendUint32(out, uint32(n/ch))
	out = append(out, "data"...)
	out = le.AppendUint32(out, uint32(n))
	return append(out, data...)
}

// encodePCMWAV wraps 16-bit PCM in a plain WAV header.
func encodePCMWAV(pcm []byte, rate, ch int) []byte {
	le := binary.LittleEndian
	out := make([]byte, 0, 44+len(pcm))
	out = append(out, "RIFF"...)
	out = le.AppendUint32(out, uint32(36+len(pcm)))
	out = append(out, "WAVEfmt "...)
	out = le.AppendUint32(out, 16)
	out = le.AppendUint16(out, wavFmtPCM)
	out = le.AppendUint16(out, uint16(ch))
	out = le.AppendUint32(out, uint32(rate))
	out = le.AppendUint32(out, uint32(rate*ch*2))
	out = le.AppendUint16(out, uint16(ch*2))
	out = le.AppendUint16(out, 16)
	out = append(out, "data"...)
	out = le.AppendUint32(out, uint32(len(pcm)))
	return append(out, pcm...)
}

// encodeSoundClip makes one clip in the chosen format. ADPCM falls back to
// mu-law if the clip length can't be blocked exactly (it never is with the
// lengths we choose, but a clip must never be lost).
func encodeSoundClip(codec string, pcm []byte, rate, ch int) []byte {
	switch codec {
	case soundADPCM:
		if b, err := encodeIMAWAV(pcm, rate, ch); err == nil {
			return b
		}
		return encodeULawWAV(pcm, rate, ch)
	case soundULaw:
		return encodeULawWAV(pcm, rate, ch)
	}
	return encodePCMWAV(pcm, rate, ch)
}

// decodeWAV turns a PCM, mu-law or IMA ADPCM WAV clip back into 16-bit PCM.
func decodeWAV(b []byte) (pcm []byte, rate, ch int, err error) {
	le := binary.LittleEndian
	if len(b) < 12 || string(b[:4]) != "RIFF" || string(b[8:12]) != "WAVE" {
		return nil, 0, 0, errors.New("not a WAV file")
	}
	var fmtTag, bits, blockAlign, spb int
	var data []byte
	frames := -1
	for p := 12; p+8 <= len(b); {
		id, size := string(b[p:p+4]), int(le.Uint32(b[p+4:]))
		body := b[p+8:]
		if size > len(body) {
			size = len(body)
		}
		body = body[:size]
		switch id {
		case "fmt ":
			if size < 16 {
				return nil, 0, 0, errors.New("short fmt chunk")
			}
			fmtTag = int(le.Uint16(body))
			ch = int(le.Uint16(body[2:]))
			rate = int(le.Uint32(body[4:]))
			blockAlign = int(le.Uint16(body[12:]))
			bits = int(le.Uint16(body[14:]))
			if fmtTag == wavFmtIMA && size >= 20 {
				spb = int(le.Uint16(body[18:]))
			}
		case "fact":
			if size >= 4 {
				frames = int(le.Uint32(body))
			}
		case "data":
			data = body
		}
		p += 8 + size + size&1
	}
	if ch < 1 || ch > 2 || data == nil {
		return nil, 0, 0, errors.New("unsupported WAV")
	}
	switch {
	case fmtTag == wavFmtPCM && bits == 16:
		return data[:len(data)/2*2], rate, ch, nil
	case fmtTag == wavFmtULaw:
		out := make([]byte, 0, len(data)*2)
		for _, u := range data {
			out = le.AppendUint16(out, uint16(int16(ulawDecode(u))))
		}
		return out, rate, ch, nil
	case fmtTag == wavFmtIMA && spb > 0 && blockAlign >= 4*ch:
		out := make([]byte, 0, len(data)/blockAlign*spb*ch*2)
		for off := 0; off+blockAlign <= len(data); off += blockAlign {
			blk := data[off : off+blockAlign]
			samples := make([][]int, ch)
			var st [2]imaState
			for c := 0; c < ch; c++ {
				st[c] = imaState{pred: int(int16(le.Uint16(blk[c*4:]))), index: min(int(blk[c*4+2]), 88)}
				samples[c] = append(make([]int, 0, spb), st[c].pred)
			}
			nib := blk[4*ch:]
			if ch == 1 {
				for _, x := range nib {
					samples[0] = append(samples[0], st[0].step(int(x&15)), st[0].step(int(x>>4)))
				}
			} else {
				for i := 0; i+8 <= len(nib); i += 8 {
					for c := 0; c < 2; c++ {
						for _, x := range nib[i+c*4 : i+c*4+4] {
							samples[c] = append(samples[c], st[c].step(int(x&15)), st[c].step(int(x>>4)))
						}
					}
				}
			}
			for i := 0; i < spb && i < len(samples[0]); i++ {
				for c := 0; c < ch; c++ {
					out = le.AppendUint16(out, uint16(int16(samples[c][i])))
				}
			}
		}
		if frames >= 0 && frames*ch*2 < len(out) {
			out = out[:frames*ch*2]
		}
		return out, rate, ch, nil
	}
	return nil, 0, 0, errors.New("unsupported WAV encoding")
}

// downmixResample converts 16-bit PCM to at most maxRate Hz and maxCh
// channels, by whole factors (2, 3, 4...) so clip lengths stay exact and
// clips still join seamlessly. Each output sample averages its inputs,
// which also filters out what the lower rate can't carry.
func downmixResample(pcm []byte, rate, ch, maxRate, maxCh int) ([]byte, int, int) {
	le := binary.LittleEndian
	n := len(pcm) / (2 * ch)
	outCh := ch
	if maxCh > 0 && maxCh < ch {
		outCh = maxCh
	}
	factor := 1
	if maxRate > 0 && rate > maxRate {
		factor = (rate + maxRate/2) / maxRate // nearest whole factor
		if factor > 8 {
			factor = 8
		}
		for factor > 1 && n%factor != 0 {
			factor--
		}
	}
	if factor == 1 && outCh == ch {
		return pcm, rate, ch
	}
	out := make([]byte, 0, n/factor*outCh*2)
	for i := 0; i+factor <= n; i += factor {
		var acc [2]int
		for k := 0; k < factor; k++ {
			for c := 0; c < ch; c++ {
				acc[c] += int(int16(le.Uint16(pcm[((i+k)*ch+c)*2:])))
			}
		}
		if outCh == 1 && ch == 2 {
			out = le.AppendUint16(out, uint16(int16((acc[0]+acc[1])/(2*factor))))
		} else {
			for c := 0; c < outCh; c++ {
				out = le.AppendUint16(out, uint16(int16(acc[c]/factor)))
			}
		}
	}
	return out, rate / factor, outCh
}
