package main

// Settings-file upkeep shared by telnetvision.exe and tvserver.exe.
//
// cleanINI (used at every start) rewrites the file in the current
// version's layout: every setting in its section, under its explanation,
// with the user's own values kept. See cleanINI.
//
// mergeINI (used by setup) never removes or reorders anything. It can:
//   - append settings the file doesn't have yet (with their explanation),
//     taken from a template of the current version's settings, and
//   - optionally (update=true) change the value of settings already there,
//     editing just the value on those lines.
// Comments, blank lines, unknown keys and their order are kept as they are.

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

type iniSection struct {
	comments []string
	keys     []string // canonical (lower-case) key names, in order
	lines    map[string]string
	values   map[string]string
}

// parseTemplate splits a template into sections: runs of comment lines and
// key=value lines separated by blank lines.
func parseTemplate(t string) []iniSection {
	var out []iniSection
	cur := iniSection{lines: map[string]string{}, values: map[string]string{}}
	flush := func() {
		if len(cur.keys) > 0 {
			out = append(out, cur)
		}
		cur = iniSection{lines: map[string]string{}, values: map[string]string{}}
	}
	for _, raw := range strings.Split(strings.ReplaceAll(t, "\r\n", "\n"), "\n") {
		line := strings.TrimSpace(raw)
		switch {
		case line == "":
			flush()
		case line[0] == '#' || line[0] == ';':
			if len(cur.keys) > 0 { // a comment after keys starts a new section
				flush()
			}
			cur.comments = append(cur.comments, raw)
		default:
			k, v, ok := strings.Cut(line, "=")
			if !ok {
				continue
			}
			key := strings.ToLower(strings.TrimSpace(k))
			cur.keys = append(cur.keys, key)
			cur.lines[key] = raw
			cur.values[key] = strings.TrimSpace(v)
		}
	}
	flush()
	return out
}

// iniKeyOf returns the canonical key on a settings line, or "".
func iniKeyOf(line string, aliases map[string]string) string {
	l := strings.TrimSpace(strings.TrimPrefix(line, "\ufeff"))
	if l == "" || l[0] == '#' || l[0] == ';' || l[0] == '[' {
		return ""
	}
	k, _, ok := strings.Cut(l, "=")
	if !ok {
		return ""
	}
	key := strings.ToLower(strings.TrimSpace(k))
	if a, ok := aliases[key]; ok {
		key = a
	}
	return key
}

func isPlainKey(k string) bool {
	for _, r := range k {
		if !(r >= 'a' && r <= 'z' || r >= '0' && r <= '9' || r == '_') {
			return false
		}
	}
	return k != ""
}

// setLineValue replaces the value on a key=value line, keeping the key's
// spelling, the spacing around '=', and (when the format has them) a
// trailing " # comment".
func setLineValue(line, value string, trailingComments bool) string {
	eq := strings.Index(line, "=")
	head, rest := line[:eq+1], line[eq+1:]
	lead := rest[:len(rest)-len(strings.TrimLeft(rest, " \t"))]
	body := strings.TrimSpace(rest)
	tail := ""
	if trailingComments && !(strings.HasPrefix(body, `"`) || strings.HasPrefix(body, `'`)) {
		if i := strings.Index(body, " #"); i >= 0 {
			tail = "  " + strings.TrimSpace(body[i:])
		}
	}
	if trailingComments && strings.Contains(value, " #") {
		value = `"` + value + `"`
	}
	return head + lead + value + tail
}

// lineValue is the value on a key=value line, as the loaders read it.
func lineValue(line string, trailingComments bool) string {
	_, v, _ := strings.Cut(line, "=")
	v = strings.TrimSpace(v)
	if len(v) >= 2 && (v[0] == '"' && v[len(v)-1] == '"' || v[0] == '\'' && v[len(v)-1] == '\'') {
		return v[1 : len(v)-1]
	}
	if trailingComments {
		if i := strings.Index(v, " #"); i >= 0 {
			v = strings.TrimSpace(v[:i])
		}
	}
	return v
}

// mergeINI returns the new file contents, the keys it added, and whether
// anything changed.
//
// With update, same decides whether an existing value already means the new
// one (so "TLS=yes" or "%TEMP%\\cap.txt" are left exactly as written).
func mergeINI(existing []byte, template string, aliases map[string]string, skip map[string]bool,
	update, trailingComments bool, header string, same func(old, new string) bool) ([]byte, []string, bool) {

	text := string(existing)
	nl := "\n"
	if strings.Contains(text, "\r\n") || text == "" {
		nl = "\r\n"
	}
	lines := strings.Split(strings.ReplaceAll(text, "\r\n", "\n"), "\n")
	if len(lines) > 0 && lines[len(lines)-1] == "" {
		lines = lines[:len(lines)-1] // the file's final newline
	}
	have := map[string][]int{}
	commented := map[string]bool{} // "# key = value": the user switched it off on purpose
	for i, l := range lines {
		if k := iniKeyOf(l, aliases); k != "" {
			have[k] = append(have[k], i)
		} else if t := strings.TrimLeft(strings.TrimSpace(l), "#; \t"); t != "" {
			if k := iniKeyOf(t, aliases); k != "" && isPlainKey(k) {
				commented[k] = true
			}
		}
	}

	changed := false
	var added []string
	var addLines []string
	for _, sec := range parseTemplate(template) {
		var missing []string
		for _, k := range sec.keys {
			if skip[k] {
				continue
			}
			if idx, ok := have[k]; ok {
				if update {
					for _, i := range idx {
						if same != nil && same(lineValue(lines[i], trailingComments), sec.values[k]) {
							continue
						}
						nv := setLineValue(lines[i], sec.values[k], trailingComments)
						if nv != lines[i] {
							lines[i], changed = nv, true
						}
					}
				}
				continue
			}
			if commented[k] {
				continue
			}
			missing = append(missing, k)
		}
		if len(missing) == 0 {
			continue
		}
		addLines = append(addLines, "")
		addLines = append(addLines, sec.comments...)
		for _, k := range missing {
			addLines = append(addLines, sec.lines[k])
			added = append(added, strings.TrimSpace(strings.SplitN(sec.lines[k], "=", 2)[0]))
		}
	}
	if len(addLines) > 0 {
		if len(lines) > 0 && header != "" {
			lines = append(lines, "", header)
		}
		lines = append(lines, addLines...)
		changed = true
	}
	return []byte(strings.Join(lines, nl) + nl), added, changed
}

// writeINISafely keeps a .bak of the old file, then replaces it in one step
// so a crash or full disk can never leave a half-written settings file.
func writeINISafely(path string, data []byte) error {
	if old, err := os.ReadFile(path); err == nil {
		if err := os.WriteFile(path+".bak", old, 0o600); err != nil {
			return fmt.Errorf("couldn't save a backup copy: %w", err)
		}
	}
	tmp := filepath.Join(filepath.Dir(path), "."+filepath.Base(path)+".new")
	if err := os.WriteFile(tmp, data, 0o600); err != nil {
		return err
	}
	if err := os.Rename(tmp, path); err != nil {
		os.Remove(tmp)
		return err
	}
	return nil
}

// cleanINI rebuilds a settings file from the current template:
//   - every setting goes back to its place and section, under the
//     template's up-to-date explanation, spelled the current way (old
//     names like HOST become BBS_HOST);
//   - the user's value is kept exactly as written; if a setting appears
//     twice, the one that counts (the last) is kept;
//   - a setting the user switched off ("# key = value") stays switched off,
//     in its new place;
//   - settings the file doesn't have are added at their defaults;
//   - settings this version doesn't know are kept at the end, so nothing
//     is ever lost. The user's own comments are replaced by the template's.
//
// It returns the new contents, the settings added, how many settings
// moved, and whether anything changed. skip lists template keys that are
// never added (the server's token must be the user's own).
func cleanINI(existing []byte, template string, aliases map[string]string, skip map[string]bool,
	program string) (out []byte, added []string, moved int, changed bool) {

	text := strings.TrimPrefix(string(existing), "\ufeff")
	lines := strings.Split(strings.ReplaceAll(text, "\r\n", "\n"), "\n")
	type val struct {
		raw   string // the value exactly as written, after '='
		order int    // position among the file's settings (for "moved")
	}
	active := map[string]val{}
	off := map[string]string{} // switched-off settings: key -> value
	var unknown []string       // settings the template doesn't have, as written
	n := 0
	for _, l := range lines {
		t := strings.TrimSpace(l)
		if k := iniKeyOf(l, aliases); k != "" {
			_, v, _ := strings.Cut(t, "=")
			active[k] = val{strings.TrimSpace(v), n}
			n++
			continue
		}
		// "#KEY=value" or "# KEY = value": a setting switched off. (Not the
		// indented examples inside explanations, like "#   adpcm = ...".)
		if c := strings.TrimLeft(t, "#;"); c != t && !strings.HasPrefix(c, "  ") && !strings.HasPrefix(c, "\t") {
			c = strings.TrimSpace(c)
			if k := iniKeyOf(c, aliases); k != "" && isPlainKey(k) {
				_, v, _ := strings.Cut(c, "=")
				off[k] = strings.TrimSpace(v)
			}
		}
	}

	var outLines []string
	known := map[string]bool{}
	var userOrder []int // the user's positions, in template order
	for _, raw := range strings.Split(strings.ReplaceAll(template, "\r\n", "\n"), "\n") {
		k := iniKeyOf(raw, nil)
		if k == "" {
			outLines = append(outLines, raw)
			continue
		}
		known[k] = true
		eq := strings.Index(raw, "=")
		head := raw[:eq+1]
		if rest := raw[eq+1:]; strings.HasPrefix(rest, " ") {
			head += " "
		}
		if v, ok := active[k]; ok {
			userOrder = append(userOrder, v.order)
			outLines = append(outLines, head+v.raw)
			continue
		}
		if v, ok := off[k]; ok {
			outLines = append(outLines, "# "+head+v)
			continue
		}
		if skip[k] {
			continue
		}
		outLines = append(outLines, raw)
		added = append(added, strings.TrimSpace(raw[:eq]))
	}
	// Settings that moved = all of them minus the longest run already in
	// the right order (the fewest moves that sort the file).
	if len(userOrder) > 0 {
		best := make([]int, len(userOrder))
		longest := 0
		for i := range userOrder {
			best[i] = 1
			for j := 0; j < i; j++ {
				if userOrder[j] < userOrder[i] && best[j]+1 > best[i] {
					best[i] = best[j] + 1
				}
			}
			if best[i] > longest {
				longest = best[i]
			}
		}
		moved = len(userOrder) - longest
	}
	for len(outLines) > 0 && outLines[len(outLines)-1] == "" {
		outLines = outLines[:len(outLines)-1]
	}
	for _, l := range lines {
		if k := iniKeyOf(l, aliases); k != "" && !known[k] {
			unknown = append(unknown, strings.TrimSpace(l))
		}
	}
	if len(unknown) > 0 {
		outLines = append(outLines, "",
			"# --- Settings "+program+" doesn't use. Kept so nothing is lost;",
			"# --- check the spelling, or delete them if you don't need them.")
		outLines = append(outLines, unknown...)
	}
	result := strings.Join(outLines, "\r\n") + "\r\n"
	norm := func(s string) string {
		return strings.TrimRight(strings.ReplaceAll(strings.TrimPrefix(s, "\ufeff"), "\r\n", "\n"), "\n")
	}
	changed = norm(result) != norm(string(existing))
	return []byte(result), added, moved, changed
}

// upgradeINI tidies the settings file into the current layout (see
// cleanINI) and reports what it did. Errors are reported but never fatal.
func upgradeINI(path, template string, aliases map[string]string, skip map[string]bool,
	trailingComments bool, program string, logf func(string, ...any)) {
	old, err := os.ReadFile(path)
	if err != nil {
		return
	}
	data, added, moved, changed := cleanINI(old, template, aliases, skip, program)
	if !changed {
		return
	}
	if err := writeINISafely(path, data); err != nil {
		logf("couldn't tidy %s: %v", filepath.Base(path), err)
		return
	}
	var what []string
	if moved > 0 {
		what = append(what, fmt.Sprintf("put %d setting(s) back in their sections", moved))
	}
	if len(added) > 0 {
		what = append(what, fmt.Sprintf("added %d new setting(s) at their defaults (%s)", len(added), strings.Join(added, ", ")))
	}
	if len(what) == 0 {
		what = append(what, "updated the explanations and layout")
	}
	logf("tidied %s: %s. Your values were kept; the old copy is %s.bak",
		filepath.Base(path), strings.Join(what, "; "), filepath.Base(path))
}
