package main

// Producer-side wire protocol (version 2), byte-for-byte compatible with
// wire.py and the Go service/door in the upstream repo.
//
// Framing: every message is uint32 length (big-endian) + payload.
//   HELLO_PRODUCER 0x01: 0x01 | u8 tokenLen | token | u8 chanLen | channel | [u8 caps]
//   FRAME          0x10: 0x10 | u16 cols | u16 rows | u8 mode | u8 ramp
//                        | u16 capLen | caption | pixels[2*rows*cols*3] | u64 pts_ms
//   AUDIO          0x11: 0x11 | u8 codec | u8 channels | u32 rate | u32 seq
//                        | u64 pts_ms | u32 dur_ms | payload

import (
	"encoding/binary"
	"errors"
	"io"
	"strings"
)

const (
	msgHelloProducer = 0x01
	msgFrame         = 0x10
	msgAudio         = 0x11

	capAudio = 0x01

	audioCodecWAV = 2

	modeHalf = 0
	modeRamp = 1

	rampASCII  = 0
	rampShades = 1
)

// framed prepends the 4-byte big-endian length.
func framed(payload []byte) []byte {
	out := make([]byte, 4+len(payload))
	binary.BigEndian.PutUint32(out, uint32(len(payload)))
	copy(out[4:], payload)
	return out
}

func helloProducer(token, channel string, caps byte) ([]byte, error) {
	if len(token) > 255 || len(channel) > 255 {
		return nil, errors.New("token and channel must each be 255 bytes or less")
	}
	p := []byte{msgHelloProducer, byte(len(token))}
	p = append(p, token...)
	p = append(p, byte(len(channel)))
	p = append(p, channel...)
	if caps != 0 {
		p = append(p, caps)
	}
	return framed(p), nil
}

// framePayload builds a FRAME. A non-empty title is appended after the
// pts as  'T' 'I' u16 len  title (UTF-8): older doors and relays read
// only up to the pts and ignore it.
func framePayload(cols, rows int, mode, ramp byte, caption []byte, pixels []byte, ptsMs uint64, title string) []byte {
	if len(caption) > 65535 {
		caption = caption[:65535]
	}
	p := make([]byte, 0, 1+4+2+2+len(caption)+len(pixels)+8)
	p = append(p, msgFrame)
	p = binary.BigEndian.AppendUint16(p, uint16(cols))
	p = binary.BigEndian.AppendUint16(p, uint16(rows))
	p = append(p, mode, ramp)
	p = binary.BigEndian.AppendUint16(p, uint16(len(caption)))
	p = append(p, caption...)
	p = append(p, pixels...)
	p = binary.BigEndian.AppendUint64(p, ptsMs)
	if title != "" {
		if len(title) > 255 {
			title = strings.ToValidUTF8(title[:255], "")
		}
		p = append(p, 'T', 'I')
		p = binary.BigEndian.AppendUint16(p, uint16(len(title)))
		p = append(p, title...)
	}
	return framed(p)
}

// hiPayload is the sharper picture for sixel viewers:
//
//	FRAME_HI 0x13: 0x13 | u16 width | u16 height | u64 pts_ms | pixels[w*h*3]
//
// It's only sent to tvserver, and only while it asks for it (WANT_HI).
func hiPayload(w, h int, pixels []byte, ptsMs uint64) []byte {
	p := make([]byte, 0, 13+len(pixels))
	p = append(p, msgFrameHi)
	p = binary.BigEndian.AppendUint16(p, uint16(w))
	p = binary.BigEndian.AppendUint16(p, uint16(h))
	p = binary.BigEndian.AppendUint64(p, ptsMs)
	p = append(p, pixels...)
	return framed(p)
}

func audioPayload(codec, channels byte, rate, seq uint32, ptsMs uint64, durMs uint32, data []byte) []byte {
	p := make([]byte, 0, 3+4+4+8+4+len(data))
	p = append(p, msgAudio, codec, channels)
	p = binary.BigEndian.AppendUint32(p, rate)
	p = binary.BigEndian.AppendUint32(p, seq)
	p = binary.BigEndian.AppendUint64(p, ptsMs)
	p = binary.BigEndian.AppendUint32(p, durMs)
	p = append(p, data...)
	return framed(p)
}

// wavEncode wraps raw S16LE PCM in a canonical RIFF/WAVE header.
func wavEncode(pcm []byte, rate, channels int) []byte {
	out := make([]byte, 0, 44+len(pcm))
	le := binary.LittleEndian
	out = append(out, "RIFF"...)
	out = le.AppendUint32(out, uint32(36+len(pcm)))
	out = append(out, "WAVEfmt "...)
	out = le.AppendUint32(out, 16)
	out = le.AppendUint16(out, 1)
	out = le.AppendUint16(out, uint16(channels))
	out = le.AppendUint32(out, uint32(rate))
	out = le.AppendUint32(out, uint32(rate*channels*2))
	out = le.AppendUint16(out, uint16(channels*2))
	out = le.AppendUint16(out, 16)
	out = append(out, "data"...)
	out = le.AppendUint32(out, uint32(len(pcm)))
	return append(out, pcm...)
}

// readFull is io.ReadFull that treats a short final read as EOF.
func readFull(r io.Reader, buf []byte) error {
	_, err := io.ReadFull(r, buf)
	return err
}
