package main

// The player decides what is on air. A source is one of:
//   - a folder: every video in it and its subfolders becomes a playlist
//   - a video file: a one-item playlist
//   - something live: camera, camera:<name>, a number, screen, test, a URL
//
// Playlists loop (and re-scan their folders for new files each time
// round), unplayable files are skipped, and each file's own sound and
// subtitles follow it. Sources can be switched, added to, and skipped
// through while running, from the keyboard.

import (
	"context"
	"errors"
	"fmt"
	"io/fs"
	"math/rand"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"
	"unicode"
)

var videoExts = map[string]bool{
	".mp4": true, ".m4v": true, ".mkv": true, ".avi": true, ".mov": true, ".wmv": true,
	".asf": true, ".flv": true, ".f4v": true, ".webm": true, ".mpg": true, ".mpeg": true,
	".mpe": true, ".m2v": true, ".ts": true, ".m2ts": true, ".mts": true, ".vob": true,
	".3gp": true, ".3g2": true, ".ogv": true, ".ogm": true, ".divx": true, ".xvid": true,
	".rm": true, ".rmvb": true, ".dv": true, ".y4m": true,
}

func isVideoFile(p string) bool { return videoExts[strings.ToLower(filepath.Ext(p))] }

func isDir(p string) bool {
	st, err := os.Stat(p)
	return err == nil && st.IsDir()
}

// cleanPath tidies a typed or dragged-in path: Windows wraps paths with
// spaces in quotes when you drag a file or folder onto the window.
func cleanPath(s string) string {
	s = strings.TrimSpace(s)
	if len(s) >= 2 && (s[0] == '"' && s[len(s)-1] == '"' || s[0] == '\'' && s[len(s)-1] == '\'') {
		s = strings.TrimSpace(s[1 : len(s)-1])
	}
	return s
}

// scanFolder lists every video under root, in natural order.
func scanFolder(root string) ([]string, error) {
	var out []string
	err := filepath.WalkDir(root, func(p string, d fs.DirEntry, err error) error {
		if err != nil {
			if p == root {
				return err
			}
			return nil // unreadable subfolder: skip it, keep going
		}
		name := d.Name()
		if d.IsDir() {
			if p != root && (strings.HasPrefix(name, ".") || strings.HasPrefix(name, "$") ||
				strings.EqualFold(name, "System Volume Information")) {
				return filepath.SkipDir
			}
			return nil
		}
		if strings.HasPrefix(name, "._") || !isVideoFile(name) {
			return nil
		}
		out = append(out, p)
		return nil
	})
	sort.SliceStable(out, func(i, j int) bool { return naturalLess(out[i], out[j]) })
	return out, err
}

// naturalLess orders "Episode 2" before "Episode 10", ignoring case.
func naturalLess(a, b string) bool {
	ar, br := []rune(strings.ToLower(a)), []rune(strings.ToLower(b))
	i, j := 0, 0
	for i < len(ar) && j < len(br) {
		if unicode.IsDigit(ar[i]) && unicode.IsDigit(br[j]) {
			si := i
			for i < len(ar) && unicode.IsDigit(ar[i]) {
				i++
			}
			sj := j
			for j < len(br) && unicode.IsDigit(br[j]) {
				j++
			}
			na := strings.TrimLeft(string(ar[si:i]), "0")
			nb := strings.TrimLeft(string(br[sj:j]), "0")
			if len(na) != len(nb) {
				return len(na) < len(nb)
			}
			if na != nb {
				return na < nb
			}
			continue
		}
		if ar[i] != br[j] {
			// Path separators sort first so a folder's files stay together.
			if ar[i] == '/' || ar[i] == '\\' {
				return true
			}
			if br[j] == '/' || br[j] == '\\' {
				return false
			}
			return ar[i] < br[j]
		}
		i++
		j++
	}
	return len(ar)-i < len(br)-j
}

// checkSource reports why src can't be played, without touching playback.
func checkSource(src string) error {
	src = cleanPath(src)
	switch {
	case src == "":
		return errors.New("nothing entered")
	case isLiveSource(src):
		return nil
	case isDir(src):
		if f, err := scanFolder(src); err != nil {
			return fmt.Errorf("can't read folder %s: %v", src, err)
		} else if len(f) == 0 {
			return fmt.Errorf("no video files in %s or its subfolders", src)
		}
		return nil
	case fileExists(src):
		return nil
	}
	return fmt.Errorf("can't find %q (not a file, folder, URL, camera, screen or test)", src)
}

// isLiveSource reports whether s is a camera / screen / test / URL source.
func isLiveSource(s string) bool {
	l := strings.ToLower(strings.TrimSpace(s))
	return l == "camera" || strings.HasPrefix(l, "camera:") || isDigits(l) ||
		l == "screen" || l == "desktop" || l == "test" || isURL(s)
}

type playerCmd struct {
	kind string // "switch" | "add" | "next" | "prev"
	arg  string
}

type Player struct {
	base   *Config
	ffmpeg string
	v      *VideoSource
	snd    *Sender
	clock0 time.Time
	logf   func(string, ...any)

	cmds   chan playerCmd
	runCtx context.Context

	mu      sync.Mutex
	roots   []string // folders/files the playlist is built from
	items   []string // in playing order
	ordered []string // the same videos in folder order (for turning shuffle off)
	shuffle bool
	pos     int
	live    string // live source when not playing a playlist
	nowDesc string
	nowFile string // file playing now ("" for a live source)

	subs atomic.Pointer[Subtitles]

	// Audio that isn't tied to one file (a microphone) keeps running
	// across items; the file's own sound restarts with each file.
	audioKey    string
	audioCancel context.CancelFunc
	audioDone   chan struct{}
}

func NewPlayer(cfg *Config, ffmpeg string, v *VideoSource, snd *Sender, clock0 time.Time, logf func(string, ...any)) *Player {
	return &Player{base: cfg, ffmpeg: ffmpeg, v: v, snd: snd, clock0: clock0, logf: logf, cmds: make(chan playerCmd, 8), shuffle: cfg.Shuffle}
}

func (p *Player) Command(kind, arg string) {
	select {
	case p.cmds <- playerCmd{kind, arg}:
	default:
	}
}

func (p *Player) Subs() *Subtitles { return p.subs.Load() }

// Title is the name for viewers' title bar: the movie's name for a file,
// otherwise the TITLE setting.
func (p *Player) Title() string {
	if !p.base.ShowTitle {
		return ""
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.nowFile != "" {
		return tidyTitle(p.nowFile)
	}
	return p.base.Title
}

// tidyTitle makes a readable name from a file: no folder or extension, and
// dots or underscores used as spaces become spaces.
func tidyTitle(path string) string {
	name := filepath.Base(path)
	name = strings.TrimSuffix(name, filepath.Ext(name))
	if !strings.Contains(name, " ") {
		name = strings.NewReplacer(".", " ", "_", " ").Replace(name)
	}
	return strings.Join(strings.Fields(name), " ")
}

// NowPlaying is a short label for the status line.
func (p *Player) NowPlaying() string {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.nowDesc
}

// load turns a source into either a playlist or a live source.
func (p *Player) load(src string, add bool) error {
	src = cleanPath(src)
	if src == "" {
		return errors.New("nothing entered")
	}
	if isLiveSource(src) {
		if add {
			return errors.New("only files and folders can be added to the playlist; use S to switch to " + src)
		}
		p.mu.Lock()
		p.live, p.roots, p.items, p.ordered, p.pos = src, nil, nil, nil, 0
		p.mu.Unlock()
		return nil
	}
	var found []string
	switch {
	case isDir(src):
		var err error
		if found, err = scanFolder(src); err != nil {
			return fmt.Errorf("can't read folder %s: %v", src, err)
		}
		if len(found) == 0 {
			return fmt.Errorf("no video files in %s or its subfolders", src)
		}
	case fileExists(src):
		found = []string{src}
	default:
		return fmt.Errorf("can't find %q (not a file, folder, URL, camera, screen or test)", src)
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	order := append([]string(nil), found...)
	if p.shuffle {
		shuffled(found)
	}
	if add && p.live == "" && len(p.items) > 0 {
		p.roots = append(p.roots, src)
		p.items = append(p.items, found...)
		p.ordered = append(p.ordered, order...)
		return nil
	}
	p.live, p.roots, p.items, p.ordered, p.pos = "", []string{src}, found, order, 0
	return nil
}

// rescan rebuilds the playlist from its folders (new files show up).
func (p *Player) rescan() {
	p.mu.Lock()
	roots := append([]string(nil), p.roots...)
	p.mu.Unlock()
	var all []string
	for _, r := range roots {
		if isDir(r) {
			if f, err := scanFolder(r); err == nil {
				all = append(all, f...)
			}
		} else if fileExists(r) {
			all = append(all, r)
		}
	}
	if len(all) == 0 {
		return // folder gone for now: keep the old list
	}
	p.mu.Lock()
	p.ordered = append([]string(nil), all...)
	if p.shuffle {
		shuffled(all) // a fresh order every time round
	}
	p.items = all
	p.mu.Unlock()
}

func shuffled(s []string) {
	rand.Shuffle(len(s), func(i, j int) { s[i], s[j] = s[j], s[i] })
}

// setShuffle turns shuffle on or off without interrupting the video that's
// playing: on, the rest of the playlist is put in random order; off, it
// carries on in folder order from the current video.
func (p *Player) setShuffle(on bool) {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.shuffle = on
	if p.live != "" || len(p.items) == 0 {
		return
	}
	cur := ""
	if p.pos >= 0 && p.pos < len(p.items) {
		cur = p.items[p.pos]
	}
	if on {
		rest := make([]string, 0, len(p.items))
		for i, it := range p.items {
			if i != p.pos {
				rest = append(rest, it)
			}
		}
		shuffled(rest)
		if cur != "" {
			p.items = append([]string{cur}, rest...)
		} else {
			p.items = rest
		}
		p.pos = 0
	} else {
		p.items = append([]string(nil), p.ordered...)
		p.pos = 0
		for i, it := range p.items {
			if it == cur {
				p.pos = i
				break
			}
		}
	}
	if cur != "" {
		p.nowDesc = fmt.Sprintf("%d/%d %s", p.pos+1, len(p.items), filepath.Base(cur))
	}
}

// Shuffling reports whether the playlist plays in random order.
func (p *Player) Shuffling() bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.shuffle
}

// itemConfig is the base settings with this item as the source.
func (p *Player) itemConfig(src string) *Config {
	c := *p.base
	c.Source = src
	return &c
}

// setAudio makes sure the right sound is running for this item.
func (p *Player) setAudio(ctx context.Context, c *Config, perFile bool) {
	if !p.base.Audio {
		return
	}
	args, desc, err := audioInputArgs(c, p.ffmpeg)
	key := strings.Join(args, "\x00")
	if err == nil && !perFile && key == p.audioKey && p.audioCancel != nil {
		return // the same microphone keeps running
	}
	p.stopAudio()
	if err != nil {
		p.logf("sound: %v", err)
		return
	}
	// A file's own sound ends with the file; a microphone keeps going
	// across videos, so it hangs off the player, not this one item.
	parent := ctx
	if !perFile {
		parent = p.runCtx
	}
	actx, cancel := context.WithCancel(parent)
	done := make(chan struct{})
	p.audioKey, p.audioCancel, p.audioDone = key, cancel, done
	if !perFile {
		p.logf("sound: %s", desc)
	}
	go func() {
		defer close(done)
		runAudio(actx, c, p.ffmpeg, args, p.clock0, p.snd, p.logf)
	}()
}

func (p *Player) stopAudio() {
	if p.audioCancel != nil {
		p.audioCancel()
		<-p.audioDone
		p.audioCancel, p.audioKey = nil, ""
	}
}

// audioFollowsFile: with AUDIO_SOURCE=auto a file plays its own sound.
func (p *Player) audioFollowsFile() bool {
	a := strings.ToLower(strings.TrimSpace(p.base.AudioSource))
	return a == "" || a == "auto"
}

// playOne runs one item until it ends (files) or ctx is cancelled.
// It returns nil when a file played through.
func (p *Player) playOne(ctx context.Context, src string, file bool) error {
	c := p.itemConfig(src)
	if strings.EqualFold(src, "test") {
		p.subs.Store(nil)
		p.setAudio(ctx, c, false)
		runTestPattern(ctx, p.v, c.Cols, c.Rows, c.FPS)
		return nil
	}
	input, autoFlip, _, err := videoInputArgs(c, p.ffmpeg)
	if err != nil {
		return err
	}
	flip := autoFlip
	if c.Flip == "1" {
		flip = true
	} else if c.Flip == "0" {
		flip = false
	}
	var subs *Subtitles
	if file || isURL(src) {
		subs = setupSubtitles(ctx, c, p.ffmpeg, p.logf)
		if ctx.Err() != nil {
			return nil // skipped while checking the file
		}
	}
	p.subs.Store(subs)

	// Picture and sound from ONE ffmpeg whenever they belong together, so
	// they're stamped by the same clock and can't drift apart:
	//   - a file or stream with its own sound (AUDIO_SOURCE=auto), and
	//   - a camera with a microphone (Windows: one DirectShow input).
	var av *avOut
	if p.base.Audio && p.base.SyncCapture {
		media := file || isURL(src)
		switch {
		case media && p.audioFollowsFile() && (subs == nil || subs.mode != "cc"):
			if probeStreams(ctx, p.ffmpeg, src).hasAudio {
				av = &avOut{clock0: p.clock0, snd: p.snd}
			}
			if ctx.Err() != nil {
				return nil
			}
		case !media:
			if ain, adesc, err := audioInputArgs(c, p.ffmpeg); err == nil {
				if merged, ok := mergeDshow(input, ain); ok {
					input = merged
					av = &avOut{clock0: p.clock0, snd: p.snd}
					p.logf("sound: %s, captured together with the picture", adesc)
				}
			}
		}
	}
	if av != nil {
		p.stopAudio() // this item brings its own sound
	} else {
		p.setAudio(ctx, c, (file || isURL(src)) && p.audioFollowsFile())
	}
	return runFFmpegVideo(ctx, p.v, p.ffmpeg, input, flip, c.FPS, subs, c, file, av, p.logf)
}

// mergeDshow combines a DirectShow camera and microphone into one input
// ("video=Camera:audio=Mic"), which ffmpeg keeps in sync with each other.
func mergeDshow(video, audio []string) ([]string, bool) {
	isDshow := func(a []string) bool {
		for i := 0; i+1 < len(a); i++ {
			if a[i] == "-f" && a[i+1] == "dshow" {
				return true
			}
		}
		return false
	}
	inputOf := func(a []string) (int, string) {
		for i := 0; i+1 < len(a); i++ {
			if a[i] == "-i" {
				return i + 1, a[i+1]
			}
		}
		return -1, ""
	}
	if !isDshow(video) || !isDshow(audio) {
		return nil, false
	}
	vi, vname := inputOf(video)
	_, aname := inputOf(audio)
	if vi < 0 || !strings.HasPrefix(vname, "video=") || !strings.HasPrefix(aname, "audio=") {
		return nil, false
	}
	out := append([]string(nil), video[:vi-1]...)
	out = append(out, "-audio_buffer_size", "50", "-i", vname+":"+aname)
	out = append(out, video[vi+1:]...)
	return out, true
}

// Run plays sources until ctx ends. startup is the SOURCE setting; if it
// can't play at all the program stops, as it always has. Later problems
// (a bad file, a switch to a camera that isn't there) are logged and the
// player moves on or goes back to what it was playing.
func (p *Player) Run(ctx context.Context, startup string) {
	p.runCtx = ctx
	defer p.stopAudio()
	if err := p.load(startup, false); err != nil {
		p.v.fail(err, true)
		return
	}
	everPlayed := false
	var prevLive string
	var prevRoots []string
	failsInRow := 0

	for ctx.Err() == nil {
		p.mu.Lock()
		live, n := p.live, len(p.items)
		var item string
		if live == "" && n > 0 {
			if p.pos >= n {
				p.pos = 0
			}
			if p.pos < 0 {
				p.pos = n - 1
			}
			item = p.items[p.pos]
			p.nowDesc = fmt.Sprintf("%d/%d %s", p.pos+1, n, filepath.Base(item))
			p.nowFile = item
		} else {
			item = live
			p.nowDesc = live
			p.nowFile = ""
		}
		pos := p.pos
		p.mu.Unlock()

		if live == "" {
			p.logf("playing %d/%d: %s", pos+1, n, item)
		} else {
			p.logf("playing: %s", item)
		}
		itemCtx, cancel := context.WithCancel(ctx)
		done := make(chan error, 1)
		started := time.Now()
		go func() { done <- p.playOne(itemCtx, item, live == "") }()

		var cmd *playerCmd
		var err error
	wait:
		for {
			select {
			case err = <-done:
				break wait
			case c := <-p.cmds:
				// Commands that don't change what's on screen are handled
				// without interrupting it.
				if c.kind == "shuffle" {
					p.handle(c, &prevLive, &prevRoots)
					continue
				}
				if c.kind == "add" && live == "" && n > 0 {
					p.handle(c, &prevLive, &prevRoots)
					continue
				}
				if (c.kind == "next" || c.kind == "prev") && live != "" {
					p.logf("next/back only work when playing files or a folder")
					continue
				}
				// Check a new source before stopping the current one, so a
				// typo doesn't interrupt what's playing.
				if c.kind == "switch" {
					if err := checkSource(c.arg); err != nil {
						p.logf("%v", err)
						continue
					}
				}
				cmd = &c
				cancel()
				<-done
				break wait
			case <-ctx.Done():
				cancel()
				<-done
				return
			}
		}
		cancel()
		if live == "" && p.audioFollowsFile() {
			p.stopAudio() // this file's sound ends with it
		}

		if cmd != nil {
			p.handle(*cmd, &prevLive, &prevRoots)
			failsInRow = 0
			continue
		}

		if err != nil {
			failsInRow++
			if p.v.HasFrames() {
				everPlayed = true // something has been on screen: never quit over this
			}
			if !everPlayed && (live != "" || failsInRow >= n) {
				p.v.fail(err, true) // the SOURCE setting never worked
				return
			}
			if live != "" {
				p.logf("couldn't play %s (%v); going back to what was playing", live, err)
				p.restore(prevLive, prevRoots)
				continue
			}
			p.logf("skipping %s (%v)", filepath.Base(item), err)
			if failsInRow >= n {
				p.logf("none of the %d files would play; press S to choose another source", n)
				p.idleUntilCommand(ctx, &prevLive, &prevRoots)
				failsInRow = 0
				continue
			}
		} else {
			failsInRow = 0
			if time.Since(started) > 2*time.Second {
				everPlayed = true
			}
		}
		if live != "" {
			continue // live sources only stop on a command
		}
		everPlayed = true
		p.mu.Lock()
		p.pos++
		wrapped := p.pos >= len(p.items)
		p.mu.Unlock()
		if wrapped {
			if !p.base.Loop {
				p.logf("playlist finished; press S to choose another source")
				p.idleUntilCommand(ctx, &prevLive, &prevRoots)
				continue
			}
			p.rescan()
			p.mu.Lock()
			p.pos = 0
			p.mu.Unlock()
		}
	}
}

func (p *Player) idleUntilCommand(ctx context.Context, prevLive *string, prevRoots *[]string) {
	p.mu.Lock()
	p.nowDesc = "(nothing playing)"
	p.mu.Unlock()
	select {
	case c := <-p.cmds:
		p.handle(c, prevLive, prevRoots)
	case <-ctx.Done():
	}
}

// restore goes back to what was playing before a failed switch.
func (p *Player) restore(live string, roots []string) {
	if live == "" && len(roots) == 0 {
		return
	}
	if live != "" {
		p.load(live, false)
		return
	}
	p.mu.Lock()
	p.live, p.roots = "", roots
	p.mu.Unlock()
	p.rescan()
}

func (p *Player) handle(c playerCmd, prevLive *string, prevRoots *[]string) {
	p.mu.Lock()
	*prevLive, *prevRoots = p.live, append([]string(nil), p.roots...)
	p.mu.Unlock()
	switch c.kind {
	case "switch":
		if err := p.load(c.arg, false); err != nil {
			p.logf("%v", err)
			return
		}
		p.mu.Lock()
		n := len(p.items)
		p.mu.Unlock()
		if n > 1 {
			p.logf("new playlist: %d videos from %s", n, cleanPath(c.arg))
		}
	case "add":
		p.mu.Lock()
		before := len(p.items)
		wasLive := p.live != "" || before == 0
		p.mu.Unlock()
		if err := p.load(c.arg, true); err != nil {
			p.logf("%v", err)
			return
		}
		p.mu.Lock()
		added := len(p.items)
		if !wasLive {
			added -= before
		}
		p.mu.Unlock()
		if wasLive {
			p.logf("playlist started with %d video(s) from %s", added, cleanPath(c.arg))
		} else {
			p.logf("added %d video(s) to the end of the playlist", added)
		}
	case "shuffle":
		on := c.arg == "on"
		p.setShuffle(on)
		p.mu.Lock()
		live, n := p.live, len(p.items)
		p.mu.Unlock()
		switch {
		case live != "":
			p.logf("shuffle %s (it applies when playing a folder)", map[bool]string{true: "on", false: "off"}[on])
		case on:
			p.logf("shuffle on: the other %d video(s) will play in random order", n-1)
		default:
			p.logf("shuffle off: playing in folder order from here")
		}
	case "next", "prev":
		p.mu.Lock()
		if p.live != "" || len(p.items) == 0 {
			p.mu.Unlock()
			p.logf("next/back only work when playing files or a folder")
			return
		}
		if c.kind == "next" {
			p.pos++
		} else {
			p.pos--
		}
		p.mu.Unlock()
	}
}
