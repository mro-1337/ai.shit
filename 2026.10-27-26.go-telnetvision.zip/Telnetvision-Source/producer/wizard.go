package main

import (
	"bufio"
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"os"
	"strconv"
	"strings"
)

type prompter struct{ r *bufio.Reader }

func (p *prompter) line() string {
	s, _ := p.r.ReadString('\n')
	return strings.TrimSpace(s)
}

func (p *prompter) ask(q, def string) string {
	if def != "" {
		fmt.Printf("%s [%s]: ", q, def)
	} else {
		fmt.Printf("%s: ", q)
	}
	if s := p.line(); s != "" {
		return s
	}
	return def
}

func (p *prompter) askRequired(q, def string) string {
	for {
		if s := p.ask(q, def); s != "" {
			return s
		}
		fmt.Println("  This one is required.")
	}
}

func (p *prompter) askInt(q string, def, lo, hi int) int {
	for {
		s := p.ask(q, strconv.Itoa(def))
		if n, err := strconv.Atoi(s); err == nil && n >= lo && n <= hi {
			return n
		}
		fmt.Printf("  Please enter a number from %d to %d.\n", lo, hi)
	}
}

func (p *prompter) yes(q string, def bool) bool {
	d := "y/N"
	if def {
		d = "Y/n"
	}
	for {
		fmt.Printf("%s [%s]: ", q, d)
		switch strings.ToLower(p.line()) {
		case "":
			return def
		case "y", "yes":
			return true
		case "n", "no":
			return false
		}
		fmt.Println("  Please answer y or n.")
	}
}

// choose shows a numbered menu and returns the chosen index.
func (p *prompter) choose(q string, opts []string, def int) int {
	fmt.Println(q)
	for i, o := range opts {
		fmt.Printf("  %d) %s\n", i+1, o)
	}
	for {
		n := p.askInt("Choose", def+1, 1, len(opts))
		return n - 1
	}
}

func randomToken() string {
	b := make([]byte, 16)
	rand.Read(b)
	return hex.EncodeToString(b)
}

// runWizard walks the user through every setting that matters and saves
// the result. Existing values are offered as defaults.
func runWizard(cfg *Config, path string) error {
	p := &prompter{r: bufio.NewReader(os.Stdin)}
	fmt.Println()
	fmt.Println("  ==============================================")
	fmt.Println("   Telnetvision setup")
	fmt.Println("  ==============================================")
	fmt.Println("  Press Enter to accept the [default] shown.")
	fmt.Println()

	fmt.Println("-- 1. Your server ---------------------------------------------")
	fmt.Println("This is the machine running tvserver.exe (or the BBS relay, service.exe).")
	cfg.Host = p.askRequired("Server host name or IP address", cfg.Host)
	cfg.Port = p.askInt("Server feed port (feed_port in tvserver.ini)", cfg.Port, 1, 65535)
	if cfg.Token == "" {
		fmt.Println("The token is shown when tvserver.exe starts (token = in tvserver.ini).")
		fmt.Println("If you haven't picked one yet, type  new  to generate one.")
	}
	tok := p.askRequired("Token", cfg.Token)
	if strings.EqualFold(tok, "new") {
		tok = randomToken()
		fmt.Printf("  Your new token is: %s\n", tok)
		fmt.Println("  Put this in tvserver.ini as:  token = " + tok)
	}
	cfg.Token = tok
	cfg.Channel = p.ask("Channel name (must match channel in tvserver.ini)", cfg.Channel)
	cfg.TLS = p.yes("Encrypt the connection with TLS? (tvserver.exe supports it automatically)", cfg.TLS)
	if cfg.TLS {
		cfg.Insecure = p.yes("Is the server's certificate self-signed? (yes for tvserver.exe's automatic one)", cfg.Insecure)
	}
	fmt.Println()

	fmt.Println("-- 2. What to stream ------------------------------------------")
	ff, ffErr := findFFmpeg(cfg)
	var devs []Device
	if ffErr != nil {
		fmt.Println("  NOTE: ffmpeg.exe was not found, so cameras can't be listed and only")
		fmt.Println("  the test pattern will work until you put ffmpeg.exe next to this program.")
	} else {
		devs, _ = listDevices(ff)
	}
	type opt struct{ label, source string }
	var opts []opt
	for _, d := range devs {
		if d.Kind == "video" {
			opts = append(opts, opt{"Camera: " + d.Name, "camera:" + d.Name})
		}
	}
	if len(opts) == 0 {
		opts = append(opts, opt{"Default webcam", "camera"})
	}
	opts = append(opts,
		opt{"Your screen (desktop capture)", "screen"},
		opt{"A video file or stream URL (mp4, rtsp://, http://...)", "?"},
		opt{"A folder of videos (plays everything in it and its subfolders)", "folder?"},
		opt{"Test pattern (no camera needed - good for a first try)", "test"},
	)
	// Start on whatever is set now, matching partial device names the way
	// the program does, so pressing Enter always keeps the current choice.
	cur := currentVideoOption(cfg.Source, devs)
	def := -1
	for i, o := range opts {
		if o.source == cur || (o.source == "?" && (isURL(cfg.Source) || fileExists(cfg.Source))) ||
			(o.source == "folder?" && isDir(cfg.Source)) {
			def = i
		}
	}
	if def < 0 && cfg.Source != "" {
		opts = append([]opt{{"Keep current setting: " + cfg.Source, cfg.Source}}, opts...)
		def = 0
	}
	if def < 0 {
		def = 0
	}
	labels := make([]string, len(opts))
	for i, o := range opts {
		labels[i] = o.label
	}
	sourceBefore := cfg.Source
	pickIdx := p.choose("Video source:", labels, def)
	pick := opts[pickIdx]
	if pickIdx == def && pick.source != "?" && pick.source != "folder?" {
		pick.source = cfg.Source // unchanged: keep it exactly as written
	}
	if pick.source == "folder?" {
		cur := ""
		if isDir(cfg.Source) {
			cur = cfg.Source
		}
		for {
			d := cleanPath(p.askRequired("Folder", cur))
			if isDir(d) {
				vids, _ := scanFolder(d)
				if len(vids) == 0 {
					fmt.Println("  No video files in that folder or its subfolders.")
					continue
				}
				fmt.Printf("  Found %d videos.\n", len(vids))
				cfg.Source = d
				cfg.Shuffle = p.yes("Play them in random order?", cfg.Shuffle)
				break
			}
			fmt.Println("  That folder doesn't exist. (Tip: drag the folder onto this window.)")
		}
	} else if pick.source == "?" {
		cur := ""
		if isURL(cfg.Source) || fileExists(cfg.Source) {
			cur = cfg.Source
		}
		for {
			s := strings.Trim(p.askRequired("File path or URL", cur), "\"")
			if isURL(s) || fileExists(s) {
				cfg.Source = s
				break
			}
			fmt.Println("  That file doesn't exist. (Tip: drag the file onto this window.)")
		}
	} else {
		cfg.Source = pick.source
	}
	if strings.HasPrefix(strings.ToLower(cfg.Source), "camera") || isDigits(cfg.Source) {
		// Default to what's set now; leave the setting untouched if kept.
		mirrored := cfg.Flip == "1" || (cfg.Flip == "auto" && strings.EqualFold(cfg.Source, "camera"))
		if ans := p.yes("Mirror the camera image like a selfie?", mirrored); ans != mirrored {
			cfg.Flip = map[bool]string{true: "1", false: "0"}[ans]
		}
	} else if cfg.Source != sourceBefore {
		cfg.Flip = "0" // switched to a screen/file/stream: show it the right way round
	}
	if isURL(cfg.Source) || fileExists(cfg.Source) || isDir(cfg.Source) {
		fmt.Println("Subtitles: a .srt/.vtt next to the file, a subtitle track, or TV closed captions.")
		on := !strings.EqualFold(cfg.Subtitles, "off")
		if p.yes("Show subtitles / closed captions when the video has them?", on) {
			if strings.EqualFold(cfg.Subtitles, "off") || cfg.Subtitles == "" {
				cfg.Subtitles = "auto"
			}
		} else {
			cfg.Subtitles = "off"
		}
	}
	if p.yes(fmt.Sprintf("Keep the standard size of %dx%d characters at %g frames/sec?", cfg.Cols, cfg.Rows, cfg.FPS), true) == false {
		cfg.Cols = p.askInt("Columns", cfg.Cols, 8, 400)
		cfg.Rows = p.askInt("Rows", cfg.Rows, 4, 200)
		cfg.FPS = float64(p.askInt("Frames per second", int(cfg.FPS), 1, 60))
	}
	fmt.Println()

	fmt.Println("-- 3. Sound (optional) -----------------------------------------")
	fmt.Println("Viewers using SyncTERM 1.10a or newer hear sound; others just see video.")
	cfg.Audio = p.yes("Stream sound too?", cfg.Audio)
	if cfg.Audio {
		var aopts []opt
		if isURL(cfg.Source) || fileExists(cfg.Source) || isDir(cfg.Source) {
			aopts = append(aopts, opt{"Sound from the video file/stream itself", "auto"})
		}
		for _, d := range devs {
			if d.Kind == "audio" {
				aopts = append(aopts, opt{"Microphone/input: " + d.Name, "mic:" + d.Name})
			}
		}
		if len(aopts) == 0 {
			aopts = append(aopts, opt{"Default microphone", "mic"})
		}
		acur := currentAudioOption(cfg.AudioSource, devs, isURL(cfg.Source) || fileExists(cfg.Source) || isDir(cfg.Source))
		ad := -1
		for i, o := range aopts {
			if o.source == acur {
				ad = i
			}
		}
		if ad < 0 && cfg.AudioSource != "" && !strings.EqualFold(cfg.AudioSource, "auto") {
			aopts = append([]opt{{"Keep current setting: " + cfg.AudioSource, cfg.AudioSource}}, aopts...)
			ad = 0
		}
		if ad < 0 {
			ad = 0
		}
		al := make([]string, len(aopts))
		for i, o := range aopts {
			al[i] = o.label
		}
		if i := p.choose("Sound source:", al, ad); i != ad || acur == "" {
			cfg.AudioSource = aopts[i].source
		} // else: unchanged, keep it exactly as written
	}
	fmt.Println()

	fmt.Println("-- 4. Live captions (optional) ---------------------------------")
	fmt.Println("A text file whose last line is shown as a caption, e.g. from speech-to-text.")
	cfg.CaptionFile = strings.Trim(p.ask("Live caption file (leave blank for none)", cfg.CaptionFile), "\"")
	fmt.Println()

	if err := cfg.save(path); err != nil {
		return fmt.Errorf("saving %s: %v", path, err)
	}
	fmt.Printf("Saved to %s\n", path)
	fmt.Println("Run  telnetvision.exe --setup  any time to change these.")
	fmt.Print("Press Enter to start streaming...")
	p.line()
	return nil
}

// currentVideoOption maps the SOURCE setting to the menu entry it means.
func currentVideoOption(src string, devs []Device) string {
	low := strings.ToLower(strings.TrimSpace(src))
	var cams []string
	for _, d := range devs {
		if d.Kind == "video" {
			cams = append(cams, d.Name)
		}
	}
	switch {
	case low == "camera":
		if len(cams) > 0 {
			return "camera:" + cams[0]
		}
		return "camera"
	case strings.HasPrefix(low, "camera:"):
		if n := matchDevice(devs, "video", strings.TrimSpace(src[len("camera:"):])); n != "" {
			return "camera:" + n
		}
	case isDigits(low):
		if i, _ := strconv.Atoi(low); i < len(cams) {
			return "camera:" + cams[i]
		}
	case low == "screen" || low == "desktop":
		return "screen"
	case low == "test":
		return "test"
	}
	return ""
}

// currentAudioOption maps the AUDIO_SOURCE setting to the menu entry it means.
func currentAudioOption(src string, devs []Device, avSource bool) string {
	low := strings.ToLower(strings.TrimSpace(src))
	want := ""
	switch {
	case low == "" || low == "auto":
		if avSource {
			return "auto"
		}
		want = ""
	case low == "mic":
	case strings.HasPrefix(low, "mic:"):
		want = strings.TrimSpace(src[4:])
	case strings.HasPrefix(low, ":"):
		want = strings.TrimSpace(src[1:])
	default:
		return ""
	}
	name := firstDevice(devs, "audio")
	if want != "" {
		name = matchDevice(devs, "audio", want)
	}
	if name != "" {
		return "mic:" + name
	}
	if want == "" {
		return "mic"
	}
	return ""
}

func fileExists(p string) bool {
	if p == "" {
		return false
	}
	st, err := os.Stat(p)
	return err == nil && !st.IsDir()
}
