package main

import (
	"strings"
	"testing"
	"time"
)

func TestParseSRTAndVTT(t *testing.T) {
	srt := "\ufeff1\r\n00:00:02,000 --> 00:00:05,500\r\n<i>Hello</i> there,\r\n{\\an8}general &amp; friends.\r\n\r\n2\r\n00:01:00,250 --> 00:01:02,000\r\n♪ music ♪\r\n"
	c := parseSubtitleFile(srt)
	if len(c) != 2 || c[0].start != 2 || c[0].end != 5.5 || c[0].text != "Hello there,\ngeneral & friends." || c[1].start != 60.25 {
		t.Fatalf("srt: %+v", c)
	}
	vtt := "WEBVTT\n\n00:01.000 --> 00:03.000 align:start\nShort <c.yellow>form</c>\n\nnote\n01:02:03.400 --> 01:02:04.000\nLong form\n"
	c = parseSubtitleFile(vtt)
	if len(c) != 2 || c[0].start != 1 || c[0].text != "Short form" || c[1].start != 3723.4 {
		t.Fatalf("vtt: %+v", c)
	}
}

func TestCleanCaption(t *testing.T) {
	got := cleanCaption(`<font face="Monospace">{\an7}ONE` + "\n" + `TWO\NTHREE` + "\n  FOUR  </font>")
	if got != "TWO\nTHREE\nFOUR" {
		t.Fatalf("%q", got)
	}
	if cleanCaption(`<font face="Monospace"></font>`) != "" {
		t.Fatal("empty cc event should clear")
	}
}

func TestPickTrack(t *testing.T) {
	subs := []string{"0:eng:hdmv_pgs_subtitle:bitmap", "1:eng:subrip", "2:spa:subrip"}
	if i, _, ok := pickTrack(subs, ""); !ok || i != 1 {
		t.Fatal("default should skip bitmap track")
	}
	if i, _, ok := pickTrack(subs, "spa"); !ok || i != 2 {
		t.Fatal("language pick")
	}
	if _, _, ok := pickTrack(subs, "0"); ok {
		t.Fatal("bitmap track must be refused")
	}
}

func TestCurrentSidecarLoops(t *testing.T) {
	s := &Subtitles{mode: "sidecar", period: 10, cues: []subCue{{2, 4, "A"}}}
	now := time.Now()
	s.startRun(now)
	if s.Current(now.Add(3*time.Second)) != "A" || s.Current(now.Add(13*time.Second)) != "A" || s.Current(now.Add(5*time.Second)) != "" {
		t.Fatal("sidecar timing")
	}
	_ = strings.TrimSpace
}
