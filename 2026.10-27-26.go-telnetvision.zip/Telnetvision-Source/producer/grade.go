package main

import "math"

// grade applies contrast, brightness and saturation in place to packed RGB24.
// Same order and math as the Python producer: contrast and brightness on the
// raw channels (clipped), then saturation as a gain on HSV saturation.
func grade(px []byte, brightness int, contrast, saturation float64) {
	if contrast == 1 && brightness == 0 && saturation == 1 {
		return
	}
	var lut [256]byte
	for i := range lut {
		v := (float64(i)-128)*contrast + 128 + float64(brightness)
		lut[i] = clamp8(v)
	}
	for i := 0; i+2 < len(px); i += 3 {
		px[i], px[i+1], px[i+2] = lut[px[i]], lut[px[i+1]], lut[px[i+2]]
	}
	if saturation == 1 {
		return
	}
	for i := 0; i+2 < len(px); i += 3 {
		r, g, b := float64(px[i]), float64(px[i+1]), float64(px[i+2])
		mx := math.Max(r, math.Max(g, b))
		mn := math.Min(r, math.Min(g, b))
		if mx == 0 || mx == mn {
			continue // grey: no hue to saturate
		}
		s := (mx - mn) / mx
		ns := math.Min(1, s*saturation)
		// Scaling each channel's distance from the max by ns/s preserves hue
		// and value while setting saturation to ns.
		k := ns / s
		px[i] = clamp8(mx - (mx-r)*k)
		px[i+1] = clamp8(mx - (mx-g)*k)
		px[i+2] = clamp8(mx - (mx-b)*k)
	}
}

func clamp8(v float64) byte {
	if v <= 0 {
		return 0
	}
	if v >= 255 {
		return 255
	}
	return byte(v + 0.5)
}

// testFrame draws an animated color field (no camera needed).
func testFrame(dst []byte, cols, rows, n int) {
	h := 2 * rows
	f := float64(n)
	i := 0
	for y := 0; y < h; y++ {
		for x := 0; x < cols; x++ {
			fx, fy := float64(x), float64(y)
			dst[i] = byte(math.Sin((fx+f*1.5)/7)*127 + 128)
			dst[i+1] = byte(math.Sin((fy+f)/6)*127 + 128)
			dst[i+2] = byte(math.Sin((fx+fy+f*2)/9)*127 + 128)
			i += 3
		}
	}
}
