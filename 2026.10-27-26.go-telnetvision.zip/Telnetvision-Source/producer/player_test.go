package main

import (
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"
)

func TestNaturalOrder(t *testing.T) {
	in := []string{`M\Season 2\Ep 1.mkv`, `M\Season 1\Ep 10.mkv`, `M\Season 1\ep 2.mkv`, `M\Season 1\Ep 1.mkv`, `M\Season 10\Ep 1.mkv`, `M\Movie.mp4`}
	want := []string{`M\Movie.mp4`, `M\Season 1\Ep 1.mkv`, `M\Season 1\ep 2.mkv`, `M\Season 1\Ep 10.mkv`, `M\Season 2\Ep 1.mkv`, `M\Season 10\Ep 1.mkv`}
	got := append([]string(nil), in...)
	sortNatural(got)
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("got  %q\nwant %q", got, want)
	}
}

func sortNatural(s []string) {
	for i := 1; i < len(s); i++ {
		for j := i; j > 0 && naturalLess(s[j], s[j-1]); j-- {
			s[j], s[j-1] = s[j-1], s[j]
		}
	}
}

func TestScanFolder(t *testing.T) {
	d := t.TempDir()
	mk := func(p string) {
		full := filepath.Join(d, p)
		os.MkdirAll(filepath.Dir(full), 0o755)
		os.WriteFile(full, []byte("x"), 0o644)
	}
	for _, p := range []string{"a/Ep 10.MP4", "a/Ep 2.mkv", "a/b/c/deep.avi", "a/notes.txt", "a/Ep 2.srt",
		".hidden/x.mp4", "$RECYCLE.BIN/y.mp4", "a/._Ep 2.mkv"} {
		mk(p)
	}
	got, err := scanFolder(d)
	if err != nil {
		t.Fatal(err)
	}
	var rel []string
	for _, g := range got {
		r, _ := filepath.Rel(d, g)
		rel = append(rel, filepath.ToSlash(r))
	}
	want := []string{"a/b/c/deep.avi", "a/Ep 2.mkv", "a/Ep 10.MP4"}
	if !reflect.DeepEqual(rel, want) {
		t.Fatalf("got %q want %q", rel, want)
	}
}

func TestCleanPathAndLive(t *testing.T) {
	if cleanPath(`  "C:\My Movies\x.mp4" `) != `C:\My Movies\x.mp4` {
		t.Error("quotes from drag-and-drop not removed")
	}
	for _, s := range []string{"camera", "camera:SplitCam", "1", "screen", "test", "rtsp://x/y", "http://h:5004/auto/v2"} {
		if !isLiveSource(s) {
			t.Errorf("%s should be live", s)
		}
	}
	if isLiveSource(`C:\Movies`) {
		t.Error("folder is not live")
	}
}

func TestTypingLine(t *testing.T) {
	c := newControls(&Config{MessageSec: 15})
	feed := func(s string) {
		for _, b := range []byte(s) {
			c.key(b)
		}
	}
	feed("t")
	if _, _, on := c.promptLine(); !on {
		t.Fatal("T should open the message line")
	}
	// typed keys must not act as commands while typing; é split across reads
	feed("Show starts at 9qx")
	c.key(0xC3)
	c.key(0xA9)
	feed("\x08\x08!") // two backspaces remove é and x
	feed("\r")
	if m := c.currentMessage(time.Now()); m != "Show starts at 9q!" {
		t.Fatalf("message %q", m)
	}
	if c.currentMessage(time.Now().Add(16*time.Second)) != "" {
		t.Error("message should expire after MESSAGE_SECONDS")
	}
	feed("s")
	feed(`"C:\TV Shows"` + "\x1b")
	select {
	case a := <-c.actions:
		t.Fatalf("Esc should cancel, got %v", a)
	default:
	}
	feed("s" + `"C:\TV Shows"` + "\r")
	if a := <-c.actions; a.kind != "switch" || cleanPath(a.arg) != `C:\TV Shows` {
		t.Fatalf("switch action %+v", a)
	}
	feed("n")
	if a := <-c.actions; a.kind != "next" {
		t.Fatal("N should skip")
	}
	if c.key('q') != true {
		t.Fatal("Q should still quit outside the typing line")
	}
}

func TestCombineCaption(t *testing.T) {
	got := string(combineCaption("Back in 5", []byte("one\ntwo\nthree")))
	if got != "Back in 5\ntwo\nthree" || strings.Count(got, "\n") != 2 {
		t.Fatalf("%q", got)
	}
	if string(combineCaption("", []byte("sub"))) != "sub" || string(combineCaption("hi", nil)) != "hi" {
		t.Fatal("simple cases")
	}
}

func TestEscClosesHelpNeverQuits(t *testing.T) {
	c := newControls(&Config{})
	c.key('h')
	if !c.helpShown() {
		t.Fatal("H should open help")
	}
	if c.key(27) || c.helpShown() {
		t.Fatal("Esc should close help without quitting")
	}
	if c.key(27) {
		t.Fatal("Esc with help closed must not quit")
	}
	c.key('h')
	c.key('h')
	if c.helpShown() {
		t.Fatal("H toggles help")
	}
	c.key('n')
	if c.flashText() == "" {
		t.Fatal("N should show 'skipping' at once")
	}
	if !c.key('q') {
		t.Fatal("Q quits")
	}
}

func TestMergeDshow(t *testing.T) {
	v := []string{"-f", "dshow", "-rtbufsize", "32M", "-i", "video=SplitCam Video Driver"}
	a := []string{"-f", "dshow", "-audio_buffer_size", "50", "-i", "audio=Microphone (SplitCam Audio Mixer)"}
	got, ok := mergeDshow(v, a)
	want := []string{"-f", "dshow", "-rtbufsize", "32M", "-audio_buffer_size", "50", "-i", "video=SplitCam Video Driver:audio=Microphone (SplitCam Audio Mixer)"}
	if !ok || strings.Join(got, "|") != strings.Join(want, "|") {
		t.Fatalf("got %q", got)
	}
	if _, ok := mergeDshow([]string{"-f", "gdigrab", "-i", "desktop"}, a); ok {
		t.Fatal("screen capture can't merge with a microphone")
	}
}

func TestTidyTitle(t *testing.T) {
	for in, want := range map[string]string{
		`C:\Movies\The.Matrix.1999.mkv`:   "The Matrix 1999",
		`C:\Movies\Some_Home_Video.mp4`:   "Some Home Video",
		`C:\TV\Season 1\Ep 2 - Pilot.mp4`: "Ep 2 - Pilot",
		`/x/Dr. Strangelove (1964).avi`:   "Dr. Strangelove (1964)",
	} {
		if got := tidyTitle(filepath.FromSlash(strings.ReplaceAll(in, `\`, "/"))); got != want {
			t.Errorf("%s: got %q want %q", in, got, want)
		}
	}
}
