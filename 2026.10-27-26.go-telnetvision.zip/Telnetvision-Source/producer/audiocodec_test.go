package main

import (
	"encoding/binary"
	"math"
	"os"
	"path/filepath"
	"strconv"
	"testing"
)

func tone(n, ch, rate int) []byte {
	b := make([]byte, 0, n*ch*2)
	for i := 0; i < n; i++ {
		for c := 0; c < ch; c++ {
			v := 9000*math.Sin(2*math.Pi*440*float64(i)/float64(rate)+float64(c)) + 3000*math.Sin(2*math.Pi*1700*float64(i)/float64(rate))
			b = binary.LittleEndian.AppendUint16(b, uint16(int16(v)))
		}
	}
	return b
}

func snr(a, b []byte) float64 {
	var s, e float64
	for i := 0; i+1 < len(a) && i+1 < len(b); i += 2 {
		x := float64(int16(binary.LittleEndian.Uint16(a[i:])))
		y := float64(int16(binary.LittleEndian.Uint16(b[i:])))
		s += x * x
		e += (x - y) * (x - y)
	}
	return 10 * math.Log10(s/(e+1))
}

func TestSoundCodecsRoundTrip(t *testing.T) {
	dir := os.Getenv("ADPCM_OUT")
	for _, ch := range []int{1, 2} {
		for _, rate := range []int{8000, 11025, 22050, 44100} {
			n := imaChunkSamples(rate/5, ch)
			if b, _ := imaBlockPlan(n, ch); b == 0 {
				t.Fatalf("no plan for %d ch %d", n, ch)
			}
			pcm := tone(n, ch, rate)
			for _, codec := range []string{soundPCM, soundULaw, soundADPCM} {
				clip := encodeSoundClip(codec, pcm, rate, ch)
				out, r2, c2, err := decodeWAV(clip)
				if err != nil || r2 != rate || c2 != ch || len(out) != len(pcm) {
					t.Fatalf("%s %d/%d: err=%v rate=%d ch=%d len %d want %d", codec, rate, ch, err, r2, c2, len(out), len(pcm))
				}
				q := snr(pcm, out)
				if codec != soundPCM && q < 20 {
					t.Errorf("%s %d/%d snr %.1f", codec, rate, ch, q)
				}
				t.Logf("%s rate=%d ch=%d n=%d bytes=%d (pcm %d) snr=%.1f", codec, rate, ch, n, len(clip), len(pcm)+44, q)
				if dir != "" {
					os.WriteFile(filepath.Join(dir, codec+"_"+itoa(rate)+"_"+itoa(ch)+".wav"), clip, 0644)
					os.WriteFile(filepath.Join(dir, codec+"_"+itoa(rate)+"_"+itoa(ch)+".raw"), pcm, 0644)
				}
			}
		}
	}
}

func itoa(i int) string { return strconv.Itoa(i) }

func TestDownmix(t *testing.T) {
	pcm := tone(4410, 2, 44100)
	out, r, c := downmixResample(pcm[:4400*4], 44100, 2, 11025, 1)
	if r != 11025 || c != 1 || len(out) != 4400/4*2 {
		t.Fatalf("got %d %d %d", r, c, len(out))
	}
}
