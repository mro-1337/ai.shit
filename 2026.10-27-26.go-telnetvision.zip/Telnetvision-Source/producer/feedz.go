package main

// Compressed picture frames on the link to tvserver.
//
// Frames are raw RGB (11.5 KB each at 80x24, 1.4 Mbit/s at 15 fps), which a
// home upload can struggle with: the sound goes first, so the picture then
// arrives late (the server's "picture arrives N ms behind its sound").
// When tvserver says it understands them (a WELCOME message with the zlib
// bit), frames are sent as FRAME_Z:
//
//	FRAME_Z 0x12: 0x12 | u8 flags | zlib(FRAME payload without its 0x10)
//	flags bit 0: the pixels are XORed with the previous frame's (a delta)
//
// Pixels are first rounded to FEED_COLOR_BITS bits per colour (6 = 262,144
// colours, which looks the same at this size), so unchanged areas really
// are unchanged and the sensor noise doesn't cost bandwidth. Together this
// is typically a quarter to a half of the size. Servers that don't send a
// WELCOME (the classic relay) keep getting plain frames.

import (
	"bytes"
	"compress/zlib"
	"encoding/binary"
)

const (
	msgFrameZ   = 0x12
	msgFrameHi  = 0x13 // the sharper picture for sixel viewers
	msgFrameHiZ = 0x14 // the same, packed like FRAME_Z
	msgWantHi   = 0x21 // server -> producer: u8 1 = send FRAME_HI, 0 = stop
	msgWelcome  = 0x20
	capZFrames  = 0x01 // WELCOME caps: FRAME_Z understood
	capMessages = 0x02 // WELCOME caps: typed messages may be marked (msgMark)
	msgMark     = "\x02"
)

type frameZipper struct {
	prev  []byte // pixels of the last frame sent
	prevH []byte // pixels of the last sharper frame sent
	bits  int
	buf   bytes.Buffer
	zw    *zlib.Writer
	plain int64 // bytes the frames would have taken
	sent  int64 // bytes they did take
}

func newFrameZipper(bits int) *frameZipper {
	if bits < 4 || bits > 8 {
		bits = 6
	}
	z := &frameZipper{bits: bits}
	z.zw, _ = zlib.NewWriterLevel(&z.buf, zlib.BestSpeed)
	return z
}

// zip turns a framed FRAME message into a framed FRAME_Z message. It
// returns the input unchanged if it isn't a frame it can handle.
func (z *frameZipper) zip(msg []byte) []byte {
	if len(msg) < 4+13 || (msg[4] != msgFrame && msg[4] != msgFrameHi) {
		return msg
	}
	p := msg[4:]
	var start, n int
	prev, outType := &z.prev, byte(msgFrameZ)
	if p[0] == msgFrameHi {
		w := int(binary.BigEndian.Uint16(p[1:3]))
		h := int(binary.BigEndian.Uint16(p[3:5]))
		start, n = 13, w*h*3
		prev, outType = &z.prevH, msgFrameHiZ
	} else {
		cols := int(binary.BigEndian.Uint16(p[1:3]))
		rows := int(binary.BigEndian.Uint16(p[3:5]))
		capLen := int(binary.BigEndian.Uint16(p[7:9]))
		start, n = 9+capLen, 2*rows*cols*3
	}
	if start+n > len(p) {
		return msg
	}
	body := append([]byte(nil), p[1:]...) // everything after the type byte
	px := body[start-1 : start-1+n]
	if z.bits < 8 {
		mask := byte(0xFF << (8 - z.bits))
		half := byte(1 << (7 - z.bits)) // round to nearest, not down
		for i, b := range px {
			if b < 0xFF-half {
				b += half
			}
			px[i] = b & mask
		}
	}
	flags := byte(0)
	cur := append([]byte(nil), px...)
	if len(*prev) == n {
		for i := range px {
			px[i] ^= (*prev)[i]
		}
		flags |= 1
	}
	*prev = cur
	z.buf.Reset()
	z.zw.Reset(&z.buf)
	z.zw.Write(body)
	z.zw.Close()
	out := make([]byte, 4, 6+z.buf.Len())
	binary.BigEndian.PutUint32(out, uint32(2+z.buf.Len()))
	out = append(out, outType, flags)
	out = append(out, z.buf.Bytes()...)
	z.plain += int64(len(msg))
	z.sent += int64(len(out))
	return out
}
