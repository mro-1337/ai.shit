package main

import "testing"

func TestDroppedPathOpensPlayLine(t *testing.T) {
	c := newControls(defaultConfigPtr())
	drop := []byte(`"C:\Videos\Queen - Live at Wembley.mkv"`)
	if !c.paste(drop) {
		t.Fatal("a dropped path must be handled as text")
	}
	if c.prompt != "source" || string(c.buf) != `C:\Videos\Queen - Live at Wembley.mkv` {
		t.Fatalf("prompt=%q buf=%q", c.prompt, string(c.buf))
	}
	// The rest of a long drop, arriving later, continues the same line.
	c.paste([]byte(" more"))
	if string(c.buf) != `C:\Videos\Queen - Live at Wembley.mkv more` {
		t.Fatalf("continuation: %q", string(c.buf))
	}
	// Enter plays it.
	if c.key('\r') {
		t.Fatal("Enter must not quit")
	}
	select {
	case a := <-c.actions:
		if a.kind != "switch" {
			t.Fatalf("action %+v", a)
		}
	default:
		t.Fatal("Enter should play the dropped file")
	}
	// Single key presses are still commands.
	if c.paste([]byte("n")) {
		t.Fatal("one key is a command, not a paste")
	}
}

func defaultConfigPtr() *Config { c := defaultConfig(); return &c }
