#!/bin/sh
# Build every Windows program from Linux or macOS (same as build.bat).
#   ./build.sh            32-bit and 64-bit
#   ./build.sh 32 | 64    one of them
#   ./build.sh test       run the tests first
set -e
cd "$(dirname "$0")"
export CGO_ENABLED=0 GOFLAGS= GOPROXY=off GOTOOLCHAIN=local
want="$1"
if [ "$want" = test ]; then
  for m in producer tvserver door service lib/shadecell lib/termprobe; do
    echo "test $m"; (cd "$m" && go test ./...)
  done
  want=
fi
build() { # goarch folder
  out="$PWD/bin/$2"; mkdir -p "$out/camera-pc" "$out/server" "$out/bbs-door"
  echo "=== $2 ($1) ==="
  for p in producer:camera-pc/telnetvision.exe tvserver:server/tvserver.exe \
           door:bbs-door/door.exe service:bbs-door/service.exe; do
    src=${p%%:*}; dst=${p#*:}; echo "  $dst"
    (cd "$src" && GOOS=windows GOARCH=$1 go build -trimpath -ldflags="-s -w" -o "$out/$dst" .)
  done
  cp docs/telnetvision.ini.example "$out/camera-pc/"
  cp docs/door.ini.example "$out/bbs-door/door.ini"
  cp docs/BBS-DOOR-INSTALL.md "$out/bbs-door/INSTALL.md"
  cp "docs/README-USER-$2.txt" "$out/README.txt"
}
case "$want" in
  "") build 386 Win32; build amd64 Win64 ;;
  32) build 386 Win32 ;;
  64) build amd64 Win64 ;;
  *) echo "use 32, 64, test or nothing"; exit 1 ;;
esac
echo "Done. The programs are in bin/."
