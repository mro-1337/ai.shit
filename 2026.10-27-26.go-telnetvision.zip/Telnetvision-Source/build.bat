@echo off
rem ======================================================================
rem  Telnetvision for Windows - build every program from source.
rem
rem    build.bat          build 32-bit and 64-bit
rem    build.bat 32       build 32-bit only
rem    build.bat 64       build 64-bit only
rem    build.bat test     run the automatic tests, then build both
rem
rem  Needs Go 1.24 or newer (https://go.dev/dl/). Nothing else, and no
rem  internet connection: every library is in the lib folder.
rem
rem  The programs land in  bin\Win32  and  bin\Win64 , laid out like the
rem  release zips:  camera-pc\telnetvision.exe   server\tvserver.exe
rem                 bbs-door\door.exe  bbs-door\service.exe
rem ======================================================================
setlocal
cd /d "%~dp0"

where go >nul 2>nul
if errorlevel 1 (
    echo Go was not found. Install it from https://go.dev/dl/ and open a new
    echo command prompt, then run build.bat again.
    exit /b 1
)
for /f "tokens=3" %%v in ('go version') do echo Using %%v

set CGO_ENABLED=0
set GOOS=windows
set GOFLAGS=
set GOPROXY=off
set GOTOOLCHAIN=local

set WANT=%~1
if /i "%WANT%"=="test" (
    call :tests || exit /b 1
    set WANT=
)

if "%WANT%"=="" (
    call :build 386 Win32 || exit /b 1
    call :build amd64 Win64 || exit /b 1
) else if "%WANT%"=="32" (
    call :build 386 Win32 || exit /b 1
) else if "%WANT%"=="64" (
    call :build amd64 Win64 || exit /b 1
) else (
    echo Unknown option "%WANT%". Use 32, 64, test, or nothing.
    exit /b 1
)
echo.
echo Done. The programs are in the bin folder.
exit /b 0

rem ----------------------------------------------------------------------
:build
set GOARCH=%1
set OUT=%~dp0bin\%2
echo.
echo === %2 (%1) ===
if not exist "%OUT%\camera-pc" mkdir "%OUT%\camera-pc"
if not exist "%OUT%\server"    mkdir "%OUT%\server"
if not exist "%OUT%\bbs-door"  mkdir "%OUT%\bbs-door"
call :one producer "%OUT%\camera-pc\telnetvision.exe" || exit /b 1
call :one tvserver "%OUT%\server\tvserver.exe"        || exit /b 1
call :one door     "%OUT%\bbs-door\door.exe"          || exit /b 1
call :one service  "%OUT%\bbs-door\service.exe"       || exit /b 1
copy /y docs\telnetvision.ini.example "%OUT%\camera-pc\telnetvision.ini.example" >nul
copy /y docs\door.ini.example         "%OUT%\bbs-door\door.ini"                  >nul
copy /y docs\BBS-DOOR-INSTALL.md      "%OUT%\bbs-door\INSTALL.md"                >nul
copy /y docs\README-USER-%2.txt        "%OUT%\README.txt"                         >nul
exit /b 0

:one
echo   %~nx2
pushd "%~dp0%1"
go build -trimpath -ldflags="-s -w" -o %2 .
set RC=%errorlevel%
popd
if not "%RC%"=="0" (
    echo Building %1 failed.
    exit /b 1
)
exit /b 0

rem ----------------------------------------------------------------------
:tests
echo.
echo === tests ===
set GOOS=
for %%m in (producer tvserver door service lib\shadecell lib\termprobe) do (
    pushd "%~dp0%%m"
    echo   %%m
    go test ./...
    if errorlevel 1 (
        popd
        echo Tests failed in %%m.
        exit /b 1
    )
    popd
)
set GOOS=windows
exit /b 0
