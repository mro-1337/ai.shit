module telnetvision/door

go 1.24

require (
	github.com/hmderdoc/shadecell v0.1.0
	github.com/hmderdoc/termprobe v0.1.0
)

// Both libraries are included in ../lib, so nothing is downloaded.
replace github.com/hmderdoc/shadecell => ../lib/shadecell

replace github.com/hmderdoc/termprobe => ../lib/termprobe
