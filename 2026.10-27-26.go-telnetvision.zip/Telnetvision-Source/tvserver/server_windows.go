//go:build windows

package main

import (
	"syscall"
	"unsafe"
)

var (
	srvKernel32       = syscall.NewLazyDLL("kernel32.dll")
	srvSetTitle       = srvKernel32.NewProc("SetConsoleTitleW")
	srvGetProcessList = srvKernel32.NewProc("GetConsoleProcessList")
)

func setServerTitle(s string) {
	if p, err := syscall.UTF16PtrFromString(s); err == nil {
		srvSetTitle.Call(uintptr(unsafe.Pointer(p)))
	}
}

// serverDoubleClicked: started from Explorer, the console holds only us,
// so an error should wait for Enter instead of the window vanishing.
func serverDoubleClicked() bool {
	var ids [4]uint32
	n, _, _ := srvGetProcessList.Call(uintptr(unsafe.Pointer(&ids[0])), 4)
	return n == 1
}
