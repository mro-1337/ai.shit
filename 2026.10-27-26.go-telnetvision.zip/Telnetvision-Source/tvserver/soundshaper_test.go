package main

import (
	"encoding/binary"
	"math"
	"os"
	"path/filepath"
	"strconv"
	"testing"
)

func testTone(n, ch, rate, start int) []byte {
	b := make([]byte, 0, n*ch*2)
	for i := start; i < start+n; i++ {
		for c := 0; c < ch; c++ {
			v := 9000 * math.Sin(2*math.Pi*300*float64(i)/float64(rate))
			b = binary.LittleEndian.AppendUint16(b, uint16(int16(v)))
		}
	}
	return b
}

// Every sample that goes in comes out (after rate reduction), across
// chunk sizes that don't line up with ADPCM blocks or resample groups.
func TestShaperKeepsEverySample(t *testing.T) {
	dir := os.Getenv("SHAPER_OUT")
	cases := []struct {
		rate, ch        int
		codec, quality  string
		inCodec         byte
		wantRate, wantC int
	}{
		{22050, 1, soundADPCM, qualityBest, codecRaw, 22050, 1},
		{44100, 2, soundADPCM, qualityGood, codecRaw, 22050, 1},
		{44100, 2, soundULaw, qualityLow, codecWAV, 11025, 1},
		{22050, 1, soundADPCM, qualityLow, codecWAV, 11025, 1},
		{44100, 2, soundADPCM, qualityBest, codecWAV, 44100, 2},
		{48000, 2, soundPCM, qualityGood, codecRaw, 24000, 1},
	}
	for ci, tc := range cases {
		var sh soundShaper
		sh.set(tc.codec, tc.quality)
		in, out := 0, 0
		var all []byte
		pos := 0
		for k := 0; k < 40; k++ {
			n := tc.rate*80/1000 + k%7 // ragged chunk lengths
			pcm := testTone(n, tc.ch, tc.rate, pos)
			pos += n
			payload := pcm
			if tc.inCodec == codecWAV {
				payload = encodePCMWAV(pcm, tc.rate, tc.ch)
			}
			in += n
			m := audioMsg{Codec: tc.inCodec, Channels: byte(tc.ch), SampleRate: uint32(tc.rate), DurMs: uint32(n * 1000 / tc.rate), Payload: payload}
			for _, c := range sh.shape(m) {
				tag, r, ch, ok := wavInfo(c.file)
				if !ok || tag != codecTag(tc.codec) || r != tc.wantRate || ch != tc.wantC {
					t.Fatalf("case %d: clip tag=%x rate=%d ch=%d", ci, tag, r, ch)
				}
				p, _, _, err := decodeWAV(c.file)
				if err != nil {
					t.Fatal(err)
				}
				out += len(p) / (2 * ch)
				all = append(all, p...)
				if dir != "" {
					os.WriteFile(filepath.Join(dir, "c"+strconv.Itoa(ci)+"_"+strconv.Itoa(k)+".wav"), c.file, 0644)
				}
			}
		}
		factor := tc.rate / tc.wantRate
		held := (len(sh.encCarry)/(2*tc.wantC))*factor + len(sh.rsCarry)/(2*tc.ch)
		if out*factor+held != in {
			t.Errorf("case %d: in %d samples, out %d (x%d) + held %d", ci, in, out, factor, held)
		}
		t.Logf("case %d: %s %s %d->%d Hz: in=%d out=%d held=%d", ci, tc.codec, tc.quality, tc.rate, tc.wantRate, in, out, held)
	}
}

func TestShaperPassThrough(t *testing.T) {
	var sh soundShaper
	sh.set(soundADPCM, qualityBest)
	pcm := testTone(1764, 1, 22050, 0)
	clip, err := encodeIMAWAV(pcm, 22050, 1)
	if err != nil {
		t.Fatal(err)
	}
	got := sh.shape(audioMsg{Codec: codecWAV, Channels: 1, SampleRate: 22050, DurMs: 80, Payload: clip})
	if len(got) != 1 || &got[0].file[0] != &clip[0] {
		t.Fatal("matching ADPCM clip should pass through untouched")
	}
}

func TestCodecForTerminal(t *testing.T) {
	if codecFor(soundAutoCodec, "syncterm (CTerm 1.331)") != soundADPCM || codecFor(soundAutoCodec, "icyterm") != soundULaw ||
		codecFor(soundAutoCodec, "unknown") != soundULaw || codecFor(soundPCM, "syncterm") != soundPCM || codecFor(soundADPCM, "icyterm") != soundULaw || codecFor(soundAutoCodec, "web browser (fTelnet)") != soundADPCM {
		t.Fatal("auto compression by terminal")
	}
}

func TestBoostIsLouderAndNeverWraps(t *testing.T) {
	pcm := testTone(2205, 1, 22050, 0)
	var sh soundShaper
	sh.set(soundPCM, qualityBest)
	sh.setGain(12)
	clips := sh.shape(audioMsg{Codec: codecRaw, Channels: 1, SampleRate: 22050, DurMs: 100, Payload: pcm})
	out, _, _, _ := decodeWAV(clips[0].file)
	var in, o float64
	for i := 0; i+1 < len(pcm); i += 2 {
		a := float64(int16(binary.LittleEndian.Uint16(pcm[i:])))
		b := float64(int16(binary.LittleEndian.Uint16(out[i:])))
		in += a * a
		o += b * b
		if a > 1000 && b < 0 || a < -1000 && b > 0 {
			t.Fatal("boost wrapped around")
		}
	}
	if o < in*4 {
		t.Fatalf("+12 dB should be much louder: %.0f vs %.0f", o, in)
	}
}
