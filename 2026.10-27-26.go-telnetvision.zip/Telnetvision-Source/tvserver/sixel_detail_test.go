package main

import (
	"bytes"
	"encoding/binary"
	"os"
	"testing"
)

func TestSixelDetailSizes(t *testing.T) {
	dir := os.Getenv("SIXEL_DIR")
	if dir == "" {
		t.Skip("set SIXEL_DIR")
	}
	for _, name := range []string{"frac", "noisy"} {
		raw, err := os.ReadFile(dir + "/" + name + "_160x96.rgb")
		if err != nil {
			t.Fatal(err)
		}
		for _, d := range sixelDetails {
			var total, n int
			for off := 0; off+160*96*3 <= len(raw); off += 160 * 96 * 3 {
				hiPx := raw[off : off+160*96*3]
				hi := []byte{msgFrameHi, 0, 160, 0, 96}
				hi = binary.BigEndian.AppendUint64(hi, 1000)
				hi = append(hi, hiPx...)
				lo := shrink(hiPx, 160, 96, 80, 48)
				var b bytes.Buffer
				renderSixel(&b, lo, 80, 24, hi, 1000, 80, 24, 0, 0, 8, 16, 64, d)
				total += b.Len()
				n++
			}
			t.Logf("%-5s %-6s %6d bytes/picture = %4.1f Mbit/s at 15 fps", name, d, total/n, float64(total/n)*8*15/1e6)
		}
	}
}
