package main

// One telnet caller. Negotiates the terminal (window size via NAWS, name via
// TTYPE, colour depth via an in-band probe), then paints the feed using the
// door's renderers - delta-encoded, letterboxed to the caller's window, and
// drop-to-latest so a slow modem-speed link never falls behind live.

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"log"
	"net"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/hmderdoc/termprobe"
)

// Telnet protocol bytes.
const (
	tIAC  = 255
	tDONT = 254
	tDO   = 253
	tWONT = 252
	tWILL = 251
	tSB   = 250
	tSE   = 240

	optBinary = 0
	optEcho   = 1
	optSGA    = 3
	optTType  = 24
	optNAWS   = 31
)

// viewOptions are the per-caller rendering settings from tvserver.ini.
type viewOptions struct {
	channel     string
	encoding    string // auto | cp437 | utf8
	color       string // auto | truecolor | 256 | 16
	menu        bool   // viewers may open the S settings menu
	web         bool   // a browser (fTelnet over WebSocket), not a telnet program
	lipSync     bool   // picture waits for its sound (viewers can turn it off with S)
	sixel       bool   // offer sixel graphics in the S menu
	soundDebug  bool   // log the sound debug answers for every caller
	sixelCols   int    // colours per sixel picture
	sixelDetail string // where sixel viewers start: high | medium | low
	cellW       int    // terminal character cell in pixels, for sixel
	cellH       int
	maxHold     time.Duration // the longest a frame may wait for its sound
	webColor    string        // colors for browsers: truecolor | 256 | 16
	stretch     bool
	saturation  float64
	dither      bool
	shade       bool
	fps         float64 // frames a second each viewer starts at
	maxFPS      float64 // the most a viewer can raise it to (+ key)
	hint        bool
	captions    bool // show captions unless the viewer presses C
	titleBar    bool // show the movie title bar unless the viewer presses T
	banner      string
	audio       audioConfig // SyncTERM sound settings (audio = auto|on|off ...)
}

type session struct {
	conn net.Conn
	opt  viewOptions
	hub  *hub
	id   string

	data chan []byte // caller bytes with telnet commands stripped

	cols, rows atomic.Int32
	nawsSeen   atomic.Bool
	negSent    time.Time    // when our telnet negotiation went out
	rttNs      atomic.Int64 // round trip, from the first negotiation reply
	ttype      atomic.Value // string
	ttypeSeen  chan struct{}
	ttypeOnce  sync.Once

	wmu    sync.Mutex // serializes writes to conn
	closed chan struct{}
	once   sync.Once
}

func (s *session) close() {
	s.once.Do(func() { close(s.closed) })
}

func (s *session) isClosed() bool {
	select {
	case <-s.closed:
		return true
	default:
		return false
	}
}

// write sends b, doubling any 0xFF byte as telnet requires.
func (s *session) write(b []byte) error {
	if bytes.IndexByte(b, tIAC) >= 0 {
		b = bytes.ReplaceAll(b, []byte{tIAC}, []byte{tIAC, tIAC})
	}
	return s.raw(b)
}

func (s *session) raw(b []byte) error {
	s.wmu.Lock()
	defer s.wmu.Unlock()
	s.conn.SetWriteDeadline(time.Now().Add(30 * time.Second))
	_, err := s.conn.Write(b)
	if err != nil {
		s.close()
	}
	return err
}

// Write lets termprobe send its queries through the IAC-escaping path.
func (s *session) Write(b []byte) (int, error) {
	if err := s.write(b); err != nil {
		return 0, err
	}
	return len(b), nil
}

// readLoop strips telnet commands, handles NAWS / TTYPE answers, and passes
// everything else on as data.
func (s *session) readLoop() {
	defer s.close()
	defer close(s.data)
	buf := make([]byte, 4096)
	state := 0 // 0 data, 1 IAC, 2 option byte, 3 SB, 4 SB+IAC
	var cmd byte
	var sb []byte
	for {
		n, err := s.conn.Read(buf)
		if err != nil {
			return
		}
		var out []byte
		for _, c := range buf[:n] {
			switch state {
			case 0:
				if c == tIAC {
					state = 1
				} else {
					out = append(out, c)
				}
			case 1:
				switch {
				case c == tIAC: // escaped 0xFF data byte
					out = append(out, c)
					state = 0
				case c == tSB:
					sb, state = sb[:0], 3
				case c >= tWILL && c <= tDONT:
					cmd, state = c, 2
				default:
					state = 0
				}
			case 2:
				s.noteReply()
				s.onOption(cmd, c)
				state = 0
			case 3:
				if c == tIAC {
					state = 4
				} else if len(sb) < 512 {
					sb = append(sb, c)
				}
			case 4:
				if c == tSE {
					s.noteReply()
					s.onSub(sb)
					state = 0
				} else {
					if c == tIAC {
						sb = append(sb, c)
					}
					state = 3
				}
			}
		}
		if len(out) > 0 {
			select {
			case s.data <- out:
			case <-s.closed:
				return
			}
		}
	}
}

// noteReply records the round-trip time from the client's first answer
// to our telnet negotiation (sent on an idle connection, so it's a clean
// measurement of the network distance).
func (s *session) noteReply() {
	if s.rttNs.Load() == 0 && !s.negSent.IsZero() {
		d := time.Since(s.negSent)
		if d < time.Millisecond {
			d = time.Millisecond
		}
		s.rttNs.Store(int64(d))
	}
}

// rtt is the measured round trip, or 0 if the client never negotiated.
func (s *session) rtt() time.Duration { return time.Duration(s.rttNs.Load()) }

// sendBufferSize sizes the kernel send buffer to the viewer's distance.
// A buffer smaller than (speed x round trip) caps the connection no matter
// how fast it really is: TCP can only have one buffer's worth in flight.
// Room for 20 Mbit/s over the measured round trip is plenty for any
// picture + sound, while nearby viewers keep a small buffer for low delay.
func sendBufferSize(rtt time.Duration, withSound bool) int {
	min := 64 << 10
	if withSound {
		min = 32 << 10 // sound must not sit behind much picture data
	}
	if rtt <= 0 {
		return min
	}
	n := int(rtt.Seconds() * 2.5e6)
	if n < min {
		n = min
	}
	if n > 1<<20 {
		n = 1 << 20
	}
	return n
}

func (s *session) onOption(cmd, opt byte) {
	switch {
	case cmd == tWILL && opt == optTType:
		s.raw([]byte{tIAC, tSB, optTType, 1, tIAC, tSE}) // SEND
	case cmd == tWONT && opt == optTType:
		s.ttypeOnce.Do(func() { close(s.ttypeSeen) })
	}
}

func (s *session) onSub(sb []byte) {
	if len(sb) == 0 {
		return
	}
	switch sb[0] {
	case optNAWS:
		if len(sb) >= 5 {
			w := int(binary.BigEndian.Uint16(sb[1:3]))
			h := int(binary.BigEndian.Uint16(sb[3:5]))
			if w >= 20 && h >= 8 && w <= 1000 && h <= 1000 {
				s.cols.Store(int32(w))
				s.rows.Store(int32(h))
				s.nawsSeen.Store(true)
			}
		}
	case optTType:
		if len(sb) >= 2 && sb[1] == 0 { // IS
			s.ttype.Store(strings.ToLower(strings.TrimSpace(string(sb[2:]))))
			s.ttypeOnce.Do(func() { close(s.ttypeSeen) })
		}
	}
}

// pickCP437 decides the character set. BBS terminals (SyncTERM, NetRunner,
// mTelnet, Windows telnet's "ANSI") want CP437; Unix terminals and PuTTY
// want UTF-8.
func pickCP437(mode, ttype string) bool {
	switch mode {
	case "cp437":
		return true
	case "utf8":
		return false
	}
	for _, u := range []string{"xterm", "putty", "linux", "rxvt", "screen", "tmux", "alacritty", "kitty", "wezterm", "foot", "konsole", "gnome", "vt220", "vt100", "vt102", "dumb",
		"iterm", "ghostty", "windows terminal", "mintty", "vte", "contour", "tabby", "hyper", "warp", "terminal.app", "apple_terminal"} {
		if strings.Contains(ttype, u) {
			return false
		}
	}
	return true
}

func serveTelnet(conn net.Conn, h *hub, opt viewOptions, active *atomic.Int32) {
	defer conn.Close()
	defer active.Add(-1)
	if tc, ok := conn.(*net.TCPConn); ok {
		tc.SetNoDelay(true)
		tc.SetKeepAlive(true)
		tc.SetKeepAlivePeriod(30 * time.Second)
	}
	s := &session{
		conn: conn, opt: opt, hub: h, id: conn.RemoteAddr().String(),
		data: make(chan []byte, 64), ttypeSeen: make(chan struct{}), closed: make(chan struct{}),
	}
	s.ttype.Store("")
	s.cols.Store(80)
	s.rows.Store(25)
	start := time.Now()

	// We echo nothing and want character-at-a-time, 8-bit clean input/output;
	// ask for the window size and terminal name.
	s.negSent = time.Now()
	s.raw([]byte{
		tIAC, tWILL, optEcho, tIAC, tWILL, optSGA, tIAC, tDO, optSGA,
		tIAC, tWILL, optBinary, tIAC, tDO, optBinary,
		tIAC, tDO, optNAWS, tIAC, tDO, optTType,
	})
	go s.readLoop()

	// Give the client a moment to answer the negotiation.
	select {
	case <-s.ttypeSeen:
	case <-time.After(1200 * time.Millisecond):
	case <-s.closed:
		return
	}
	deadline := time.Now().Add(300 * time.Millisecond)
	for !s.nawsSeen.Load() && time.Now().Before(deadline) {
		time.Sleep(20 * time.Millisecond)
	}
	ttype := s.ttype.Load().(string)

	// Everything the caller typed so far, plus probe leftovers, goes to the
	// key parser later.
	var pending []byte
	drain := func() {
		for {
			select {
			case b, ok := <-s.data:
				if !ok {
					return
				}
				pending = append(pending, b...)
			default:
				return
			}
		}
	}
	drain()

	// Colour depth.
	use16 := false
	ctermVer := "" // SyncTERM's CTerm revision, from its Device Attributes reply
	colorWhy := "set by color in tvserver.ini"
	color := opt.color
	if opt.web {
		color = opt.webColor
		ttype = "web browser (fTelnet)"
	}
	switch color {
	case "16":
		use16 = true
	case "truecolor", "256":
	default:
		res := termprobe.ColorDepth(s, termprobe.ChanReader(s.data), 500*time.Millisecond)
		use16 = res.Depth != termprobe.DepthTrue
		colorWhy = "color = auto: the terminal supports 24-bit"
		if use16 {
			colorWhy = "color = auto: the terminal didn't report 24-bit"
		}
		pending = append(pending, res.Leftover...)
		ctermVer = res.CTerm
		// No TTYPE answer: the probe's reply still tells us who it is.
		if ttype == "" {
			if res.CTerm != "" {
				ttype = "syncterm"
			} else {
				ttype = strings.ToLower(res.Terminal)
			}
		}
	}
	cp437 := pickCP437(opt.encoding, ttype)
	if opt.web {
		// The web page scales sixel pictures made for 8x16 cells to its font.
		opt.cellW, opt.cellH = 8, 16
		cp437 = true // fTelnet draws with the IBM PC (CP437) font
		colorWhy = "web viewer (web_color in tvserver.ini)"
	}

	// Window size: NAWS if the client offered it, else a cursor-position probe.
	if !s.nawsSeen.Load() {
		s.write([]byte(cprProbe))
		var kp keyParser
		end := time.After(800 * time.Millisecond)
	probe:
		for {
			select {
			case b, ok := <-s.data:
				if !ok {
					return
				}
				for _, c := range b {
					if ev, c2, r2 := kp.feed(c); ev == keyResize {
						s.cols.Store(int32(c2))
						s.rows.Store(int32(r2))
						break probe
					}
				}
				pending = append(pending, b...)
			case <-end:
				break probe
			}
		}
	}

	// SyncTERM 1.10a+ can play sound sent as Audio APC escape sequences.
	// Ask once; other terminals ignore the question and get video only.
	opt.audio.Codec = codecFor(opt.audio.Codec, ttype) // auto: by terminal program
	audio := newAudioSession(opt.audio)
	probeBytes, noSoundWhy := audio.detectTimed(s, termprobe.ChanReader(s.data), 1500*time.Millisecond)
	pending = append(pending, probeBytes...)
	// Sound debugging for SyncTERM-like callers whose sound wasn't confirmed
	// by an answer (or every caller, with sound_debug = on).
	cterm := strings.Contains(ttype, "syncterm") || ctermVer != ""
	if opt.audio.Mode != "off" && (opt.soundDebug || (cterm && (noSoundWhy != "" || opt.audio.Mode == "on"))) {
		res, rest := soundDebugProbe(s, termprobe.ChanReader(s.data), 2500*time.Millisecond)
		pending = append(pending, rest...)
		log.Printf("sound debug, caller %s: %s", s.id, res)
		audio.mu.Lock()
		audio.apcIgnored = res.audioAnswered && !res.verAnswered
		audio.mu.Unlock()
		if res.sndfile == 1 && !audio.enabled {
			// It does answer - just slowly. Turn sound on.
			audio.mu.Lock()
			audio.enabled = true
			audio.mu.Unlock()
			noSoundWhy = ""
		}
	}
	fps := opt.fps
	maxFPS := opt.maxFPS
	if maxFPS < fps {
		maxFPS = fps
	}
	if audio.is3DBBS { // Nintendo 3DS terminal: small intake, spend it on sound
		use16 = true
		colorWhy = "Nintendo 3DS terminal"
		if fps > 10 {
			fps = 10
		}
		maxFPS = fps
	}
	// A shallow kernel send buffer: the pacing below only works if a slow
	// connection makes our writes wait, instead of Windows quietly queueing
	// megabytes of picture that would play out seconds late. Sound gets an
	// even shallower one so it never sits behind much picture data.
	sendBuf := sendBufferSize(s.rtt(), audio.enabled)
	if tc, ok := conn.(interface{ SetWriteBuffer(int) error }); ok {
		tc.SetWriteBuffer(sendBuf)
	}

	colorMode := colorTrue
	switch {
	case use16:
		colorMode = color16
	case color == "256":
		colorMode = color256
	}
	depth := depthName(colorMode)
	depthLog := depth + " (" + colorWhy + ")"
	enc := "utf8"
	if cp437 {
		enc = "cp437"
	}
	if ttype == "" {
		ttype = "unknown"
	}
	// SyncTERM ignores every SyncTERM: command (sound included) when it
	// can't make a cache folder named after the connection - which is what
	// happens on Windows for a quick-connect to host:port, since ':' isn't
	// allowed in folder names (SyncTERM's apc_handler/get_cache_fn_base).
	syncNoAPC := noSoundWhy == soundNoAnswer && cterm
	if syncNoAPC {
		noSoundWhy = "SyncTERM didn't answer the sound check - see the \"sound debug\" line above"
	}
	sound := "no (" + noSoundWhy + ")"
	if audio.enabled {
		sound = "yes"
	}
	if ctermVer != "" {
		ttype += " (CTerm " + ctermVer + ")"
	}
	rttDesc := "round trip unknown"
	if r := s.rtt(); r > 0 {
		rttDesc = fmt.Sprintf("round trip %d ms", r.Milliseconds())
	}
	log.Printf("caller %s connected: terminal=%s %dx%d %s %s sound=%s (%s, send buffer %d KB)",
		s.id, ttype, s.cols.Load(), s.rows.Load(), depthLog, enc, sound, rttDesc, sendBuf>>10)
	defer func() {
		log.Printf("caller %s left after %s", s.id, time.Since(start).Round(time.Second))
	}()

	// Keys: Q / X / ENTER / Ctrl-C / ESC quit, M mutes; CPR and audio
	// status reports from the terminal come in on the same stream.
	quit := make(chan struct{})
	var quitOnce sync.Once
	var lateYes atomic.Bool // the terminal said yes to sound after we gave up
	var showCaptions, showTitle atomic.Bool
	menuOpen := false               // owned by the key reader; the render loop follows its 'o'/'c' messages
	menuKeys := make(chan byte, 32) // settings-menu keys, handled by the render loop
	menuSend := func(c byte) {
		select {
		case menuKeys <- c:
		default:
		}
	}
	showCaptions.Store(opt.captions)
	showTitle.Store(opt.titleBar)
	go func() {
		var kp keyParser
		handle := func(b []byte) bool {
			for i, c := range b {
				if kp.state == ksGround && menuOpen && c != 3 {
					// The settings menu has the keyboard: 1-4 change things,
					// S / Q / ENTER / ESC close it (and don't quit).
					switch {
					case c >= '1' && c <= '7':
						menuSend(c)
						continue
					case c == 's' || c == 'S' || c == 'q' || c == 'Q' || c == 'x' || c == 'X' || c == '\r' || c == '\n',
						c == 27 && (i == len(b)-1 || (b[i+1] != '[' && b[i+1] != 'O')):
						menuOpen = false
						menuSend('c')
						continue
					}
				}
				if kp.state == ksGround && opt.menu && (c == '+' || c == '=' || c == '-' || c == '_') {
					// Frame rate up / down, any time (menu open or not).
					if c == '=' {
						c = '+'
					} else if c == '_' {
						c = '-'
					}
					menuSend(c)
					continue
				}
				if kp.state == ksGround && opt.menu && (c == 's' || c == 'S') {
					menuOpen = true
					menuSend('o')
					continue
				}
				if kp.state == ksGround && (c == 'c' || c == 'C') {
					showCaptions.Store(!showCaptions.Load())
					continue
				}
				if kp.state == ksGround && (c == 't' || c == 'T') {
					showTitle.Store(!showTitle.Load())
					continue
				}
				ev, c2, r2 := kp.feed(c)
				switch ev {
				case keyQuit:
					return true
				case keyResize:
					s.cols.Store(int32(c2))
					s.rows.Store(int32(r2))
				case keyAudioDSR:
					if pairs, ok := parseDSRPairs(kp.params); ok {
						for _, p := range pairs {
							if p[0] == audioFeatureID {
								// The sound check's answer, arriving late (a
								// re-ask, or a slow link): act on a yes.
								if p[1] != 0 && opt.audio.Mode != "off" {
									lateYes.Store(true)
								}
							}
						}
						audio.onDSR(pairs, time.Now())
					}
				case keyMute:
					audio.toggleMute()
				}
			}
			return false
		}
		// Bytes typed during negotiation are replayed, but a bare CR/LF
		// some clients send on connect must not count as ENTER-to-quit.
		if handle(bytes.Trim(pending, "\r\n\x00")) {
			quitOnce.Do(func() { close(quit) })
			return
		}
		for b := range s.data {
			if handle(b) {
				quitOnce.Do(func() { close(quit) })
				return
			}
		}
	}()

	v := newViewer(audio.enabled)
	h.subscribe(opt.channel, v)
	defer h.unsubscribe(opt.channel, v)

	// Output queue: sound always goes before the next slice of picture, and
	// pictures are cut into ~4 KB slices at escape-code boundaries, so a big
	// repaint on a slow link never makes the caller's audio run dry.
	q := newOutQueue(s)
	st := &viewerStats{id: s.id, terminal: ttype, depth: depth, fps: fps, start: start, q: q, v: v, audio: audio, sess: s}
	h.addViewerStats(st)
	defer h.removeViewerStats(st)
	var setup bytes.Buffer
	setup.WriteString("\x1b[0m\x1b[?25l\x1b[?7l\x1b[2J\x1b[H")
	audio.start(&setup)
	q.pushAudio(setup.Bytes())
	defer func() {
		q.stop() // waits for any half-sent slice to finish
		if s.isClosed() {
			return
		}
		var bye bytes.Buffer
		bye.WriteString("\x1b\\") // close any open escape string
		audio.stop(&bye)          // silence the queued tail now
		bye.WriteString("\x1b[0m\x1b[?7h\x1b[?25h\x1b[2J\x1b[HThanks for watching!\r\n")
		s.write(bye.Bytes())
	}()

	glyph := []byte("▀")
	if cp437 {
		glyph = []byte{0xDF}
	}
	hintText := hintFor(audio.enabled, opt.menu)

	reaskAt := []time.Duration{4 * time.Second, 15 * time.Second}
	reask := 0
	minInterval := time.Duration(float64(time.Second) / fps)
	tickEvery := time.Duration(float64(time.Second)/maxFPS) / 2 // fast enough for the highest rate a viewer can pick
	if audio.enabled && tickEvery > 20*time.Millisecond {
		tickEvery = 20 * time.Millisecond // audio upkeep runs on this beat
	}
	tick := time.NewTicker(tickEvery)
	defer tick.Stop()

	// The viewer's own settings (S menu).
	vs := viewerSettings{color: colorMode, fps: fps, maxFPS: maxFPS, sound: audio.enabled, lipSync: opt.lipSync, sixelOK: opt.sixel, detail: opt.sixelDetail,
		quality: opt.audio.Quality, codec: opt.audio.Codec, volume: opt.audio.VolumeDB}
	if audio.is3DBBS {
		vs.codec = sound8bit
	}
	switch noSoundWhy {
	case soundOffSetting:
		vs.noSound = "off on this server"
	case soundUnsupported:
		vs.noSound = "your terminal can't play it"
	case soundNoAnswer:
		vs.noSound = "no answer from your terminal yet"
	}
	if syncNoAPC {
		vs.noSound = "off: your terminal didn't answer"
	}
	menuShown := false
	menuDirty := false
	var bwAt time.Time
	var bwBytes int64
	bwText := ""
	var arrivedAt int64 // frames received from the camera, for feed fps
	topText := hintText // the top bar: key hints, or a short notice
	var keys []byte
	soundWarned := false
	soundReported := false

	var prev []byte
	sig := ""
	lastBar := "" // title bar as last drawn
	var lastPaint time.Time
	var pendingFrame []byte
	var frameQ []queuedFrame // newest last: frames waiting for their sound to play
	// When the camera PC's picture runs behind its sound (a busy PC, a heavy
	// video, or sound from a different source than the picture), waiting
	// for perfect lip-sync would mean never showing a frame. syncLag is how
	// far behind the picture is; frames are matched to the sound that much
	// later, so the picture keeps moving, just a little out of step.
	var syncLag int64
	lastShown := time.Now() // last time a picture frame was drawn
	var lagLogged time.Time
	hintUntil := time.Now().Add(5 * time.Second)
	hintShown := opt.hint
	if syncNoAPC {
		// Tell the viewer why they hear nothing, and how to fix it.
		topText = " No sound: your terminal didn't answer the sound check. "
		hintShown, hintUntil = true, time.Now().Add(12*time.Second)
	}
	nextProbe := time.Now().Add(time.Second)
	waitingShown := false
	offlineShown := false
	lastFrameAt := time.Now()

	// applyVS puts the viewer's settings into effect.
	applyVS := func() {
		colorMode, depth = vs.color, depthName(vs.color)
		use16 = colorMode == color16
		minInterval = time.Duration(float64(time.Second) / vs.fps)
		audio.setSound(vs.quality, vs.codec)
		audio.setVolume(vs.volume)
		st.setView(depth, vs.fps)
		// Low detail draws the normal picture: no need for the sharp copy.
		h.setWantHi(opt.channel, v, colorMode == colorSixel && vs.detail != sixelLow)
		prev, lastBar = nil, ""
	}
	// What this viewer chose last time (same address and terminal program).
	prefKey := viewerKey(s.id, ttype)
	if p, ok := viewerPrefs.get(prefKey); ok && opt.menu {
		vs.restore(p)
		applyVS()
		log.Printf("caller %s: using their saved settings (%s)", s.id, vs.summary())
	}

	for {
		select {
		case <-s.closed:
			return
		case <-quit:
			return
		case <-v.notify:
		case <-tick.C:
		case c := <-menuKeys:
			keys = append(keys, c)
		}
		now := time.Now()
		for more := true; more; {
			select {
			case c := <-menuKeys:
				keys = append(keys, c)
			default:
				more = false
			}
		}
		for _, c := range keys {
			{
				switch {
				case c == 'o' || c == 'c':
					menuShown = c == 'o'
					prev, lastBar = nil, "" // repaint everything around/under it
					waitingShown = false
					menuDirty = menuShown
				case menuShown || c == '+' || c == '-':
					if vs.change(c) {
						if c == '+' || c == '-' {
							// Say what it is now, briefly, along the top.
							topText = " Speed: " + vs.speedText() + "  (+ faster, - slower) "
							hintShown, hintUntil = true, now.Add(2500*time.Millisecond)
						}
						applyVS()
						menuDirty = true
						viewerPrefs.put(prefKey, vs.saved())
						log.Printf("caller %s changed settings: %s", s.id, vs.summary())
					}
				}
			}
		}
		keys = keys[:0]
		if now.Sub(bwAt) >= time.Second {
			total := q.bytesPaint.Load() + q.bytesAudio.Load()
			if !bwAt.IsZero() {
				bwText = fmt.Sprintf("%.2f Mbit/s", float64(total-bwBytes)*8/1e6/now.Sub(bwAt).Seconds())
				if menuShown {
					menuDirty = true
				}
			}
			if a := v.arrived.Load(); !bwAt.IsZero() {
				vs.feedFPS = float64(a-arrivedAt) / now.Sub(bwAt).Seconds()
				arrivedAt = a
			} else {
				arrivedAt = a
			}
			bwAt, bwBytes = now, total
		}
		if !audio.enabled && noSoundWhy == soundNoAnswer && reask < len(reaskAt) && now.Sub(start) > reaskAt[reask] {
			q.pushAudio([]byte(featureProbe)) // ask again; a yes turns sound on
			reask++
		}
		if !audio.enabled && lateYes.Load() {
			audio.mu.Lock()
			audio.enabled = true
			audio.mu.Unlock()
			if tc, ok := conn.(interface{ SetWriteBuffer(int) error }); ok {
				tc.SetWriteBuffer(sendBufferSize(s.rtt(), true))
			}
			var b bytes.Buffer
			audio.start(&b)
			q.pushAudio(b.Bytes())
			v.wantAudio.Store(true)
			vs.sound = true // the S menu can offer sound settings now
			menuDirty = menuShown
			hintText = hintFor(true, opt.menu)
			if !hintShown || now.After(hintUntil) {
				topText = hintText
			}
			log.Printf("caller %s: sound turned on (the terminal's answer arrived late)", s.id)
		}
		// The terminal accepts the sound but never plays it: try a simpler
		// format (ADPCM -> mu-law -> uncompressed), and remember what works.
		if audio.enabled && audio.formatFailed() {
			next := map[string]string{soundADPCM: soundULaw, soundULaw: soundPCM}[vs.codec]
			if next != "" {
				log.Printf("caller %s: the terminal isn't playing %s sound; switching to %s", s.id, vs.codec, next)
				vs.codec = next
				applyVS()
				viewerPrefs.put(prefKey, vs.saved())
				menuDirty = menuShown
			} else if !soundWarned {
				soundWarned = true
				log.Printf("caller %s: the terminal accepts sound but isn't playing any of it - check its sound output setting (in SyncTERM: try a different audio output than the current one)", s.id)
			}
		}
		if !soundReported && now.Sub(start) > 10*time.Second && audio.enabled && (cterm || opt.soundDebug) {
			soundReported = true
			log.Printf("sound debug, caller %s, after 10 s: %s", s.id, audio.debugReport())
		}
		f, chunks := v.take()
		if f != nil {
			frameQ = append(frameQ, queuedFrame{f, now})
			if len(frameQ) > 90 { // ~3 s at 30 fps; never hold more
				frameQ = frameQ[len(frameQ)-90:]
			}
			lastFrameAt = now
		}
		// Pick the frame to show: the newest one whose moment in the sound
		// has come (lip-sync), keeping later ones queued. Without sound,
		// just the newest. A frame never waits more than a second.
		if len(frameQ) > 0 {
			apts, synced := audio.playingPts(now)
			pick := len(frameQ) - 1
			if synced && audio.enabled && vs.lipSync {
				pick = -1
				early := int64(40) // shown at most this far ahead of its sound
				if sl := int64(opt.audio.SlackMs); sl < early {
					early = sl
				}
				for i := len(frameQ) - 1; i >= 0; i-- {
					if p, ok := framePTS(frameQ[i].b); !ok || p+syncLag-apts <= early {
						pick = i
						break
					}
				}
				if pick < 0 && now.Sub(frameQ[0].at) > opt.maxHold {
					pick = 0
				}
			}
			if pick >= 0 {
				st.holdMs.Add(now.Sub(frameQ[pick].at).Milliseconds())
				st.holdN.Add(1)
				pendingFrame = frameQ[pick].b
				frameQ = frameQ[pick+1:]
			}
		}

		// Sound first: new chunks plus the periodic upkeep (drain re-arm,
		// status poll, mute flush).
		if audio.enabled {
			var abuf bytes.Buffer
			for _, c := range chunks {
				if m, ok := parseAudioMsg(c); ok {
					audio.handleChunk(&abuf, m, now)
				}
			}
			audio.tick(&abuf, now)
			if abuf.Len() > 0 {
				q.pushAudio(abuf.Bytes())
			}
		}

		if q.paintBusy() {
			continue // previous picture still going out; keep only the newest
		}
		var buf bytes.Buffer
		builtFrame := false
		dstCols, dstRows := int(s.cols.Load()), int(s.rows.Load())

		if pendingFrame == nil && len(frameQ) == 0 && prev == nil && !waitingShown {
			// No picture yet: tell the caller what's going on.
			waitingShown = true
			buf.WriteString("\x1b[2J")
			msg := opt.banner
			if msg == "" {
				msg = "Telnetvision"
			}
			centered(&buf, msg, dstRows/2-1, dstCols, "\x1b[1;37m")
			centered(&buf, "Waiting for the broadcast to start...", dstRows/2+1, dstCols, "\x1b[0;36m")
			centered(&buf, "Press Q to quit", dstRows/2+3, dstCols, "\x1b[0;37m")
			buf.WriteString("\x1b[0m")
		}

		if pendingFrame != nil && time.Since(lastPaint) >= minInterval && !q.videoOK() {
			st.pacedWaits.Add(1) // waiting for the connection to catch up
		}
		if pendingFrame != nil && time.Since(lastPaint) >= minInterval && q.videoOK() {
			fr := pendingFrame
			pendingFrame = nil
			if len(fr) >= 9 && fr[0] == msgFrame {
				srcCols := int(binary.BigEndian.Uint16(fr[1:3]))
				srcRows := int(binary.BigEndian.Uint16(fr[3:5]))
				mode, rampID := int(fr[5]), int(fr[6])
				capLen := int(binary.BigEndian.Uint16(fr[7:9]))
				px := fr[9:]
				var caption []byte
				if capLen <= len(px) {
					caption, px = px[:capLen], px[capLen:]
				}
				if !showCaptions.Load() {
					caption = onlyMessages(caption) // the sysop's message still shows
				}
				pixelBytes := 2 * srcRows * srcCols * 3
				title := frameTitle(px, pixelBytes)
				// Lip-sync: frames carry their capture time after the pixels.
				// Too late against the audio clock -> skip it; too early ->
				// hold it briefly. Never freeze the picture for over a second.
				skip := false
				if audio.enabled && vs.lipSync && srcCols > 0 && len(px) >= pixelBytes+8 {
					pts := int64(binary.BigEndian.Uint64(px[pixelBytes : pixelBytes+8]))
					// Chosen above as due (or after waiting a second); only a
					// frame that's already too late for its sound is skipped,
					// and never for long: see syncLag.
					if apts, ok := audio.playingPts(now); ok {
						late := apts - pts // how far behind its sound this frame is
						if late < syncLag {
							// The picture caught up (some or all of the way).
							syncLag = late
							if syncLag < 0 {
								syncLag = 0
							}
						}
						if late-syncLag > int64(opt.audio.SlackMs) {
							if !lastShown.IsZero() && now.Sub(lastShown) > 400*time.Millisecond {
								// Frames keep arriving too late: stop waiting
								// for them to line up and follow the picture.
								syncLag = late
								if now.Sub(lagLogged) > 30*time.Second {
									lagLogged = now
									log.Printf("caller %s: the picture arrives %d ms behind its sound; showing it anyway (lip-sync off by that much). Usually the camera PC's upload is too slow for the picture (the sound goes first): use a telnetvision.exe new enough to pack pictures (FEED_COMPRESS=1), lower FPS there, or set SYNC_CAPTURE=0. AUDIO_OFFSET_MS in telnetvision.ini can line them up; lip_sync = off in tvserver.ini stops waiting altogether.", s.id, late)
								}
							} else {
								skip = true
								st.syncDrops.Add(1)
							}
						}
					}
				}
				if !skip && srcCols > 0 && srcRows > 0 && len(px) >= pixelBytes {
					if hintShown && now.After(hintUntil) {
						hintShown = false
						topText = hintText
						prev = nil
					}
					if offlineShown {
						offlineShown = false
						prev = nil
					}
					// The title bar takes the bottom row; the picture fits above.
					barOn := title != "" && showTitle.Load() && dstRows >= 10
					avail := dstRows
					if barOn {
						avail--
					}
					if colorMode == colorSixel && !barOn {
						avail-- // an image touching the bottom line can scroll the screen
					}
					fitCols, fitRows, ox, oy := fitRegion(srcCols, srcRows, dstCols, avail, opt.stretch)
					capLines := captionLines(caption, fitCols)
					// Caption bars cover picture cells, so a change in how many
					// rows they use needs a full repaint underneath.
					ns := fmt.Sprintf("%d-%d-%d-%d-%d-%d-%d-%v-%s", srcCols, srcRows, dstCols, dstRows, mode, rampID, len(capLines), barOn, colorMode)
					if ns != sig {
						prev, sig = nil, ns
					}
					if prev == nil {
						buf.WriteString("\x1b[0m\x1b[2J\x1b[H")
						lastBar = ""
					}
					switch {
					case colorMode == colorSixel:
						fpts := int64(-1)
						if len(px) >= pixelBytes+8 {
							fpts = int64(binary.BigEndian.Uint64(px[pixelBytes : pixelBytes+8]))
						}
						renderSixel(&buf, px, srcCols, srcRows, v.latestHi(), fpts, fitCols, fitRows, ox, oy, opt.cellW, opt.cellH, opt.sixelCols, vs.detail)
						prev = []byte{0} // a whole new image every time; no clearing between
					case mode == 1:
						prev = renderRamp(&buf, px, srcCols, srcRows, fitCols, fitRows, ox, oy, prev, colorMode != colorTrue, opt.saturation, opt.dither, rampGlyphs(rampID, cp437))
					case colorMode == color256:
						prev = render256(&buf, px, srcCols, srcRows, fitCols, fitRows, ox, oy, prev, glyph)
					case use16 && opt.shade:
						prev = renderShade(&buf, px, srcCols, srcRows, fitCols, fitRows, ox, oy, prev, opt.saturation, cp437)
					case use16:
						prev = renderCGA(&buf, px, srcCols, srcRows, fitCols, fitRows, ox, oy, prev, opt.saturation, opt.dither, glyph)
					default:
						prev = renderTrue(&buf, px, srcCols, srcRows, fitCols, fitRows, ox, oy, prev, glyph)
					}
					if len(capLines) > 0 {
						// Just below the picture when there's room, else over
						// its bottom rows.
						capRow := oy + fitRows + 1
						if capRow > avail {
							capRow = avail
						}
						renderCaptionBars(&buf, capLines, ox, capRow, fitCols, cp437)
					}
					if barOn {
						if bar := titleBar(title, opt.banner, dstCols); bar != lastBar {
							fmt.Fprintf(&buf, "\x1b[%d;1H\x1b[0;30;46m", dstRows)
							buf.Write(captionText(bar, cp437))
							buf.WriteString("\x1b[0m")
							lastBar = bar
						}
					}
					if hintShown {
						buf.WriteString("\x1b[1;1H\x1b[1;37;44m" + topText + "\x1b[0m")
					}
					lastPaint = now
					lastShown = now
					builtFrame = true
				}
			}
		}

		// Feed went quiet: say so on the bottom line (picture stays up).
		if prev != nil && !offlineShown && now.Sub(lastFrameAt) > 5*time.Second {
			offlineShown = true
			fmt.Fprintf(&buf, "\x1b[%d;1H\x1b[0;1;37;41m%s\x1b[0m", dstRows, padCenter("Broadcast paused - waiting for it to resume", dstCols))
		}

		// The settings menu sits on top of the picture: redrawn after each
		// picture update (which may have painted under it) or any change.
		if menuShown && (menuDirty || builtFrame) {
			drawMenu(&buf, &vs, bwText, int(s.cols.Load()), int(s.rows.Load()), cp437)
			menuDirty = false
		}

		// Clients without NAWS get a periodic size probe for live resize.
		if !s.nawsSeen.Load() && now.After(nextProbe) {
			buf.WriteString(cprProbe)
			nextProbe = now.Add(time.Second)
		}

		if buf.Len() > 0 {
			if builtFrame {
				q.pushPaint(splitANSIUnits(buf.Bytes(), 4096), true)
				st.painted.Add(1)
			} else {
				q.pushPaint([][]byte{buf.Bytes()}, false)
			}
		}
	}
}

// outQueue is the caller's single writer. Audio goes first; picture slices
// fill the gaps. paintBusy reports whether a picture is still going out, so
// the render loop only ever builds from the newest frame.
//
// It also paces the picture to the caller's real connection speed (the
// original door's "link governor"): whenever writes start blocking, the
// connection is the limit, and the bytes it accepts over that busy stretch
// measure how fast it drains. The picture is then held to 85% of that rate
// with a token bucket, so router and kernel buffers between us and the
// caller stay empty and sound never waits behind seconds of queued picture.
// Sound spends from the same budget but is never held back.
type outQueue struct {
	s        *session
	mu       sync.Mutex
	audio    [][]byte
	units    [][]byte
	painting bool
	quit     bool
	wake     chan struct{}
	done     chan struct{}

	// pacing
	rateEst    float64 // drain rate in bytes/s; 0 = never limited
	tokens     float64 // picture byte budget
	lastTok    time.Time
	frameBytes float64 // size of the last paint, sizes the gate
	busyStart  time.Time
	busyBytes  int
	lastShort  time.Time

	// statistics
	bytesPaint atomic.Int64
	bytesAudio atomic.Int64
}

// A write that takes longer than this was waiting for room in a full send
// buffer, i.e. the connection is the limit right now.
const blockedWrite = 5 * time.Millisecond

func newOutQueue(s *session) *outQueue {
	q := &outQueue{s: s, wake: make(chan struct{}, 1), done: make(chan struct{}),
		lastTok: time.Now(), lastShort: time.Now(), frameBytes: 8192}
	go q.run()
	return q
}

func (q *outQueue) signal() {
	select {
	case q.wake <- struct{}{}:
	default:
	}
}

func (q *outQueue) pushAudio(b []byte) {
	q.mu.Lock()
	q.audio = append(q.audio, append([]byte(nil), b...))
	q.tokens -= float64(len(b)) // sound spends budget, ungated
	q.mu.Unlock()
	q.signal()
}

// pushPaint queues a picture (or other screen update) in slices.
func (q *outQueue) pushPaint(units [][]byte, isFrame bool) {
	n := 0
	for _, u := range units {
		n += len(u)
	}
	q.mu.Lock()
	q.units = append(q.units, units...)
	q.tokens -= float64(n)
	if isFrame {
		q.frameBytes = float64(n)
		if q.frameBytes < 2048 {
			q.frameBytes = 2048 // tiny deltas mustn't open the gate wide
		}
	}
	q.mu.Unlock()
	q.signal()
}

func (q *outQueue) paintBusy() bool {
	q.mu.Lock()
	defer q.mu.Unlock()
	return len(q.units) > 0 || q.painting
}

// videoOK refills the picture budget and reports whether a new frame fits.
func (q *outQueue) videoOK() bool {
	q.mu.Lock()
	defer q.mu.Unlock()
	now := time.Now()
	if q.rateEst > 0 {
		q.tokens += q.rateEst * 0.85 * now.Sub(q.lastTok).Seconds()
		q.tokens = clampTokens(q.tokens, q.rateEst, q.frameBytes)
		// No pressure for a while: the connection may have sped up (or we
		// are holding back too hard). Probe upward until it pushes back.
		if now.Sub(q.lastShort) > 3*time.Second {
			q.rateEst *= 1.5
			if q.rateEst > 8e6 {
				q.rateEst = 0 // faster than any picture needs: stop pacing
			}
			q.lastShort = now
		}
	}
	q.lastTok = now
	return videoBudgetOK(q.rateEst, q.tokens, q.frameBytes)
}

// pacedRate returns the connection speed the picture is paced to (bytes/s),
// or 0 when this caller's connection has never been the limit.
func (q *outQueue) pacedRate() float64 {
	q.mu.Lock()
	defer q.mu.Unlock()
	return q.rateEst
}

// noteWrite feeds one finished write into the drain-rate measurement.
func (q *outQueue) noteWrite(n int, began time.Time, took time.Duration) {
	q.mu.Lock()
	defer q.mu.Unlock()
	now := began.Add(took)
	if took > blockedWrite {
		q.lastShort = now
		if q.busyStart.IsZero() {
			q.busyStart, q.busyBytes = began, 0
		}
		q.busyBytes += n
		if d := now.Sub(q.busyStart); d >= 2*time.Second {
			q.rateEst = updateRate(q.rateEst, q.busyBytes, d)
			q.busyStart, q.busyBytes = now, 0
		}
		return
	}
	if q.busyStart.IsZero() {
		return
	}
	q.busyBytes += n
	// The busy stretch ends only after a real lull in blocked writes, not
	// when one slice happens to fit.
	if d := now.Sub(q.busyStart); now.Sub(q.lastShort) >= 250*time.Millisecond {
		if d >= 300*time.Millisecond {
			q.rateEst = updateRate(q.rateEst, q.busyBytes, d)
		}
		q.busyStart, q.busyBytes = time.Time{}, 0
	} else if d >= 2*time.Second {
		q.rateEst = updateRate(q.rateEst, q.busyBytes, d)
		q.busyStart, q.busyBytes = now, 0
	}
}

// stop ends the writer after the slice it is sending, if any.
func (q *outQueue) stop() {
	q.mu.Lock()
	q.quit = true
	q.mu.Unlock()
	q.signal()
	<-q.done
}

func (q *outQueue) run() {
	defer close(q.done)
	for {
		q.mu.Lock()
		if q.quit {
			q.mu.Unlock()
			return
		}
		var b []byte
		isAudio := false
		switch {
		case len(q.audio) > 0:
			b, q.audio = q.audio[0], q.audio[1:]
			isAudio = true
		case len(q.units) > 0:
			b, q.units = q.units[0], q.units[1:]
			q.painting = true
		}
		q.mu.Unlock()
		if b == nil {
			select {
			case <-q.wake:
			case <-q.s.closed:
				return
			}
			continue
		}
		began := time.Now()
		err := q.s.write(b)
		q.noteWrite(len(b), began, time.Since(began))
		if isAudio {
			q.bytesAudio.Add(int64(len(b)))
		} else {
			q.bytesPaint.Add(int64(len(b)))
		}
		q.mu.Lock()
		q.painting = false
		q.mu.Unlock()
		if err != nil {
			return
		}
	}
}

func padCenter(msg string, width int) string {
	r := []rune(msg)
	if len(r) > width {
		r = r[:width]
	}
	left := (width - len(r)) / 2
	return strings.Repeat(" ", left) + string(r) + strings.Repeat(" ", width-len(r)-left)
}

func centered(buf *bytes.Buffer, msg string, row, width int, sgr string) {
	r := []rune(msg)
	if len(r) > width {
		r = r[:width]
	}
	if row < 1 {
		row = 1
	}
	fmt.Fprintf(buf, "\x1b[%d;%dH%s%s", row, (width-len(r))/2+1, sgr, string(r))
}

// frameTitle reads the optional movie title that follows a FRAME's pts:
// 'T' 'I' u16 len title.
func frameTitle(px []byte, pixelBytes int) string {
	o := pixelBytes + 8
	if len(px) < o+4 || px[o] != 'T' || px[o+1] != 'I' {
		return ""
	}
	n := int(binary.BigEndian.Uint16(px[o+2 : o+4]))
	if len(px) < o+4+n {
		return ""
	}
	return strings.ToValidUTF8(string(px[o+4:o+4+n]), "?")
}

// titleBar lays out the bottom bar: the title on the left, the banner on
// the right when there's room, padded to the screen width.
func titleBar(title, banner string, width int) string {
	left := []rune(" " + title)
	right := []rune(banner + " ")
	if banner == "" || len(left)+len(right)+2 > width {
		right = nil
	}
	if len(left) > width-len(right) {
		left = append(left[:max(0, width-len(right)-3)], '.', '.', '.')
	}
	pad := width - len(left) - len(right)
	if pad < 0 {
		pad = 0
	}
	return string(left) + strings.Repeat(" ", pad) + string(right)
}

// queuedFrame is a picture waiting for its moment in the sound.
type queuedFrame struct {
	b  []byte
	at time.Time // when it arrived
}

// framePTS reads a FRAME message's time stamp (after the pixels).
func framePTS(fr []byte) (int64, bool) {
	if len(fr) < 9 || fr[0] != msgFrame {
		return 0, false
	}
	cols := int(binary.BigEndian.Uint16(fr[1:3]))
	rows := int(binary.BigEndian.Uint16(fr[3:5]))
	off := 9 + int(binary.BigEndian.Uint16(fr[7:9])) + 2*rows*cols*3
	if cols == 0 || off+8 > len(fr) {
		return 0, false
	}
	return int64(binary.BigEndian.Uint64(fr[off : off+8])), true
}
