package main

import (
	"bytes"
	"fmt"
)

// 256-color rendering (xterm palette: a 6x6x6 color cube plus 24 grays),
// for viewers who pick 256 colors to save bandwidth or whose terminal
// can't do 24-bit. About half the bytes of 24-bit color per cell.

var xterm256 [32768]byte // 5 bits per channel -> palette index

func init() {
	levels := [6]int{0, 95, 135, 175, 215, 255}
	near := func(v int) int {
		best, bd := 0, 1<<30
		for i, l := range levels {
			if d := (v - l) * (v - l); d < bd {
				best, bd = i, d
			}
		}
		return best
	}
	for i := range xterm256 {
		r, g, b := (i>>10&31)<<3|4, (i>>5&31)<<3|4, (i&31)<<3|4
		ri, gi, bi := near(r), near(g), near(b)
		cr, cg, cb := levels[ri], levels[gi], levels[bi]
		cd := (r-cr)*(r-cr) + (g-cg)*(g-cg) + (b-cb)*(b-cb)
		idx := 16 + 36*ri + 6*gi + bi
		// The gray ramp is finer than the cube's grays; use it when closer.
		avg := (r + g + b) / 3
		gs := (avg - 8 + 5) / 10
		if gs < 0 {
			gs = 0
		} else if gs > 23 {
			gs = 23
		}
		gv := 8 + 10*gs
		if gd := (r-gv)*(r-gv) + (g-gv)*(g-gv) + (b-gv)*(b-gv); gd < cd {
			idx = 232 + gs
		}
		xterm256[i] = byte(idx)
	}
}

func to256(r, g, b byte) byte { return xterm256[int(r>>3)<<10|int(g>>3)<<5|int(b>>3)] }

// render256 is renderTrue with palette colors: 2 bytes per cell in prev.
func render256(buf *bytes.Buffer, px []byte, srcCols, srcRows, dstCols, dstRows, ox, oy int, prev, glyph []byte) []byte {
	colMap, rowMap := sampleMaps(srcCols, srcRows, dstCols, dstRows)
	cur := make([]byte, dstRows*dstCols*2)
	lastFG, lastBG := -1, -1
	curRow, curCol := -1, -1
	for y := 0; y < dstRows; y++ {
		spTop, spBot := rowMap[2*y], rowMap[2*y+1]
		for x := 0; x < dstCols; x++ {
			sx := colMap[x]
			tp := (spTop*srcCols + sx) * 3
			bp := (spBot*srcCols + sx) * 3
			fg := to256(px[tp], px[tp+1], px[tp+2])
			bg := to256(px[bp], px[bp+1], px[bp+2])
			ci := (y*dstCols + x) * 2
			cur[ci], cur[ci+1] = fg, bg
			if prev != nil && len(prev) == len(cur) && prev[ci] == fg && prev[ci+1] == bg {
				continue
			}
			if curRow != y || curCol != x {
				fmt.Fprintf(buf, "\x1b[%d;%dH", y+1+oy, x+1+ox)
			}
			switch {
			case int(fg) != lastFG && int(bg) != lastBG:
				fmt.Fprintf(buf, "\x1b[38;5;%d;48;5;%dm", fg, bg)
			case int(fg) != lastFG:
				fmt.Fprintf(buf, "\x1b[38;5;%dm", fg)
			case int(bg) != lastBG:
				fmt.Fprintf(buf, "\x1b[48;5;%dm", bg)
			}
			lastFG, lastBG = int(fg), int(bg)
			buf.Write(glyph)
			curRow, curCol = y, x+1
			if curCol >= dstCols {
				curRow, curCol = -1, -1
			}
		}
	}
	return cur
}
