package main

import (
	"bytes"
	"fmt"
	"os"
	"testing"
	"time"
)

func TestSixelSizes(t *testing.T) {
	dir := os.Getenv("SIXEL_DIR")
	if dir == "" {
		t.Skip("set SIXEL_DIR")
	}
	for _, name := range []string{"frac", "noisy"} {
		for _, sz := range [][2]int{{80, 48}, {120, 72}, {160, 96}} {
			w, h := sz[0], sz[1]
			raw, err := os.ReadFile(fmt.Sprintf("%s/%s_%dx%d.rgb", dir, name, w, h))
			if err != nil {
				t.Fatal(err)
			}
			for _, cols := range []int{16, 32, 64} {
				scale := 640 / w
				if w == 120 {
					scale = 5
				}
				var total, n int
				start := time.Now()
				for off := 0; off+w*h*3 <= len(raw); off += w * h * 3 {
					var b bytes.Buffer
					sixelImage(&b, raw[off:off+w*h*3], w, h, scale, scale, cols)
					total += b.Len()
					n++
				}
				t.Logf("%-5s %dx%d x%d -> %dx%d, %3d colours: %6d bytes/frame = %5.1f Mbit/s at 15 fps, %v/frame",
					name, w, h, scale, w*scale, h*scale, cols, total/n, float64(total/n)*8*15/1e6, time.Since(start)/time.Duration(n))
			}
		}
	}
}

func TestSixelDump(t *testing.T) {
	dir := os.Getenv("SIXEL_DIR")
	if dir == "" {
		t.Skip()
	}
	raw, _ := os.ReadFile(dir + "/frac_160x96.rgb")
	var b bytes.Buffer
	sixelImage(&b, raw[:160*96*3], 160, 96, 4, 4, 64)
	os.WriteFile(dir+"/frac.six", b.Bytes(), 0644)
}
