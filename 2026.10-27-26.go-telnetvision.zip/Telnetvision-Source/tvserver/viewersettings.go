package main

import (
	"bytes"
	"fmt"
	"strings"
)

// The viewer's own settings menu (S key): each caller can lower their
// colors, frame rate and sound quality to suit their connection.

const (
	colorTrue  = "true"
	color256   = "256"
	color16    = "16"
	colorSixel = "sixel"
)

func depthName(mode string) string {
	switch mode {
	case color256:
		return "256-color"
	case color16:
		return "16-color"
	case colorSixel:
		return "sixel"
	}
	return "truecolor"
}

func hintFor(sound, menu bool) string {
	h := " Q quit | C captions | T title "
	if sound {
		h += "| M mute "
	}
	if menu {
		h += "| +/- speed | S settings "
	}
	return h
}

type viewerSettings struct {
	color   string
	fps     float64
	maxFPS  float64
	feedFPS float64 // what's arriving from the camera PC, measured
	sound   bool    // this viewer can hear sound at all
	quality string
	codec   string
	lipSync bool
	volume  int    // dB: below 0 quieter, above 0 boosted
	noSound string // why there's no sound, for the menu
	sixelOK bool   // offer sixel graphics in the colour choices
	detail  string // sixel detail: high | medium | low
}

var volumeSteps = []int{-12, -6, -3, 0, 3, 6, 9, 12}

func (v *viewerSettings) saved() savedSettings {
	return savedSettings{Color: v.color, FPS: v.fps, Quality: v.quality, Codec: v.codec, LipSync: v.lipSync, Volume: v.volume, Detail: v.detail}
}

// restore applies saved choices, keeping only ones valid here now.
func (v *viewerSettings) restore(p savedSettings) {
	switch p.Color {
	case colorTrue, color256, color16:
		v.color = p.Color
	case colorSixel:
		if v.sixelOK {
			v.color = p.Color
		}
	}
	if p.FPS >= 1 && p.FPS <= v.maxFPS {
		v.fps = p.FPS
	}
	if _, ok := normalizeQuality(p.Quality); ok && p.Quality != "" {
		v.quality = p.Quality
	}
	if p.Codec == soundADPCM || p.Codec == soundULaw || p.Codec == soundPCM {
		if v.codec != sound8bit {
			v.codec = p.Codec
		}
	}
	v.lipSync = p.LipSync
	if p.Volume >= -12 && p.Volume <= 12 {
		v.volume = p.Volume
	}
	if d, ok := normalizeSixelDetail(p.Detail); ok && p.Detail != "" {
		v.detail = d
	}
}

func volumeLabel(db int) string {
	switch {
	case db == 0:
		return "Full (0 dB)"
	case db < 0:
		return fmt.Sprintf("%d dB (quieter)", db)
	}
	return fmt.Sprintf("+%d dB (boosted)", db)
}

// fpsChoices are the frame rates a viewer can pick, slowest first.
func (v *viewerSettings) fpsChoices() []float64 {
	var out []float64
	for _, f := range []float64{1, 2, 3, 5, 6, 8, 10, 12, 15, 20, 24, 25, 30, 40, 50, 60} {
		if f <= v.maxFPS+0.01 {
			out = append(out, f)
		}
	}
	if !containsFPS(out, v.maxFPS) {
		out = append(out, v.maxFPS)
	}
	if !containsFPS(out, v.fps) { // e.g. fps = 7.5 in tvserver.ini
		i := 0
		for i < len(out) && out[i] < v.fps {
			i++
		}
		out = append(out[:i], append([]float64{v.fps}, out[i:]...)...)
	}
	return out
}

func containsFPS(list []float64, f float64) bool {
	for _, x := range list {
		if x > f-0.01 && x < f+0.01 {
			return true
		}
	}
	return false
}

// stepFPS moves the frame rate one choice up (+1) or down (-1).
func (v *viewerSettings) stepFPS(dir int) bool {
	ch := v.fpsChoices()
	for i, f := range ch {
		if f > v.fps-0.01 && f < v.fps+0.01 {
			if j := i + dir; j >= 0 && j < len(ch) {
				v.fps = ch[j]
				return true
			}
			return false
		}
	}
	return false
}

func (v *viewerSettings) speedText() string {
	t := fmt.Sprintf("%g frames a second", v.fps)
	switch {
	case v.fps >= v.maxFPS-0.01:
		t += " (fastest)"
	case v.fps <= 1.01:
		t += " (slowest)"
	}
	if v.feedFPS >= 1 && v.fps > v.feedFPS+0.9 {
		t += fmt.Sprintf(" - camera sends %.0f", v.feedFPS)
	}
	return t
}

func nextOf[T comparable](list []T, cur T) T {
	for i, x := range list {
		if x == cur {
			return list[(i+1)%len(list)]
		}
	}
	return list[0]
}

// change applies menu key c ('1'..'4') and reports whether anything changed.
func (v *viewerSettings) change(c byte) bool {
	switch c {
	case '1':
		choices := []string{colorTrue, color256, color16}
		if v.sixelOK {
			choices = append(choices, colorSixel)
		}
		v.color = nextOf(choices, v.color)
	case '+':
		return v.stepFPS(+1)
	case '-':
		return v.stepFPS(-1)
	case '2': // step slower, wrapping round to the fastest
		if !v.stepFPS(-1) {
			v.fps = v.maxFPS
		}
	case '3':
		if !v.sound {
			return false
		}
		v.quality = nextOf(qualityOrder, v.quality)
	case '4':
		if !v.sound || v.codec == sound8bit {
			return false
		}
		v.codec = nextOf(codecOrder, v.codec)
	case '5':
		if !v.sound {
			return false
		}
		v.lipSync = !v.lipSync
	case '6':
		if !v.sound {
			return false
		}
		v.volume = nextOf(volumeSteps, v.volume)
	case '7':
		if v.color != colorSixel {
			return false
		}
		v.detail = nextOf(sixelDetails, v.detail)
	default:
		return false
	}
	return true
}

func (v *viewerSettings) colorLabel() string {
	switch v.color {
	case color256:
		return "256 colors"
	case color16:
		return "16 colors (least data)"
	case colorSixel:
		return "Sixel graphics (real pixels)"
	}
	return "24-bit (best)"
}

func (v *viewerSettings) summary() string {
	s := fmt.Sprintf("colors %s, %g fps", depthName(v.color), v.fps)
	if v.color == colorSixel {
		s += " (" + v.detail + " detail)"
	}
	if v.sound {
		s += ", sound " + v.quality
		if v.quality != qualityOff {
			s += " " + v.codec
		}
		s += fmt.Sprintf(", volume %+d dB", v.volume)
		if v.lipSync {
			s += ", lip-sync on"
		} else {
			s += ", lip-sync off"
		}
	}
	return s
}

// drawMenu draws the settings box in the middle of the screen.
func drawMenu(buf *bytes.Buffer, v *viewerSettings, bw string, cols, rows int, cp437 bool) {
	sound, squeeze := qualityLabel(v.quality), codecLabel(v.codec)
	vol := volumeLabel(v.volume)
	detail := "-  (when Colors is Sixel)"
	if v.color == colorSixel {
		detail = sixelDetailLabel(v.detail)
	}
	lip := "Off (picture shown at once: least delay)"
	if v.lipSync {
		lip = "On (picture waits for its sound)"
	}
	if !v.sound {
		why := v.noSound
		if why == "" {
			why = "not available here"
		}
		sound, squeeze, lip, vol = why, "-", "-", "-"
	} else if v.quality == qualityOff {
		squeeze = "-"
	}
	lines := []string{
		" Your viewing settings",
		"",
		" 1  Colors       " + v.colorLabel(),
		" 2  Speed        " + v.speedText(),
		"    (+ faster, - slower, any time)",
		" 3  Sound        " + sound,
		" 4  Compression  " + squeeze,
		" 5  Lip-sync     " + lip,
		" 6  Volume       " + vol,
		" 7  Sixel detail " + detail,
		"",
	}
	if bw != "" {
		lines = append(lines, " Using about "+bw)
	}
	lines = append(lines, " Lower settings use less data.", " Press 1-7 or +/- to change, S to close")
	w := 0
	for _, l := range lines {
		if len(l) > w {
			w = len(l)
		}
	}
	w += 2
	if w > cols {
		w = cols
	}
	top := (rows-len(lines))/2 + 1
	if top < 1 {
		top = 1
	}
	left := (cols-w)/2 + 1
	if left < 1 {
		left = 1
	}
	for i, l := range lines {
		if top+i > rows {
			break
		}
		if len(l) > w {
			l = l[:w]
		}
		attr := "\x1b[0;1;37;44m"
		if i == 0 {
			attr = "\x1b[0;1;33;44m"
		} else if strings.HasPrefix(l, " Lower") || strings.HasPrefix(l, " Press") || strings.HasPrefix(l, " Using") || strings.HasPrefix(l, "    (") {
			attr = "\x1b[0;36;44m"
		}
		fmt.Fprintf(buf, "\x1b[%d;%dH%s", top+i, left, attr)
		buf.Write(captionText(l+strings.Repeat(" ", w-len(l)), cp437))
	}
	buf.WriteString("\x1b[0m")
}

// setView records this viewer's current colors and frame rate for stats.
func (st *viewerStats) setView(depth string, fps float64) {
	st.mu.Lock()
	st.depth, st.fps = depth, fps
	st.mu.Unlock()
}

func (st *viewerStats) view() (string, float64) {
	st.mu.Lock()
	defer st.mu.Unlock()
	return st.depth, st.fps
}
