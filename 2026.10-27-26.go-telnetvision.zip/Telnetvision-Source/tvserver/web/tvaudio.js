// Telnetvision web extras for fTelnet: plays the SyncTERM sound clips
// tvserver sends, so browser viewers hear the broadcast like SyncTERM users
// do, and draws sixel pictures, which fTelnet itself can't.
//
// It sits between the connection and fTelnet's screen: the sound commands
// (ESC _ SyncTERM:... ESC \  and the  ESC [ = 7 ; ch n  status questions)
// are taken out of the stream and handled here; everything else is drawn
// by fTelnet as usual. Clips can be WAV PCM (8/16-bit), mu-law or IMA ADPCM.
"use strict";
var TVAudio = (function () {
    var ctx = null, master = null, send = null;
    var files = {};      // name -> bytes (C;S stores)
    var slots = {};      // slot -> decoded AudioBuffer (A;Load)
    var chans = {};      // channel -> {gain, end, sources[], armed}
    var inAPC = false, apc = [], pend = "";   // stream filter state
    var inDCS = false, dcs = [];                // a DCS string (sixel picture) being collected
    var crt = null;                             // fTelnet's screen, for drawing sixel
    var info = { clips: 0, bad: 0, seconds: 0, flushes: 0, replies: 0 }; // for troubleshooting

    function chan(c) {
        if (!chans[c]) {
            var g = ctx.createGain();
            g.connect(master);
            chans[c] = { gain: g, end: 0, sources: [], armed: false };
        }
        return chans[c];
    }

    function reply(s) { if (send) { info.replies++; send(s); } }

    function running(ch) { return ch.end > ctx.currentTime + 0.005; }

    // ---- WAV decoding -------------------------------------------------
    var IDX = [-1, -1, -1, -1, 2, 4, 6, 8, -1, -1, -1, -1, 2, 4, 6, 8];
    var STEP = [7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45,
        50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 130, 143, 157, 173, 190, 209, 230,
        253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963,
        1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327,
        3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442,
        11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767];

    function ulaw(u) {
        u = ~u & 0xFF;
        var s = (((u & 0x0F) << 3) + 0x84) << ((u >> 4) & 7);
        s -= 0x84;
        return (u & 0x80) ? -s : s;
    }

    function decodeWAV(b) {
        var dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
        if (b.length < 12 || dv.getUint32(0) !== 0x52494646 || dv.getUint32(8) !== 0x57415645) { return null; }
        var tag = 0, ch = 0, rate = 0, align = 0, bits = 0, spb = 0, frames = -1, data = null;
        for (var p = 12; p + 8 <= b.length;) {
            var id = dv.getUint32(p), size = dv.getUint32(p + 4, true), body = p + 8;
            if (body + size > b.length) { size = b.length - body; }
            if (id === 0x666d7420) { // "fmt "
                tag = dv.getUint16(body, true); ch = dv.getUint16(body + 2, true);
                rate = dv.getUint32(body + 4, true); align = dv.getUint16(body + 12, true);
                bits = dv.getUint16(body + 14, true);
                if (tag === 0x11 && size >= 20) { spb = dv.getUint16(body + 18, true); }
            } else if (id === 0x66616374) { // "fact"
                frames = dv.getUint32(body, true);
            } else if (id === 0x64617461) { // "data"
                data = b.subarray(body, body + size);
            }
            p = body + size + (size & 1);
        }
        if (!data || ch < 1 || ch > 2 || rate < 3000) { return null; }
        var out = [], c, i, n;
        if (tag === 1 && bits === 16) {
            n = Math.floor(data.length / (2 * ch));
            var d16 = new DataView(data.buffer, data.byteOffset, data.byteLength);
            for (c = 0; c < ch; c++) {
                var f = new Float32Array(n);
                for (i = 0; i < n; i++) { f[i] = d16.getInt16((i * ch + c) * 2, true) / 32768; }
                out.push(f);
            }
        } else if (tag === 1 && bits === 8) {
            n = Math.floor(data.length / ch);
            for (c = 0; c < ch; c++) {
                var f8 = new Float32Array(n);
                for (i = 0; i < n; i++) { f8[i] = (data[i * ch + c] - 128) / 128; }
                out.push(f8);
            }
        } else if (tag === 7) {
            n = Math.floor(data.length / ch);
            for (c = 0; c < ch; c++) {
                var fu = new Float32Array(n);
                for (i = 0; i < n; i++) { fu[i] = ulaw(data[i * ch + c]) / 32768; }
                out.push(fu);
            }
        } else if (tag === 0x11 && spb > 0 && align >= 4 * ch) {
            var blocks = Math.floor(data.length / align);
            n = blocks * spb;
            if (frames >= 0 && frames < n) { n = frames; }
            for (c = 0; c < ch; c++) { out.push(new Float32Array(blocks * spb)); }
            for (var k = 0; k < blocks; k++) {
                var o = k * align, pred = [0, 0], idx = [0, 0], pos = [k * spb, k * spb];
                for (c = 0; c < ch; c++) {
                    pred[c] = (data[o + c * 4] | (data[o + c * 4 + 1] << 8)) << 16 >> 16;
                    idx[c] = Math.min(data[o + c * 4 + 2], 88);
                    out[c][pos[c]++] = pred[c] / 32768;
                }
                var nb = o + 4 * ch, end = o + align;
                var nib = function (c, x) {
                    var st = STEP[idx[c]], df = st >> 3;
                    if (x & 4) { df += st; }
                    if (x & 2) { df += st >> 1; }
                    if (x & 1) { df += st >> 2; }
                    pred[c] += (x & 8) ? -df : df;
                    if (pred[c] > 32767) { pred[c] = 32767; } else if (pred[c] < -32768) { pred[c] = -32768; }
                    idx[c] += IDX[x];
                    if (idx[c] < 0) { idx[c] = 0; } else if (idx[c] > 88) { idx[c] = 88; }
                    out[c][pos[c]++] = pred[c] / 32768;
                };
                if (ch === 1) {
                    for (i = nb; i < end; i++) { nib(0, data[i] & 15); nib(0, data[i] >> 4); }
                } else {
                    for (i = nb; i + 8 <= end; i += 8) {
                        for (c = 0; c < 2; c++) {
                            for (var j = 0; j < 4; j++) { var x = data[i + c * 4 + j]; nib(c, x & 15); nib(c, x >> 4); }
                        }
                    }
                }
            }
            for (c = 0; c < ch; c++) { out[c] = out[c].subarray(0, n); }
        } else {
            return null;
        }
        n = out[0].length;
        if (n === 0) { return null; }
        var buf = ctx.createBuffer(ch, n, rate);
        for (c = 0; c < ch; c++) { buf.getChannelData(c).set(out[c]); }
        return buf;
    }

    // ---- SyncTERM sound commands -----------------------------------------
    function args(list) {
        var a = {};
        for (var i = 0; i < list.length; i++) {
            var e = list[i].indexOf("=");
            if (e > 0) { a[list[i].substring(0, e)] = list[i].substring(e + 1); }
        }
        return a;
    }

    function command(s) {
        if (s.indexOf("SyncTERM:") !== 0) { return; }
        s = s.substring(9);
        if (s.indexOf("C;S;") === 0) { // store a file: C;S;name;base64
            var semi = s.indexOf(";", 4);
            if (semi < 0) { return; }
            var bin = atob(s.substring(semi + 1)), bytes = new Uint8Array(bin.length);
            for (var i = 0; i < bin.length; i++) { bytes[i] = bin.charCodeAt(i); }
            files[s.substring(4, semi)] = bytes;
            return;
        }
        var parts = s.split(";");
        if (parts[0] === "Q" && parts[1] === "libsndfile") {
            reply("\x1b[=7;100;" + (ctx ? 1 : 0) + "n"); // yes (if the viewer allowed sound)
            return;
        }
        if (parts[0] !== "A" || !ctx) { return; }
        var a = args(parts.slice(2)), ch;
        switch (parts[1]) {
            case "Load": // A;Load;S=slot;name
                var name = parts[parts.length - 1];
                if (files[name]) {
                    slots[a.S] = decodeWAV(files[name]);
                    if (slots[a.S]) { info.clips++; } else { info.bad++; }
                    delete files[name];
                }
                break;
            case "Queue": // A;Queue;C=ch;S=slot
                ch = chan(a.C);
                var b = slots[a.S];
                if (!b) { break; }
                var now = ctx.currentTime;
                if (ch.end < now + 0.01) { ch.end = now + 0.03; } // ran dry: restart just ahead
                var src = ctx.createBufferSource();
                src.buffer = b;
                src.connect(ch.gain);
                src.start(ch.end);
                ch.end += b.duration;
                info.seconds += b.duration;
                ch.sources.push(src);
                src.onended = function () {
                    var i = ch.sources.indexOf(src);
                    if (i >= 0) { ch.sources.splice(i, 1); }
                    if (ch.armed && !running(ch)) { // the queue ran out: tell the server
                        ch.armed = false;
                        reply("\x1b[=7;" + a.C + ";0n");
                    }
                };
                break;
            case "Flush":
                ch = chan(a.C);
                ch.sources.forEach(function (x) { x.onended = null; try { x.stop(); } catch (e) { } });
                ch.sources = [];
                ch.end = 0;
                info.flushes++;
                break;
            case "Update": // tell me once when the channel runs dry
                ch = chan(a.C);
                if (!running(ch)) { reply("\x1b[=7;" + a.C + ";0n"); } else { ch.armed = true; }
                break;
            case "Volume": // V=-6dB or V=50 (percent)
                ch = chan(a.C);
                var v = a.V || "100", g;
                if (/dB$/i.test(v)) { g = Math.pow(10, parseFloat(v) / 20); } else { g = Math.max(0, Math.min(100, parseFloat(v))) / 100; }
                if (!isNaN(g)) { ch.gain.gain.value = g; }
                break;
        }
    }

    // ESC [ = 7 ; ch n  - "is channel ch playing?"
    function status(params) {
        var m = /^=7;(\d+)$/.exec(params);
        if (!m || !ctx) { return false; }
        reply("\x1b[=7;" + m[1] + ";" + (running(chan(m[1])) ? 1 : 0) + "n");
        return true;
    }

    // filter takes connection text and returns what fTelnet should draw.
    // It only looks for ESC _ (sound commands) and ESC [ = (sound status
    // questions); all other text and escape codes pass straight through.
    // emit (optional) receives the text before a sixel picture, so fTelnet
    // draws it - and moves its cursor to where the picture goes - first.
    function filter(text, emit) {
        if (pend) { text = pend + text; pend = ""; }
        var out = "", i = 0, n = text.length;
        while (i < n) {
            if (inDCS) {
                var de = text.indexOf("\x1b\\", i);
                if (de < 0) {
                    if (text.charCodeAt(n - 1) === 27) { dcs.push(text.substring(i, n - 1)); pend = "\x1b"; }
                    else { dcs.push(text.substring(i)); }
                    return out;
                }
                dcs.push(text.substring(i, de));
                var body = dcs.join("");
                dcs = []; inDCS = false; i = de + 2;
                if (/^[0-9;]*q/.test(body) && crt) {
                    if (emit && out.length > 0) { emit(out); out = ""; }
                    try { drawSixel(body); } catch (err) { info.sixelErrors = (info.sixelErrors || 0) + 1; }
                } else {
                    out += "\x1b" + "P" + body + "\x1b\\"; // not a picture: fTelnet's business
                }
                continue;
            }
            if (inAPC) {
                var e = text.indexOf("\x1b\\", i);
                if (e < 0) {
                    if (text.charCodeAt(n - 1) === 27) { apc.push(text.substring(i, n - 1)); pend = "\x1b"; }
                    else { apc.push(text.substring(i)); }
                    return out;
                }
                apc.push(text.substring(i, e));
                try { command(apc.join("")); } catch (err) { }
                apc = []; inAPC = false; i = e + 2;
                continue;
            }
            var j = text.indexOf("\x1b", i);
            if (j < 0) { out += text.substring(i); break; }
            if (j + 1 >= n || (text.charAt(j + 1) === "[" && j + 2 >= n)) { // cut off mid-code
                out += text.substring(i, j); pend = text.substring(j); break;
            }
            var c1 = text.charAt(j + 1);
            if (c1 === "P") {
                out += text.substring(i, j); inDCS = true; i = j + 2;
                continue;
            }
            if (c1 === "_") {
                out += text.substring(i, j); inAPC = true; i = j + 2;
                continue;
            }
            if (c1 === "[" && text.charAt(j + 2) === "=") {
                var k = j + 3;
                while (k < n) { var cc = text.charCodeAt(k); if (cc >= 0x40 && cc <= 0x7E) { break; } k++; }
                if (k >= n) { out += text.substring(i, j); pend = text.substring(j); break; }
                out += text.substring(i, j);
                var params = text.substring(j + 2, k);
                if (!(text.charAt(k) === "n" && status(params))) { out += text.substring(j, k + 1); }
                i = k + 1;
                continue;
            }
            out += text.substring(i, j + 1);
            i = j + 1;
        }
        return out;
    }

    // ---- sixel pictures -------------------------------------------------
    // tvserver sizes pictures for 8x16-pixel character cells; they're
    // scaled to the cells fTelnet is really using.
    var six = { canvas: null, ctx: null };

    function drawSixel(body) {
        var q = body.indexOf("q");
        var d = body.substring(q + 1), n = d.length, i = 0;
        var W = 0, H = 0;
        var m = /^"(\d+);(\d+);(\d+);(\d+)/.exec(d);
        if (m) { W = +m[3]; H = +m[4]; i = m[0].length; }
        if (!W || !H || W > 4096 || H > 4096) { return; }
        var img = new ImageData(W, H), px = new Uint32Array(img.data.buffer);
        var pal = [], cur = 0x000000FF, x = 0, band = 0;
        while (i < n) {
            var c = d.charCodeAt(i);
            if (c === 35) { // # colour
                var j = i + 1, num = 0;
                while (j < n && d.charCodeAt(j) >= 48 && d.charCodeAt(j) <= 57) { num = num * 10 + d.charCodeAt(j) - 48; j++; }
                if (d.charAt(j) === ";") {
                    var mm = /^;(\d+);(\d+);(\d+);(\d+)/.exec(d.substring(j, j + 24));
                    if (mm) {
                        var r = Math.round(+mm[2] * 2.55), g = Math.round(+mm[3] * 2.55), b = Math.round(+mm[4] * 2.55);
                        pal[num] = (255 << 24 | b << 16 | g << 8 | r) >>> 0; // little-endian RGBA
                        j += mm[0].length;
                    }
                }
                cur = pal[num] !== undefined ? pal[num] : 0xFF000000;
                i = j;
                continue;
            }
            if (c === 36) { x = 0; i++; continue; }          // $ back to the band's start
            if (c === 45) { x = 0; band++; i++; continue; }  // - next band
            var rep = 1;
            if (c === 33) {                                  // !count
                var k = i + 1; rep = 0;
                while (k < n && d.charCodeAt(k) >= 48 && d.charCodeAt(k) <= 57) { rep = rep * 10 + d.charCodeAt(k) - 48; k++; }
                i = k; c = d.charCodeAt(i);
            }
            if (c >= 63 && c <= 126) {
                var v = c - 63, y0 = band * 6;
                for (var bit = 0; bit < 6; bit++) {
                    if (!(v >> bit & 1)) { continue; }
                    var y = y0 + bit;
                    if (y >= H) { break; }
                    var row = y * W;
                    for (var t = 0; t < rep && x + t < W; t++) { px[row + x + t] = cur; }
                }
                x += rep;
            }
            i++;
        }
        if (!six.canvas) { six.canvas = document.createElement("canvas"); six.ctx = six.canvas.getContext("2d"); }
        if (six.canvas.width !== W || six.canvas.height !== H) { six.canvas.width = W; six.canvas.height = H; }
        six.ctx.putImageData(img, 0, 0);
        var fw = crt.Font.Width, fh = crt.Font.Height;
        var row0 = crt.WhereY() - 1 + (crt._UseModernScrollback ? crt._ScrollbackSize : 0);
        var ctx = crt._CanvasContext;
        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(six.canvas, 0, 0, W, H, (crt.WhereX() - 1) * fw, row0 * fh, W * fw / 8, H * fh / 16);
        info.sixels = (info.sixels || 0) + 1;
    }

    return {
        // start must be called from a click/tap (browsers only allow sound then).
        start: function () {
            var AC = window.AudioContext || window.webkitAudioContext;
            if (!AC) { return false; }
            if (!ctx) {
                ctx = new AC();
                master = ctx.createGain();
                master.connect(ctx.destination);
            }
            if (ctx.state === "suspended") { ctx.resume(); }
            return true;
        },
        attach: function (client) {
            var ansi = client._Ansi, write = ansi.Write;
            ansi.Write = function (text) {
                if (!send && client._Connection) {
                    send = function (s) { if (client._Connection.connected) { client._Connection.writeString(s); } };
                }
                crt = client._Crt;
                var t = filter(text, function (before) { write.call(ansi, before); });
                if (t.length > 0) { write.call(ansi, t); }
            };
        },
        setMuted: function (m) { if (master) { master.gain.value = m ? 0 : 1; } },
        reset: function () { files = {}; slots = {}; inAPC = false; apc = []; inDCS = false; dcs = []; pend = ""; send = null; },
        filter: filter,
        info: info
    };
}());
