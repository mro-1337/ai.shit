# Applies Telnetvision's changes to fTelnet's ftelnet.norip.noxfer.js.
# Usage: python3 patch-ftelnet.py <original.js> <out.js>
import sys
s = open(sys.argv[1], encoding='utf-8').read()

def rep(a, b, count=1):
    global s
    assert s.count(a) >= count, a[:80]
    s = s.replace(a, b, count)

# 1. 24-bit colours: accept 38;2;r;g;b followed by more parameters.
rep("if (this._AnsiParams.length === 3) {\n                                        this._Crt.TextColor24(",
    "if (this._AnsiParams.length >= 3) {\n                                        this._Crt.TextColor24(")
rep("if (this._AnsiParams.length === 3) {\n                                        this._Crt.TextBackground24(",
    "if (this._AnsiParams.length >= 3) {\n                                        this._Crt.TextBackground24(")

# 2. Fast drawing of block characters.
start = s.index("    Crt.prototype.FastWrite = function (text, x, y, charInfo, updateBuffer) {")
a = s.index("            var CharMap = this._Font.GetChars(charInfo);", start)
b = s.index("                if (updateBuffer) {", a)
s = s[:a] + '''            // Telnetvision: block characters (the video's "pixels") are
            // drawn as plain rectangles; recolouring the whole font for
            // each of thousands of 24-bit colour pairs was far too slow.
            var CharMap, CharMapTried = false;
            var FW = this._Font.Width, FH = this._Font.Height;
            for (var i = 0; i < TextLength; i++) {
                var Code = CharCodes[i];
                var DrawIt = this._UseModernScrollback || (!this._InScrollback) || (this._InScrollback && !updateBuffer);
                var DY = (y - 1 + (this._UseModernScrollback ? this._ScrollbackSize : 0)) * FH;
                var DX = (x - 1 + i) * FW;
                if (DrawIt && FW > 0 && !this._Transparent && (Code === 0xDF || Code === 0xDC || Code === 0xDB || Code === 32)) {
                    var Fg = charInfo.Fore24, Bg = charInfo.Back24;
                    if (charInfo.Reverse) { var Tmp = Fg; Fg = Bg; Bg = Tmp; }
                    var Ctx = this._CanvasContext, Half = Math.floor(FH / 2);
                    Ctx.fillStyle = Crt.CssColour(Code === 0xDB ? Fg : Bg);
                    Ctx.fillRect(DX, DY, FW, FH);
                    if (Code === 0xDF) { Ctx.fillStyle = Crt.CssColour(Fg); Ctx.fillRect(DX, DY, FW, Half); }
                    else if (Code === 0xDC) { Ctx.fillStyle = Crt.CssColour(Fg); Ctx.fillRect(DX, DY + Half, FW, FH - Half); }
                } else if (DrawIt) {
                    if (!CharMapTried) { CharMap = this._Font.GetChars(charInfo); CharMapTried = true; }
                    if (typeof CharMap === 'undefined') {
                        this._Buffer[y][x + i].NeedsRedraw = true;
                    } else {
                        this._CanvasContext.drawImage(CharMap, Code * FW, 0, FW, FH, DX, DY, FW, FH);
                    }
                }
''' + s[b:]
rep("    Crt.prototype.FastWrite = function (text, x, y, charInfo, updateBuffer) {",
    """    Crt._CssColours = {};
    Crt.CssColour = function (c) {
        var s = Crt._CssColours[c];
        if (!s) { s = Crt._CssColours[c] = '#' + (0x1000000 + (c & 0xFFFFFF)).toString(16).substring(1); }
        return s;
    };
    Crt.prototype.FastWrite = function (text, x, y, charInfo, updateBuffer) {""")

# 3. Cap the recoloured-font cache (one canvas per colour pair).
rep("""        if (!this._CharsMap[CharsMapKey]) {
            var NewChars = this._CanvasContext.getImageData(""",
    """        if (!this._CharsMap[CharsMapKey]) {
            this._CharsMapCount = (this._CharsMapCount || 0) + 1; // Telnetvision: keep at most 400
            if (this._CharsMapCount > 400) { this._CharsMap = {}; this._CharsMapCount = 1; }
            var NewChars = this._CanvasContext.getImageData(""")

# 4. CSI ?7l / ?7h (auto-wrap off / on). Without it, drawing the bottom-right
#    corner scrolled the whole screen up a line.
rep("""                    case '?7':
                        console.log('Unhandled ESC sequence: Enable auto wrap');""",
    """                    case '?7':
                        this._Crt._NoAutoWrap = false;""")
rep("""                    case '?7':
                        console.log('Unhandled ESC sequence: Disable auto wrap');""",
    """                    case '?7':
                        this._Crt._NoAutoWrap = true;""")
wa = s.index("    Crt.prototype.WriteASCII = function (text) {")
old = """                if ((X + Buf.length) > this.WindCols) {
                    this.FastWrite(Buf, this.WhereXA(), this.WhereYA(), this._CharInfo);
                    Buf = '';
                    X = 1;
                    Y += 1;
                    DoGoto = true;
                }"""
i = s.index(old, wa)
s = s[:i] + """                if ((X + Buf.length) > this.WindCols) {
                    this.FastWrite(Buf, this.WhereXA(), this.WhereYA(), this._CharInfo);
                    Buf = '';
                    if (this._NoAutoWrap) {
                        X = this.WindCols; // stay in the last column
                    } else {
                        X = 1;
                        Y += 1;
                    }
                    DoGoto = true;
                }""" + s[i + len(old):]
# The last column: with wrap off, a run ending exactly at the edge must not
# move the cursor past it either.
rep("""        if (Buf.length > 0) {
            this.FastWrite(Buf, this.WhereXA(), this.WhereYA(), this._CharInfo);
            X += Buf.length;
            this.GotoXY(X, Y);
        }
    };
    Crt.prototype.WriteATASCII""", """        if (Buf.length > 0) {
            this.FastWrite(Buf, this.WhereXA(), this.WhereYA(), this._CharInfo);
            X += Buf.length;
            if (this._NoAutoWrap && X > this.WindCols) { X = this.WindCols; }
            this.GotoXY(X, Y);
        }
    };
    Crt.prototype.WriteATASCII""")

# 5. Screen-reader text: keep only the newest 60 lines (it grew without
#    limit, thousands of page elements an hour with a live picture).
rep("""        if (newAriaText.trim() !== '') {
            var newDiv = document.createElement('div');
            newDiv.innerText = newAriaText;
            this._Canvas.appendChild(newDiv);
            newAriaText = '';
        }
    };""", """        if (newAriaText.trim() !== '') {
            var newDiv = document.createElement('div');
            newDiv.innerText = newAriaText;
            this._Canvas.appendChild(newDiv);
            newAriaText = '';
        }
        while (this._Canvas.childNodes.length > 60) { this._Canvas.removeChild(this._Canvas.firstChild); }
    };""")

# 6. Hidden cursor (CSI ?25l) really hides it; fTelnet kept blinking it.
rep("""            case BlinkState.Show:
                this.onshow.trigger();
                break;""", """            case BlinkState.Show:
                if (this._Visible) { this.onshow.trigger(); } else { this._BlinkState = BlinkState.Hide; this.onhide.trigger(); }
                break;""")

s = """/* fTelnet (https://github.com/rickparrish/fTelnet), AGPL-3.0: see LICENSE-fTelnet.txt.
 * Changed for Telnetvision by patch-ftelnet.py (in the web folder):
 *  - 24-bit colour codes setting text and background in one sequence work.
 *  - Block characters are drawn as rectangles and the recoloured-font
 *    cache is capped, so video plays at full speed.
 *  - Auto-wrap off/on (CSI ?7l / ?7h) is supported.
 *  - Screen-reader text is capped at 60 lines.
 *  - A hidden cursor stays hidden. */
""" + s
open(sys.argv[2], 'w', encoding='utf-8').write(s)
