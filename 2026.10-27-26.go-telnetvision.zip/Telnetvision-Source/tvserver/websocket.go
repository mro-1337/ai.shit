package main

// A minimal WebSocket server (RFC 6455), enough for the web viewer: the
// browser's fTelnet opens a WebSocket and the bytes inside are exactly a
// telnet connection's bytes. wsConn makes it look like a net.Conn so the
// telnet viewer code serves browsers unchanged.

import (
	"bufio"
	"crypto/sha1"
	"encoding/base64"
	"encoding/binary"
	"errors"
	"io"
	"net"
	"net/http"
	"strings"
	"sync"
	"time"
)

const wsGUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

type wsConn struct {
	net.Conn
	r       *bufio.Reader
	wmu     sync.Mutex
	pending []byte // payload of the current message not yet read
	closed  bool
	text    bool // client asked for "base64"/"plain" instead of "binary"
	b64     bool
}

// upgradeWebSocket answers the WebSocket handshake and takes over the
// connection. Returns nil (after writing an error) if it isn't one.
func upgradeWebSocket(w http.ResponseWriter, r *http.Request) *wsConn {
	if !strings.EqualFold(r.Header.Get("Upgrade"), "websocket") || r.Header.Get("Sec-WebSocket-Key") == "" {
		http.Error(w, "this address is for the web viewer's WebSocket", http.StatusBadRequest)
		return nil
	}
	proto := ""
	for _, p := range strings.Split(r.Header.Get("Sec-WebSocket-Protocol"), ",") {
		p = strings.TrimSpace(p)
		if p == "binary" {
			proto = "binary"
			break
		}
		if proto == "" && (p == "base64" || p == "plain") {
			proto = p
		}
	}
	hj, ok := w.(http.Hijacker)
	if !ok {
		http.Error(w, "no websocket support", http.StatusInternalServerError)
		return nil
	}
	conn, brw, err := hj.Hijack()
	if err != nil {
		return nil
	}
	h := sha1.Sum([]byte(r.Header.Get("Sec-WebSocket-Key") + wsGUID))
	resp := "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n" +
		"Sec-WebSocket-Accept: " + base64.StdEncoding.EncodeToString(h[:]) + "\r\n"
	if proto != "" {
		resp += "Sec-WebSocket-Protocol: " + proto + "\r\n"
	}
	resp += "\r\n"
	conn.SetDeadline(time.Time{})
	if _, err := conn.Write([]byte(resp)); err != nil {
		conn.Close()
		return nil
	}
	return &wsConn{Conn: conn, r: brw.Reader, text: proto == "base64" || proto == "plain", b64: proto == "base64"}
}

// SetWriteBuffer / SetNoDelay reach the TCP connection underneath, so the
// viewer's send-buffer sizing and pacing work for browsers too.
func (c *wsConn) SetWriteBuffer(n int) error {
	if tc, ok := c.Conn.(*net.TCPConn); ok {
		return tc.SetWriteBuffer(n)
	}
	return nil
}

func (c *wsConn) SetNoDelay(b bool) error {
	if tc, ok := c.Conn.(*net.TCPConn); ok {
		return tc.SetNoDelay(b)
	}
	return nil
}

func (c *wsConn) Read(p []byte) (int, error) {
	for {
		if len(c.pending) > 0 {
			n := copy(p, c.pending)
			c.pending = c.pending[n:]
			return n, nil
		}
		if c.closed {
			return 0, io.EOF
		}
		if err := c.nextFrame(); err != nil {
			return 0, err
		}
	}
}

// nextFrame reads one frame, answering pings and collecting data.
func (c *wsConn) nextFrame() error {
	var hdr [2]byte
	if _, err := io.ReadFull(c.r, hdr[:]); err != nil {
		return err
	}
	op := hdr[0] & 0x0F
	n := int64(hdr[1] & 0x7F)
	switch n {
	case 126:
		var b [2]byte
		if _, err := io.ReadFull(c.r, b[:]); err != nil {
			return err
		}
		n = int64(binary.BigEndian.Uint16(b[:]))
	case 127:
		var b [8]byte
		if _, err := io.ReadFull(c.r, b[:]); err != nil {
			return err
		}
		n = int64(binary.BigEndian.Uint64(b[:]))
	}
	if n > 1<<20 {
		return errors.New("websocket frame too big")
	}
	var mask [4]byte
	if hdr[1]&0x80 != 0 {
		if _, err := io.ReadFull(c.r, mask[:]); err != nil {
			return err
		}
	}
	data := make([]byte, n)
	if _, err := io.ReadFull(c.r, data); err != nil {
		return err
	}
	if hdr[1]&0x80 != 0 {
		for i := range data {
			data[i] ^= mask[i%4]
		}
	}
	switch op {
	case 0x8: // close
		c.writeFrame(0x8, data)
		c.closed = true
		return io.EOF
	case 0x9: // ping
		return c.writeFrame(0xA, data)
	case 0xA: // pong
		return nil
	}
	if c.b64 {
		dec, err := base64.StdEncoding.DecodeString(string(data))
		if err != nil {
			return err
		}
		data = dec
	}
	c.pending = data
	return nil
}

func (c *wsConn) writeFrame(op byte, p []byte) error {
	hdr := make([]byte, 0, 10+len(p))
	hdr = append(hdr, 0x80|op)
	switch n := len(p); {
	case n < 126:
		hdr = append(hdr, byte(n))
	case n < 65536:
		hdr = append(hdr, 126, byte(n>>8), byte(n))
	default:
		hdr = append(hdr, 127)
		hdr = binary.BigEndian.AppendUint64(hdr, uint64(n))
	}
	c.wmu.Lock()
	defer c.wmu.Unlock()
	_, err := c.Conn.Write(append(hdr, p...))
	return err
}

// Write sends p as one message (binary, or base64 text for old clients).
func (c *wsConn) Write(p []byte) (int, error) {
	var err error
	switch {
	case c.b64:
		err = c.writeFrame(0x1, []byte(base64.StdEncoding.EncodeToString(p)))
	case c.text: // "plain": one character per byte, as UTF-8 text
		err = c.writeFrame(0x1, []byte(string(latin1Runes(p))))
	default:
		err = c.writeFrame(0x2, p)
	}
	if err != nil {
		return 0, err
	}
	return len(p), nil
}

func latin1Runes(p []byte) []rune {
	r := make([]rune, len(p))
	for i, b := range p {
		r[i] = rune(b)
	}
	return r
}

func (c *wsConn) Close() error {
	c.writeFrame(0x8, []byte{0x03, 0xE8}) // 1000 normal closure
	return c.Conn.Close()
}
