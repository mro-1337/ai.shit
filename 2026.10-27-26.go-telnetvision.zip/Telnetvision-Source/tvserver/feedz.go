package main

// Compressed picture frames from telnetvision.exe (see its feedz.go):
//
//	WELCOME 0x20 (server -> producer, once after the hello): 0x20 | u8 caps
//	FRAME_Z 0x12: 0x12 | u8 flags | zlib(FRAME payload without its 0x10)
//	              flags bit 0: pixels XORed with the previous frame's

import (
	"bytes"
	"compress/zlib"
	"encoding/binary"
	"errors"
	"io"
)

const (
	msgFrameZ   = 0x12
	msgFrameHi  = 0x13 // sharper picture for sixel viewers: 0x13 | u16 w | u16 h | u64 pts | rgb
	msgFrameHiZ = 0x14 // the same, packed
	msgWantHi   = 0x21 // server -> producer: 0x21 | u8 on
	msgWelcome  = 0x20
	capZFrames  = 0x01
	capMessages = 0x02 // camera-window messages may come marked (msgMark)
)

type frameUnzipper struct {
	prev []byte // pixels of the last frame, after undoing the delta
}

// unzip turns a FRAME_Z payload back into a plain FRAME payload, or a
// FRAME_HI_Z back into FRAME_HI. Use one unzipper per kind.
func (u *frameUnzipper) unzip(p []byte) ([]byte, error) {
	if len(p) < 3 || (p[0] != msgFrameZ && p[0] != msgFrameHiZ) {
		return nil, errors.New("not a packed frame")
	}
	plainType := byte(msgFrame)
	if p[0] == msgFrameHiZ {
		plainType = msgFrameHi
	}
	zr, err := zlib.NewReader(bytes.NewReader(p[2:]))
	if err != nil {
		return nil, err
	}
	var out bytes.Buffer
	out.WriteByte(plainType)
	if _, err := io.Copy(&out, io.LimitReader(zr, maxMsg)); err != nil {
		return nil, err
	}
	f := out.Bytes()
	if len(f) < 13 {
		return nil, errors.New("short packed frame")
	}
	a := int(binary.BigEndian.Uint16(f[1:3]))
	b := int(binary.BigEndian.Uint16(f[3:5]))
	start, n := 9+int(binary.BigEndian.Uint16(f[7:9])), 2*a*b*3
	if plainType == msgFrameHi {
		start, n = 13, a*b*3
	}
	if start+n > len(f) {
		return nil, errors.New("packed frame too short for its size")
	}
	px := f[start : start+n]
	if p[1]&1 != 0 {
		if len(u.prev) != n {
			return nil, errors.New("packed frame delta without a previous frame")
		}
		for i := range px {
			px[i] ^= u.prev[i]
		}
	}
	u.prev = append(u.prev[:0], px...)
	return f, nil
}
