package main

import (
	"bufio"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestWebSocketEcho(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		c := upgradeWebSocket(w, r)
		if c == nil {
			return
		}
		defer c.Close()
		buf := make([]byte, 100)
		n, err := c.Read(buf)
		if err != nil {
			return
		}
		c.Write(append([]byte("got:"), buf[:n]...))
	}))
	defer srv.Close()
	conn, err := net.Dial("tcp", strings.TrimPrefix(srv.URL, "http://"))
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	conn.Write([]byte("GET /ws HTTP/1.1\r\nHost: x\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n" +
		"Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Protocol: binary, base64\r\n\r\n"))
	br := bufio.NewReader(conn)
	resp, err := http.ReadResponse(br, nil)
	if err != nil || resp.StatusCode != 101 || resp.Header.Get("Sec-WebSocket-Accept") != "s3pPLMBiTxaQ9kYGzzhZRbK+xOo=" || resp.Header.Get("Sec-WebSocket-Protocol") != "binary" {
		t.Fatalf("handshake: %v %+v", err, resp)
	}
	msg := []byte("hi\xff")
	mask := []byte{1, 2, 3, 4}
	frame := []byte{0x82, 0x80 | byte(len(msg))}
	frame = append(frame, mask...)
	for i, b := range msg {
		frame = append(frame, b^mask[i%4])
	}
	conn.Write(frame)
	hdr := make([]byte, 2)
	io.ReadFull(br, hdr)
	body := make([]byte, hdr[1]&0x7f)
	io.ReadFull(br, body)
	if hdr[0] != 0x82 || string(body) != "got:hi\xff" {
		t.Fatalf("reply %x %q", hdr, body)
	}
}
