package main

// Sound debugging: when a caller's sound doesn't come up (or always, with
// sound_debug = on), ask the terminal four questions that each go through
// a different part of SyncTERM, and log what came back:
//
//	ESC [ c                   Device Attributes  - the core terminal (CTerm version)
//	ESC [ = 7 n               audio state        - SyncTERM's sound system
//	APC SyncTERM:VER          version            - SyncTERM's APC command handler
//	APC SyncTERM:Q;libsndfile sound feature      - the same handler
//
// In SyncTERM the APC handler silently drops every SyncTERM: command when
// it can't create its cache folder for the connection (term.c apc_handler,
// get_cache_fn_base) - then the core and the sound system answer but the
// last two don't, and no sound command (C;S, A;Load, A;Queue) works either.

import (
	"bytes"
	"fmt"
	"regexp"
	"strings"
	"time"

	"github.com/hmderdoc/termprobe"
)

const soundDebugQueries = "\x1b[c" + "\x1b[=7n" + "\x1b_SyncTERM:VER\x1b\\" + "\x1b_SyncTERM:Q;libsndfile\x1b\\"

var (
	reDA     = regexp.MustCompile(`\x1b\[([=?>]?)([0-9;]*)c`)
	reAudio  = regexp.MustCompile(`\x1b\[=7((?:;[0-9]+)*)n`)
	reVer    = regexp.MustCompile(`\x1b_SyncTERM:VER;([^\x1b]*)\x1b\\`)
	reAnyAPC = regexp.MustCompile(`\x1b_[^\x1b]*\x1b\\`)
)

type soundDebugResult struct {
	da, daCTerm   string // raw DA params; CTerm version if it's CTerm
	audioState    string // "" = no answer
	audioAnswered bool
	ver           string
	verAnswered   bool
	sndfile       int // -1 no answer, 0/1
	raw           []byte
}

// soundDebugProbe asks the four questions and reads answers for up to
// timeout. It returns what it learned and the bytes that weren't answers
// (keys the caller typed), which go back to the key reader.
func soundDebugProbe(w interface{ Write([]byte) (int, error) }, r termprobe.TimedReader, timeout time.Duration) (soundDebugResult, []byte) {
	res := soundDebugResult{sndfile: -1}
	if _, err := w.Write([]byte(soundDebugQueries)); err != nil {
		return res, nil
	}
	var buf []byte
	scratch := make([]byte, 512)
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) && len(buf) < 8192 {
		rem := time.Until(deadline)
		if rem > 50*time.Millisecond {
			rem = 50 * time.Millisecond
		}
		n, err := r.ReadTimeout(scratch, rem)
		buf = append(buf, scratch[:n]...)
		if err != nil {
			break
		}
		// All four answered: no need to wait longer.
		if reDA.Match(buf) && reVer.Match(buf) && bytes.Contains(buf, []byte("\x1b[=7;100;")) && audioStateSeen(buf) {
			break
		}
	}
	res.raw = buf
	if m := reDA.FindSubmatch(buf); m != nil {
		res.da = string(m[1]) + string(m[2])
		if string(m[1]) == "=" && strings.HasPrefix(string(m[2]), "67;84;101;114;109;") {
			res.daCTerm = strings.ReplaceAll(strings.TrimPrefix(string(m[2]), "67;84;101;114;109;"), ";", ".")
		}
	}
	for _, m := range reAudio.FindAllSubmatch(buf, -1) {
		pairs := string(m[1])
		if strings.HasPrefix(pairs, ";100;") {
			fmt.Sscanf(strings.TrimPrefix(pairs, ";100;"), "%d", &res.sndfile)
			continue
		}
		res.audioAnswered = true
		res.audioState = "=7" + pairs
	}
	if m := reVer.FindSubmatch(buf); m != nil {
		res.verAnswered, res.ver = true, string(m[1])
	}
	// Hand back everything that isn't one of the answers.
	rest := reDA.ReplaceAll(buf, nil)
	rest = reAudio.ReplaceAll(rest, nil)
	rest = reAnyAPC.ReplaceAll(rest, nil)
	return res, rest
}

func audioStateSeen(buf []byte) bool {
	for _, m := range reAudio.FindAllSubmatch(buf, -1) {
		if !strings.HasPrefix(string(m[1]), ";100;") {
			return true
		}
	}
	return false
}

// verdict explains the answers in plain words.
func (r soundDebugResult) verdict() string {
	switch {
	case r.da == "" && !r.audioAnswered && !r.verAnswered:
		return "the terminal answered nothing at all (not SyncTERM, or the replies aren't reaching the server)"
	case !r.audioAnswered && !r.verAnswered:
		return "this terminal has no SyncTERM sound support (too old, or not SyncTERM)"
	case r.audioAnswered && !r.verAnswered:
		return "SyncTERM's sound system is there, but it is IGNORING all SyncTERM: commands. In SyncTERM that " +
			"happens when it can't create its cache folder for this connection: check the dialing-directory " +
			"entry's Name has none of  : \\ / * ? \" < > |  and that SyncTERM's cache folder can be written to"
	case r.verAnswered && r.sndfile == 0:
		return "SyncTERM takes commands but says it can't play sound clips (built without libsndfile?)"
	case r.verAnswered && r.sndfile == 1:
		return "SyncTERM takes commands and can play sound clips: the sound check should pass"
	case r.verAnswered:
		return "SyncTERM takes commands but didn't answer the sound-clip question"
	}
	return "unclear - see the raw answer"
}

func (r soundDebugResult) String() string {
	yn := func(ok bool, v string) string {
		if !ok {
			return "NO ANSWER"
		}
		return v
	}
	da := r.da
	if r.daCTerm != "" {
		da = "CTerm " + r.daCTerm
	}
	snd := "NO ANSWER"
	if r.sndfile >= 0 {
		snd = fmt.Sprint(r.sndfile)
	}
	raw := fmt.Sprintf("%q", r.raw)
	if len(raw) > 400 {
		raw = raw[:400] + "..."
	}
	return fmt.Sprintf("terminal %s | sound system %s | SyncTERM: commands %s | libsndfile %s | => %s | raw answer %s",
		yn(r.da != "", da), yn(r.audioAnswered, r.audioState), yn(r.verAnswered, "answered (version "+r.ver+")"),
		snd, r.verdict(), raw)
}
