package main

import (
	"bufio"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"math/big"
	"net"
	"time"
)

// selfSignedTLS makes an in-memory certificate so TLS feeds work with no
// setup. telnetvision.exe's INSECURE=1 (its default) accepts it.
func selfSignedTLS() (*tls.Config, error) {
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return nil, err
	}
	serial, _ := rand.Int(rand.Reader, big.NewInt(1<<62))
	tmpl := &x509.Certificate{
		SerialNumber: serial,
		Subject:      pkix.Name{CommonName: "tvserver"},
		NotBefore:    time.Now().Add(-time.Hour),
		NotAfter:     time.Now().AddDate(10, 0, 0),
		KeyUsage:     x509.KeyUsageDigitalSignature,
		ExtKeyUsage:  []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
	}
	der, err := x509.CreateCertificate(rand.Reader, tmpl, tmpl, &key.PublicKey, key)
	if err != nil {
		return nil, err
	}
	return &tls.Config{Certificates: []tls.Certificate{{Certificate: [][]byte{der}, PrivateKey: key}}}, nil
}

// peekConn replays bytes already read while sniffing.
type peekConn struct {
	net.Conn
	r *bufio.Reader
}

func (c *peekConn) Read(p []byte) (int, error) { return c.r.Read(p) }

// sniffTLS returns conn as-is for a plaintext feed, or wrapped in TLS when
// the first byte is a TLS handshake record (0x16). One port serves both.
func sniffTLS(conn net.Conn, cfg *tls.Config) (net.Conn, bool) {
	conn.SetReadDeadline(time.Now().Add(20 * time.Second))
	br := bufio.NewReader(conn)
	b, err := br.Peek(1)
	conn.SetReadDeadline(time.Time{})
	pc := &peekConn{Conn: conn, r: br}
	if err == nil && b[0] == 0x16 {
		return tls.Server(pc, cfg), true
	}
	return pc, false
}
