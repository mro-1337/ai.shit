package main

// The web viewer: people watch in their browser at http://server:web_port.
// The page runs fTelnet (an HTML5 telnet terminal) plus tvaudio.js for the
// sound; its WebSocket at /ws is served by the same code as telnet callers,
// so browsers get the same picture, sound, captions, title bar, settings
// menu and pacing.

import (
	"crypto/sha1"
	"embed"
	"encoding/hex"
	"html"
	"io/fs"
	"log"
	"net"
	"net/http"
	"strconv"
	"strings"
	"sync/atomic"
	"time"
)

//go:embed web
var webFiles embed.FS

func startWebServer(cfg serverConfig, h *hub, active *atomic.Int32) (net.Listener, error) {
	ln, err := net.Listen("tcp", net.JoinHostPort(cfg.Listen, strconv.Itoa(cfg.WebPort)))
	if err != nil {
		return nil, err
	}
	sub, _ := fs.Sub(webFiles, "web")
	files := http.FileServer(http.FS(sub))
	page, _ := fs.ReadFile(sub, "index.html")
	title := cfg.View.banner
	if title == "" {
		title = "Telnetvision"
	}
	page = []byte(strings.ReplaceAll(string(page), "{{TITLE}}", html.EscapeString(title)))
	// Each script's address carries a fingerprint of its contents, so after
	// an update browsers fetch the new one instead of an old cached copy.
	for _, name := range []string{"tvaudio.js", "ftelnet/ftelnet.js"} {
		if b, err := fs.ReadFile(sub, name); err == nil {
			sum := sha1.Sum(b)
			page = []byte(strings.ReplaceAll(string(page), name+"?v=tv1", name+"?v="+hex.EncodeToString(sum[:6])))
		}
	}

	view := cfg.View
	view.web = true
	mux := http.NewServeMux()
	mux.HandleFunc("/ws", func(w http.ResponseWriter, r *http.Request) {
		if int(active.Load()) >= cfg.MaxCallers {
			http.Error(w, "the channel is full right now", http.StatusServiceUnavailable)
			log.Printf("web viewer %s turned away: %d viewers is the limit", r.RemoteAddr, cfg.MaxCallers)
			return
		}
		c := upgradeWebSocket(w, r)
		if c == nil {
			return
		}
		active.Add(1)
		serveTelnet(c, h, view, active)
	})
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/" || r.URL.Path == "/index.html" {
			w.Header().Set("Content-Type", "text/html; charset=utf-8")
			w.Header().Set("Cache-Control", "no-cache")
			w.Write(page)
			return
		}
		if r.URL.RawQuery != "" {
			w.Header().Set("Cache-Control", "max-age=86400") // fingerprinted: safe to keep
		} else {
			w.Header().Set("Cache-Control", "no-cache") // fonts etc.: check for changes
		}
		files.ServeHTTP(w, r)
	})
	srv := &http.Server{Handler: mux, ReadHeaderTimeout: 10 * time.Second}
	go func() {
		if err := srv.Serve(ln); err != nil {
			log.Printf("web server stopped: %v", err)
		}
	}()
	return ln, nil
}
