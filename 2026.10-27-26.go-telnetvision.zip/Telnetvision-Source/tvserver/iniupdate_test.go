package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestServerTemplateIsNeutral(t *testing.T) {
	p := filepath.Join(t.TempDir(), "t.ini")
	os.WriteFile(p, []byte(serverINITemplate("x")), 0o600)
	got := defaultServerConfig()
	if err := got.apply(loadINI(p)); err != nil {
		t.Fatal(err)
	}
	want := defaultServerConfig()
	want.Token = "x"
	if got != want {
		t.Fatalf("template changes settings:\n%+v\n%+v", got, want)
	}
}

func TestCleanINI(t *testing.T) {
	messy := "# my notes\r\n" +
		"fps = 10\r\n" +
		"token = SECRET\r\n" +
		"color = 256\r\n" +
		"telnet_port = 23\r\n" +
		"banner = My TV  \r\n" +
		"fps = 12\r\n" + // the second one counts
		"#web_port = 9000\r\n" + // switched off on purpose
		"colour = 16\r\n" + // typo: unknown, kept
		"   audio=off\r\n"
	out, added, moved, changed := cleanINI([]byte(messy), serverINITemplate(""), nil, map[string]bool{"token": true}, "tvserver")
	if !changed || moved == 0 || len(added) == 0 {
		t.Fatalf("changed=%v moved=%d added=%v", changed, moved, added)
	}
	cfg := defaultServerConfig()
	p := filepath.Join(t.TempDir(), "t.ini")
	os.WriteFile(p, out, 0o600)
	if _, err := cfg.applyWarn(loadINI(p)); err != nil {
		t.Fatal(err)
	}
	if cfg.Token != "SECRET" || cfg.TelnetPort != 23 || cfg.View.fps != 12 || cfg.View.color != "256" ||
		cfg.View.banner != "My TV" || cfg.View.audio.Mode != "off" || cfg.WebPort != 8080 {
		t.Fatalf("values not kept: %+v", cfg)
	}
	s := string(out)
	for _, want := range []string{"# web_port = 9000", "colour = 16", "# Port people telnet to"} {
		if !strings.Contains(s, want) {
			t.Errorf("missing %q in:\n%s", want, s)
		}
	}
	if strings.Contains(s, "my notes") || strings.Count(s, "\nfps = ") != 1 {
		t.Errorf("old comments or duplicates left:\n%s", s)
	}
	if strings.Index(s, "telnet_port = 23") > strings.Index(s, "token = SECRET") {
		t.Errorf("not in template order:\n%s", s)
	}
	// A clean file stays exactly as it is.
	if _, _, _, again := cleanINI(out, serverINITemplate(""), nil, map[string]bool{"token": true}, "tvserver"); again {
		t.Error("cleaning a clean file changed it")
	}
}
