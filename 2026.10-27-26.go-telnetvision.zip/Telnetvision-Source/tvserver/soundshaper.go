package main

import (
	"encoding/binary"
	"fmt"
	"math"
	"strings"
)

// Per-viewer sound quality: what each caller's sound is turned into before
// it goes down their connection. The camera PC sends one stream; each
// viewer can ask for less (lower rate, mono, more compression) to save
// bandwidth, and the server converts it for just that viewer.

const (
	qualityBest = "best" // as the camera PC sends it
	qualityGood = "good" // at most 22 kHz mono
	qualityLow  = "low"  // at most 11 kHz mono
	qualityOff  = "off"  // no sound
	sound8bit   = "pcm8" // 8-bit PCM for the 3DS terminal
)

const soundAutoCodec = "auto" // adpcm for SyncTERM, mu-law for other terminals

// codecFor picks the compression for a terminal when it's set to auto.
// SyncTERM plays everything through libsndfile; other terminals that copy
// SyncTERM's sound commands (IcyTerm, ...) may only play PCM and mu-law.
//
// adpcm (the old default) is treated the same way: a server-wide setting
// should never pick a format a viewer's terminal can't play. A viewer can
// still choose ADPCM for themselves in the S menu.
func codecFor(setting, terminal string) string {
	if setting != soundAutoCodec && setting != soundADPCM {
		return setting
	}
	t := strings.ToLower(terminal)
	if strings.Contains(t, "syncterm") || strings.Contains(t, "web browser") { // the web page decodes ADPCM itself
		return soundADPCM
	}
	return soundULaw
}

// serverSoundCodec reads sound_compression: auto, or a fixed codec.
func serverSoundCodec(v string) (string, bool) {
	if squash(v) == "auto" || squash(v) == "" {
		return soundAutoCodec, true
	}
	return normalizeSoundCodec(v)
}

var qualityOrder = []string{qualityBest, qualityGood, qualityLow, qualityOff}
var codecOrder = []string{soundADPCM, soundULaw, soundPCM}

func normalizeQuality(v string) (string, bool) {
	switch squash(v) {
	case "best", "high", "full", "source", "":
		return qualityBest, true
	case "good", "medium", "normal", "22k", "22050":
		return qualityGood, true
	case "low", "phone", "11k", "11025", "8k":
		return qualityLow, true
	case "off", "none", "no", "mute", "0":
		return qualityOff, true
	}
	return qualityBest, false
}

func qualityCaps(q string) (maxRate, maxCh int) {
	switch q {
	case qualityGood:
		return 22050, 1
	case qualityLow:
		return 11025, 1
	}
	return 0, 0
}

func qualityLabel(q string) string {
	switch q {
	case qualityGood:
		return "Good (22 kHz mono)"
	case qualityLow:
		return "Low (11 kHz mono)"
	case qualityOff:
		return "Off"
	}
	return "Best (as broadcast)"
}

func codecLabel(c string) string {
	switch c {
	case soundULaw:
		return "mu-law (1/2 size)"
	case soundPCM:
		return "None (full size)"
	case sound8bit:
		return "8-bit"
	}
	return "ADPCM (1/4 size)"
}

// shapedClip is one sound clip ready for the terminal.
type shapedClip struct {
	file   []byte
	codec  byte // wire codec: codecWAV or codecFLAC (decides the file name)
	durMs  int64
	ptsEnd int64 // producer-clock time at the clip's end
}

// soundShaper converts the incoming stream for one viewer. It carries
// leftover samples from chunk to chunk, so lowering the rate or packing
// ADPCM blocks never drops or pads a sample: clips still join seamlessly.
type soundShaper struct {
	codec           string // adpcm | ulaw | pcm | pcm8
	maxRate, maxCh  int    // 0 = no limit
	inRate, inCh    int
	outRate, outCh  int
	rsCarry         []byte // input samples waiting for a whole resample group
	encCarry        []byte // output samples waiting for a whole ADPCM block
	passThroughSeen bool
	usCarry         int64   // leftover microseconds, so clip lengths add up exactly
	gain            float64 // >1: the viewer turned the volume above full
}

func (t *soundShaper) set(codec, quality string) {
	t.codec = codec
	t.maxRate, t.maxCh = qualityCaps(quality)
	t.rsCarry, t.encCarry = nil, nil
	t.inRate, t.inCh = 0, 0
}

// formatName describes the sound this viewer is getting, for the log.
func (t *soundShaper) formatName() string {
	if t.outRate == 0 {
		return codecLabel(t.codec)
	}
	ch := "mono"
	if t.outCh == 2 {
		ch = "stereo"
	}
	return fmt.Sprintf("%s %d Hz %s", t.codec, t.outRate, ch)
}

func wavInfo(b []byte) (tag, rate, ch int, ok bool) {
	if len(b) < 36 || string(b[:4]) != "RIFF" || string(b[8:16]) != "WAVEfmt " {
		return 0, 0, 0, false
	}
	le := binary.LittleEndian
	return int(le.Uint16(b[20:])), int(le.Uint32(b[24:])), int(le.Uint16(b[22:])), true
}

func codecTag(codec string) int {
	switch codec {
	case soundADPCM:
		return wavFmtIMA
	case soundULaw:
		return wavFmtULaw
	}
	return wavFmtPCM
}

func resampleFactor(rate, maxRate int) int {
	if maxRate <= 0 || rate <= maxRate {
		return 1
	}
	f := (rate + maxRate/2) / maxRate
	if f < 1 {
		f = 1
	}
	if f > 8 {
		f = 8
	}
	return f
}

// shape turns one incoming chunk into zero or more clips for this viewer.
func (t *soundShaper) shape(m audioMsg) []shapedClip {
	rate, ch := int(m.SampleRate), int(m.Channels)
	dur := int64(m.DurMs)
	end := int64(m.PtsMs) + dur
	if m.Codec == codecFLAC {
		return []shapedClip{{file: m.Payload, codec: codecFLAC, durMs: dur, ptsEnd: end}}
	}
	if m.Codec == codecWAV && len(t.rsCarry) == 0 && len(t.encCarry) == 0 && t.gain <= 1 {
		// Already in the viewer's format? Send it untouched.
		if tag, r, c, ok := wavInfo(m.Payload); ok && t.codec != sound8bit && tag == codecTag(t.codec) &&
			resampleFactor(r, t.maxRate) == 1 && (t.maxCh == 0 || c <= t.maxCh) {
			t.outRate, t.outCh, t.inRate, t.inCh = r, c, r, c
			return []shapedClip{{file: m.Payload, codec: codecWAV, durMs: dur, ptsEnd: end}}
		}
	}
	var pcm []byte
	if m.Codec == codecWAV {
		var err error
		if pcm, rate, ch, err = decodeWAV(m.Payload); err != nil {
			return nil
		}
	} else {
		pcm = m.Payload
	}
	if rate <= 0 || ch < 1 || ch > 2 {
		return nil
	}
	if rate != t.inRate || ch != t.inCh { // format changed: start fresh
		t.rsCarry, t.encCarry = nil, nil
		t.inRate, t.inCh = rate, ch
	}
	// Resample in whole groups; keep the remainder for the next chunk.
	f := resampleFactor(rate, t.maxRate)
	in := append(t.rsCarry, pcm...)
	frame := 2 * ch
	usable := len(in) / frame / f * f * frame
	t.rsCarry = append([]byte(nil), in[usable:]...)
	out, outRate, outCh := downmixResample(in[:usable], rate, ch, rate/f, t.maxCh)
	if f == 1 && (t.maxCh == 0 || ch <= t.maxCh) {
		out, outRate, outCh = in[:usable], rate, ch
	}
	t.outRate, t.outCh = outRate, outCh
	if t.gain > 1 {
		out = boost(out, t.gain)
	}
	buf := append(t.encCarry, out...)
	ofr := 2 * outCh
	n := len(buf) / ofr
	use := n
	if t.codec == soundADPCM {
		use = imaUsable(n, outCh)
	}
	t.encCarry = append([]byte(nil), buf[use*ofr:]...)
	if use == 0 {
		return nil
	}
	clip := buf[:use*ofr]
	held := int64(len(t.encCarry)/ofr)*1000/int64(outRate) + int64(len(t.rsCarry)/frame)*1000/int64(rate)
	// Whole milliseconds per clip, carrying the remainder: rounding every
	// clip down would make the sound clock drift a little more each clip.
	us := int64(use)*1000000/int64(outRate) + t.usCarry
	durMs := us / 1000
	t.usCarry = us % 1000
	return []shapedClip{{file: t.encode(clip, outRate, outCh), codec: codecWAV,
		durMs: durMs, ptsEnd: end - held}}
}

// setGain sets the boost for volumes above 0 dB.
func (t *soundShaper) setGain(db int) {
	t.gain = 1
	if db > 0 {
		t.gain = math.Pow(10, float64(db)/20)
	}
}

// boost makes 16-bit PCM louder. Loud peaks are rounded off smoothly
// instead of clipped hard, so a big boost distorts gently.
func boost(pcm []byte, gain float64) []byte {
	out := make([]byte, len(pcm))
	for i := 0; i+1 < len(pcm); i += 2 {
		x := float64(int16(binary.LittleEndian.Uint16(pcm[i:]))) / 32768 * gain
		if x > 0.7 || x < -0.7 { // soft knee above about -3 dB
			sign := 1.0
			if x < 0 {
				sign, x = -1, -x
			}
			x = sign * (0.7 + 0.3*math.Tanh((x-0.7)/0.3))
		}
		binary.LittleEndian.PutUint16(out[i:], uint16(int16(x*32767)))
	}
	return out
}

func (t *soundShaper) encode(pcm []byte, rate, ch int) []byte {
	if t.codec == sound8bit {
		return encodeWAV8(pcm, rate, ch)
	}
	return encodeSoundClip(t.codec, pcm, rate, ch)
}

// silence makes a silent clip of about ms milliseconds in the viewer's format.
func (t *soundShaper) silence(ms int64, rate, ch int) []byte {
	if t.outRate > 0 {
		rate, ch = t.outRate, t.outCh
	}
	n := int(int64(rate) * ms / 1000)
	if t.codec == soundADPCM {
		n = imaChunkSamples(n, ch)
	}
	return t.encode(make([]byte, n*ch*2), rate, ch)
}

// imaUsable is the most of n samples (per channel) that pack into whole,
// equal ADPCM blocks of a sensible size; the rest waits for the next chunk.
func imaUsable(n, ch int) int {
	if b, spb := imaBlockPlan(n, ch); b > 0 && spb >= 101 {
		return n
	}
	step := 2
	if ch == 2 {
		step = 8
	}
	best, bestSpb := 0, 0
	for spb := 1 + step*((101+step-1)/step); spb <= maxIMABlock; spb += step {
		if spb > n {
			break
		}
		if u := n / spb * spb; u > best || (u == best && spb > bestSpb) {
			best, bestSpb = u, spb
		}
	}
	return best
}
