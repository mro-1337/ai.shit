package main

// Each viewer's own settings (the S menu) are remembered per address and
// terminal program, in viewers.json next to tvserver.ini, so someone who
// had to pick mu-law sound for their terminal gets it again next time.

import (
	"encoding/json"
	"net"
	"os"
	"path/filepath"
	"sync"
)

type savedSettings struct {
	Color   string  `json:"color"`
	FPS     float64 `json:"fps"`
	Quality string  `json:"sound_quality"`
	Codec   string  `json:"sound_compression"`
	LipSync bool    `json:"lip_sync"`
	Volume  int     `json:"volume_db"`
	Detail  string  `json:"sixel_detail,omitempty"`
}

type viewerStore struct {
	mu   sync.Mutex
	path string
	m    map[string]savedSettings
}

var viewerPrefs = &viewerStore{m: map[string]savedSettings{}}

func (vs *viewerStore) load(dir string) {
	vs.mu.Lock()
	defer vs.mu.Unlock()
	vs.path = filepath.Join(dir, "viewers.json")
	if b, err := os.ReadFile(vs.path); err == nil {
		json.Unmarshal(b, &vs.m)
	}
}

func viewerKey(addr, terminal string) string {
	host, _, err := net.SplitHostPort(addr)
	if err != nil {
		host = addr
	}
	return host + " " + terminal
}

func (vs *viewerStore) get(key string) (savedSettings, bool) {
	vs.mu.Lock()
	defer vs.mu.Unlock()
	s, ok := vs.m[key]
	return s, ok
}

func (vs *viewerStore) put(key string, s savedSettings) {
	vs.mu.Lock()
	defer vs.mu.Unlock()
	vs.m[key] = s
	if vs.path == "" {
		return
	}
	if b, err := json.MarshalIndent(vs.m, "", "  "); err == nil {
		tmp := vs.path + ".new"
		if os.WriteFile(tmp, b, 0o600) == nil {
			os.Rename(tmp, vs.path)
		}
	}
}
