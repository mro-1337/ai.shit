package main

import (
	"testing"
	"time"
)

func TestColorSpellings(t *testing.T) {
	for in, want := range map[string]string{
		"16": "16", `"16"`: "16", "16   # for slow links": "16", "16 colors": "16", "16-color": "16",
		"16 Colours": "16", "CGA": "16", "ANSI": "16", "16 ; old terminals": "16",
		"truecolor": "truecolor", "24-bit": "truecolor", "True Color": "truecolor",
		"auto": "auto", "": "auto",
	} {
		c := defaultServerConfig()
		w, err := c.applyWarn(map[string]string{"color": in})
		if err != nil || c.View.color != want || len(w) != 0 {
			t.Errorf("color = %q: got %q warnings %v err %v", in, c.View.color, w, err)
		}
	}
	c := defaultServerConfig()
	if w, _ := c.applyWarn(map[string]string{"color": "purple", "fps": "fast", "stats": "maybe"}); len(w) != 3 || c.View.color != "auto" || c.View.fps != 15 {
		t.Errorf("bad values should warn and keep defaults: %v %+v", w, c.View)
	}
	c = defaultServerConfig()
	c.applyWarn(map[string]string{"banner": "Mike's TV #1", "fps": "10  # slow links", "telnet_port": "23 # standard"})
	if c.View.banner != "Mike's TV #1" || c.View.fps != 10 || c.TelnetPort != 23 {
		t.Errorf("inline notes: %+v %d", c.View, c.TelnetPort)
	}
}

func TestSendBufferSize(t *testing.T) {
	for _, c := range []struct {
		rtt   time.Duration
		sound bool
		want  int
	}{
		{0, false, 64 << 10}, {0, true, 32 << 10}, {2 * time.Millisecond, false, 64 << 10},
		{60 * time.Millisecond, true, 150000}, {150 * time.Millisecond, false, 375000}, {2 * time.Second, false, 1 << 20},
	} {
		if got := sendBufferSize(c.rtt, c.sound); got != c.want {
			t.Errorf("rtt %v sound %v: got %d want %d", c.rtt, c.sound, got, c.want)
		}
	}
}

func TestTitleBar(t *testing.T) {
	if b := titleBar("The Matrix 1999", "Mike's BBS TV", 40); len([]rune(b)) != 40 || b[:16] != " The Matrix 1999" || b[len(b)-14:] != "Mike's BBS TV " {
		t.Fatalf("%q", b)
	}
	long := titleBar("A Very Long Movie Title That Goes On And On Forever", "", 30)
	if len([]rune(long)) != 30 || long[27:] != "..." {
		t.Fatalf("%q", long)
	}
	px := append(make([]byte, 12+8), 'T', 'I', 0, 3, 'A', 'b', 'c')
	if frameTitle(px, 12) != "Abc" || frameTitle(px[:20], 12) != "" {
		t.Fatal("frameTitle")
	}
}
