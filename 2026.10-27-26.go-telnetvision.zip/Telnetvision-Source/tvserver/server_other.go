//go:build !windows

package main

func setServerTitle(string)     {}
func serverDoubleClicked() bool { return false }
