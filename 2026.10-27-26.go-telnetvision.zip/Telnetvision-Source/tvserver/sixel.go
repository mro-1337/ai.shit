package main

// Sixel: real pixel graphics in terminals that support them (SyncTERM,
// IcyTerm, xterm -ti vt340, mlterm, WezTerm, foot, ...). Each picture is
// sent as one sixel image with its own palette of up to sixelColors
// colours, picked from the picture by popularity (4 bits per colour
// channel), each pixel drawn in its nearest palette colour.

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"sort"
	"strconv"
)

// sixelImage encodes an RGB picture (w x h) as a sixel string, scaled up
// by whole factors sx, sy. maxColors is at most 256.
func sixelImage(buf *bytes.Buffer, px []byte, w, h, sx, sy, maxColors int) {
	if sx < 1 {
		sx = 1
	}
	if sy < 1 {
		sy = 1
	}
	// Palette: the most common colours, 4 bits per channel.
	var count [4096]int32
	var sumR, sumG, sumB [4096]int32
	idx := make([]uint16, w*h)
	for i := 0; i < w*h; i++ {
		r, g, b := px[i*3], px[i*3+1], px[i*3+2]
		k := uint16(r>>4)<<8 | uint16(g>>4)<<4 | uint16(b>>4)
		idx[i] = k
		count[k]++
		sumR[k] += int32(r)
		sumG[k] += int32(g)
		sumB[k] += int32(b)
	}
	pal := medianCut(count[:], sumR[:], sumG[:], sumB[:], maxColors)
	// Every present bin -> nearest palette entry.
	var mapTo [4096]int16
	for k, n := range count {
		if n == 0 {
			continue
		}
		r, g, b := sumR[k]/n, sumG[k]/n, sumB[k]/n
		best, bd := 0, int32(1<<30)
		for i, p := range pal {
			dr, dg, db := r-p[0], g-p[1], b-p[2]
			if d := 2*dr*dr + 4*dg*dg + db*db; d < bd {
				best, bd = i, d
			}
		}
		mapTo[k] = int16(best)
	}
	ci := make([]uint8, w*h)
	for i, k := range idx {
		ci[i] = uint8(mapTo[k])
	}

	W, H := w*sx, h*sy
	buf.WriteString("\x1bP0;1;0q\"1;1;")
	buf.WriteString(strconv.Itoa(W))
	buf.WriteByte(';')
	buf.WriteString(strconv.Itoa(H))
	for i, p := range pal {
		buf.WriteByte('#')
		buf.WriteString(strconv.Itoa(i))
		buf.WriteString(";2;")
		buf.WriteString(strconv.Itoa(int(p[0]) * 100 / 255))
		buf.WriteByte(';')
		buf.WriteString(strconv.Itoa(int(p[1]) * 100 / 255))
		buf.WriteByte(';')
		buf.WriteString(strconv.Itoa(int(p[2]) * 100 / 255))
	}
	used := make([]bool, len(pal))
	masks := make([]byte, w*len(pal)) // per source column, per colour: which of the 6 rows
	for band := 0; band*6 < H; band++ {
		for i := range masks {
			masks[i] = 0
		}
		for i := range used {
			used[i] = false
		}
		for r := 0; r < 6; r++ {
			y := band*6 + r
			if y >= H {
				break
			}
			row := (y / sy) * w
			for x := 0; x < w; x++ {
				c := ci[row+x]
				masks[int(c)*w+x] |= 1 << r
				used[c] = true
			}
		}
		first := true
		for c := range pal {
			if !used[c] {
				continue
			}
			if !first {
				buf.WriteByte('$') // back to the start of this band
			}
			first = false
			buf.WriteByte('#')
			buf.WriteString(strconv.Itoa(c))
			m := masks[c*w : c*w+w]
			// Run-length encode, skipping the trailing empty part.
			end := w
			for end > 0 && m[end-1] == 0 {
				end--
			}
			for x := 0; x < end; {
				v := m[x]
				n := 1
				for x+n < end && m[x+n] == v {
					n++
				}
				x += n
				n *= sx
				ch := byte(63 + v)
				if n > 3 {
					buf.WriteByte('!')
					buf.WriteString(strconv.Itoa(n))
					buf.WriteByte(ch)
				} else {
					for ; n > 0; n-- {
						buf.WriteByte(ch)
					}
				}
			}
		}
		buf.WriteByte('-') // next band
	}
	buf.WriteString("\x1b\\")
}

// medianCut picks up to n colours from the 4096-bin histogram: start with
// one box holding every colour, keep splitting the box with the widest
// spread (weighted by how many pixels it holds) at its median, and use
// each box's average colour. Small but distinct colours get a box too.
func medianCut(count, sumR, sumG, sumB []int32, n int) [][3]int32 {
	var all []sixEntry
	for k, cnt := range count {
		if cnt > 0 {
			all = append(all, sixEntry{[3]int32{sumR[k] / cnt, sumG[k] / cnt, sumB[k] / cnt}, cnt})
		}
	}
	type box struct{ lo, hi int } // range in all
	boxes := []box{{0, len(all)}}
	spread := func(b box) (axis int, score int64) {
		var mn, mx [3]int32
		mn = [3]int32{255, 255, 255}
		var wsum int64
		for _, e := range all[b.lo:b.hi] {
			for a := 0; a < 3; a++ {
				mn[a] = min(mn[a], e.c[a])
				mx[a] = max(mx[a], e.c[a])
			}
			wsum += int64(e.w)
		}
		best := int32(-1)
		for a := 0; a < 3; a++ {
			if r := mx[a] - mn[a]; r > best {
				best, axis = r, a
			}
		}
		// sqrt-ish weighting: big areas get more colours, small ones still some
		w := int64(1)
		for w*w < wsum {
			w++
		}
		return axis, int64(best) * w
	}
	for len(boxes) < n {
		bi, bAxis, bScore := -1, 0, int64(0)
		for i, b := range boxes {
			if b.hi-b.lo < 2 {
				continue
			}
			if a, sc := spread(b); sc > bScore {
				bi, bAxis, bScore = i, a, sc
			}
		}
		if bi < 0 {
			break
		}
		b := boxes[bi]
		part := all[b.lo:b.hi]
		sort.Slice(part, func(i, j int) bool { return part[i].c[bAxis] < part[j].c[bAxis] })
		// Split at the weighted median.
		var total, acc int64
		for _, e := range part {
			total += int64(e.w)
		}
		mid := 1
		for i, e := range part {
			acc += int64(e.w)
			if acc*2 >= total {
				mid = i + 1
				break
			}
		}
		if mid >= len(part) {
			mid = len(part) - 1
		}
		boxes[bi] = box{b.lo, b.lo + mid}
		boxes = append(boxes, box{b.lo + mid, b.hi})
	}
	pal := make([][3]int32, 0, len(boxes))
	for _, b := range boxes {
		var r, g, bl, w int64
		for _, e := range all[b.lo:b.hi] {
			r += int64(e.c[0]) * int64(e.w)
			g += int64(e.c[1]) * int64(e.w)
			bl += int64(e.c[2]) * int64(e.w)
			w += int64(e.w)
		}
		if w > 0 {
			pal = append(pal, [3]int32{int32(r / w), int32(g / w), int32(bl / w)})
		}
	}
	return pal
}

type sixEntry struct {
	c [3]int32 // average colour of a histogram bin
	w int32    // pixels in it
}

// Sixel detail levels: how sharp the picture is and how many colours it
// has. Each step down is roughly a third less data.
const (
	sixelHigh   = "high"   // the camera PC's sharp copy (160 wide), sixel_colors colours
	sixelMedium = "medium" // three quarters as sharp (120 wide), half the colours
	sixelLow    = "low"    // the normal picture (80 wide), a quarter of the colours
)

var sixelDetails = []string{sixelHigh, sixelMedium, sixelLow}

func sixelDetailLabel(d string) string {
	switch d {
	case sixelMedium:
		return "Medium (less data)"
	case sixelLow:
		return "Low (least data)"
	}
	return "High (sharpest)"
}

func normalizeSixelDetail(v string) (string, bool) {
	switch squash(v) {
	case "high", "best", "full":
		return sixelHigh, true
	case "medium", "med", "normal", "":
		return sixelMedium, true
	case "low", "small":
		return sixelLow, true
	}
	return sixelMedium, false
}

// shrink averages an RGB picture down to dw x dh.
func shrink(src []byte, sw, sh, dw, dh int) []byte {
	dst := make([]byte, dw*dh*3)
	for dy := 0; dy < dh; dy++ {
		y0, y1 := dy*sh/dh, max((dy+1)*sh/dh, dy*sh/dh+1)
		for dx := 0; dx < dw; dx++ {
			x0, x1 := dx*sw/dw, max((dx+1)*sw/dw, dx*sw/dw+1)
			var r, g, b, n int
			for y := y0; y < y1 && y < sh; y++ {
				for x := x0; x < x1 && x < sw; x++ {
					i := (y*sw + x) * 3
					r, g, b, n = r+int(src[i]), g+int(src[i+1]), b+int(src[i+2]), n+1
				}
			}
			o := (dy*dw + dx) * 3
			dst[o], dst[o+1], dst[o+2] = byte(r/n), byte(g/n), byte(b/n)
		}
	}
	return dst
}

// renderSixel draws the picture as a sixel image in the region the text
// picture would use (fitCols x fitRows cells at ox, oy). It uses the
// sharper FRAME_HI copy when there is a fresh one, else the normal frame
// (each of its half-block pixels becomes a square block).
func renderSixel(buf *bytes.Buffer, px []byte, srcCols, srcRows int, hi []byte, framePTS int64,
	fitCols, fitRows, ox, oy, cellW, cellH, colors int, detail string) {
	w, h, pix := srcCols, 2*srcRows, px[:2*srcRows*srcCols*3]
	switch detail {
	case sixelLow:
		hi, colors = nil, max(4, colors/4)
	case sixelMedium:
		colors = max(4, colors/2)
	}
	if len(hi) >= 13 && hi[0] == msgFrameHi {
		hw := int(binary.BigEndian.Uint16(hi[1:3]))
		hh := int(binary.BigEndian.Uint16(hi[3:5]))
		hpts := int64(binary.BigEndian.Uint64(hi[5:13]))
		d := hpts - framePTS
		if len(hi) >= 13+hw*hh*3 && hw > 0 && hh > 0 && (framePTS < 0 || (d > -1500 && d < 1500)) {
			w, h, pix = hw, hh, hi[13:13+hw*hh*3]
			if detail == sixelMedium && hw >= 8 {
				nw, nh := hw*3/4, hh*3/4
				pix, w, h = shrink(pix, hw, hh, nw, nh), nw, nh
			}
		}
	}
	tw, th := fitCols*cellW, fitRows*cellH
	s := min(tw/w, th/h)
	if s < 1 {
		// Too big for the space: fall back to the normal picture.
		w, h, pix = srcCols, 2*srcRows, px[:2*srcRows*srcCols*3]
		s = max(1, min(tw/w, th/h))
	}
	// Centre it in the region, to the nearest cell.
	col := ox + 1 + (tw-w*s)/2/cellW
	row := oy + 1 + (th-h*s)/2/cellH
	fmt.Fprintf(buf, "\x1b[%d;%dH", row, col)
	sixelImage(buf, pix, w, h, s, s, colors)
}
