package main

import (
	"io"
	"time"

	"github.com/hmderdoc/termprobe"
)

// Why a caller got no sound, for the server log.
const (
	soundOffSetting  = "audio = off in tvserver.ini"
	soundUnsupported = "the terminal answered that it can't play sound clips (SyncTERM without libsndfile, or older than 1.10a)"
	soundNoAnswer    = "no answer to the sound check (not SyncTERM 1.10a+, or a slow link - will ask again)"
)

// detectTimed is the door's audio feature probe (detect) over any writer
// and timed reader, so it works on a telnet socket on every OS. It returns
// every byte it read, which the caller hands back to its key parser, and
// when sound is off, the reason.
func (s *audioSession) detectTimed(w io.Writer, r termprobe.TimedReader, timeout time.Duration) ([]byte, string) {
	switch s.cfg.Mode {
	case "off":
		s.enabled = false
		return nil, soundOffSetting
	case "on":
		s.enabled = true
		return nil, ""
	}
	if _, err := w.Write([]byte(featureProbe + query3DS)); err != nil {
		s.enabled = false
		return nil, soundNoAnswer
	}
	deadline := time.Now().Add(timeout)
	var buf []byte
	scratch := make([]byte, 256)
	gotFeature, feature := false, false
	var graceEnd time.Time
	for time.Now().Before(deadline) && len(buf) < 4096 {
		rem := time.Until(deadline)
		if rem > 50*time.Millisecond {
			rem = 50 * time.Millisecond
		}
		n, err := r.ReadTimeout(scratch, rem)
		if n > 0 {
			buf = append(buf, scratch[:n]...)
			if !gotFeature {
				if avail, found := parseFeatureReply(buf, audioFeatureID); found {
					gotFeature, feature = true, avail
					graceEnd = time.Now().Add(query3DSGrace)
				}
			}
			if parse3DSVer(buf) {
				s.enabled = !gotFeature || feature // 3dBBS supports libsndfile by contract
				s.is3DBBS = true
				if !s.enabled {
					return buf, soundUnsupported
				}
				return buf, ""
			}
		} else if err != nil {
			break
		}
		if gotFeature && time.Now().After(graceEnd) {
			break
		}
	}
	s.enabled = gotFeature && feature
	switch {
	case s.enabled:
		return buf, ""
	case gotFeature:
		return buf, soundUnsupported
	}
	return buf, soundNoAnswer
}
