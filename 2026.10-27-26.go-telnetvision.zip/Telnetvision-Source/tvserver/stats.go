package main

// Viewer statistics: what each caller is actually getting, and where the
// bottleneck is. Off by default; switch on with  stats = on  in
// tvserver.ini, --stats on the command line, or by typing  stats  in the
// server window while it runs.

import (
	"bufio"
	"fmt"
	"log"
	"os"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

type viewerStats struct {
	id       string
	terminal string
	depth    string
	fps      float64 // this viewer's frame-rate cap
	start    time.Time
	q        *outQueue
	v        *viewer
	audio    *audioSession
	sess     *session
	mu       sync.Mutex // guards depth and fps (the viewer can change them)

	painted     atomic.Int64 // frames drawn for this viewer
	pacedWaits  atomic.Int64 // loop passes where a frame waited for the connection
	syncDrops   atomic.Int64 // frames skipped to stay in step with the sound
	holdMs      atomic.Int64 // total time frames waited for their sound
	holdN       atomic.Int64
	last        statSnap
	lastPrimes  int
	lastResyncs int
}

type statSnap struct {
	at                      time.Time
	arrived, painted, paced int64
	syncDrops, paint, sound int64
}

func (h *hub) addViewerStats(st *viewerStats) {
	st.last = st.snap(time.Now())
	h.statsMu.Lock()
	h.stats[st] = struct{}{}
	h.statsMu.Unlock()
}

func (h *hub) removeViewerStats(st *viewerStats) {
	h.statsMu.Lock()
	delete(h.stats, st)
	h.statsMu.Unlock()
}

func (st *viewerStats) snap(now time.Time) statSnap {
	return statSnap{
		at: now, arrived: st.v.arrived.Load(), painted: st.painted.Load(),
		paced: st.pacedWaits.Load(), syncDrops: st.syncDrops.Load(),
		paint: st.q.bytesPaint.Load(), sound: st.q.bytesAudio.Load(),
	}
}

func mbit(bytes int64, secs float64) float64 { return float64(bytes) * 8 / 1e6 / secs }

// soundCounters reads the gap counters from the audio session.
func (s *audioSession) soundCounters() (enabled, muted bool, primes, resyncs int, leadMs int64) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.enabled, s.muted, s.primes, s.resyncs, s.leadMsLocked(time.Now())
}

// report returns one line about this viewer since the last report and
// starts a new measuring window.
func (st *viewerStats) report(now time.Time, feedFPS float64) string {
	depth, vfps := st.view()
	cur := st.snap(now)
	prev := st.last
	st.last = cur
	secs := now.Sub(prev.at).Seconds()
	if secs < 0.5 {
		secs = 0.5
	}
	arrivedFPS := float64(cur.arrived-prev.arrived) / secs
	shownFPS := float64(cur.painted-prev.painted) / secs
	picture := mbit(cur.paint-prev.paint, secs)
	sound := mbit(cur.sound-prev.sound, secs)
	target := arrivedFPS
	if vfps < target {
		target = vfps
	}
	rate := st.q.pacedRate()

	conn := "not limiting"
	if rate > 0 {
		conn = fmt.Sprintf("LIMITED to about %.1f Mbit/s", rate*8/1e6)
	}
	if r := st.sess.rtt(); r > 0 {
		conn += fmt.Sprintf(", round trip %d ms", r.Milliseconds())
	}

	soundState := "off"
	gaps := 0
	if on, muted, primes, resyncs, lead := st.audio.soundCounters(); on {
		gaps = primes - st.lastPrimes
		st.lastPrimes, st.lastResyncs = primes, resyncs
		switch {
		case muted:
			soundState = "muted"
		case gaps > 0:
			soundState = fmt.Sprintf("%s, %d gap(s), %d ms queued", st.audio.soundFormat(), gaps, lead)
		default:
			soundState = fmt.Sprintf("%s, ok, %d ms queued", st.audio.soundFormat(), lead)
		}
	}

	// Verdict: the biggest problem first.
	verdict := "OK"
	syncDrops := cur.syncDrops - prev.syncDrops
	switch {
	case arrivedFPS == 0 && feedFPS == 0:
		verdict = "no picture coming in from the camera PC"
	case rate > 0 && shownFPS < target*0.85:
		hint := "the viewer can press S to pick fewer colors, a lower speed or lower sound quality (or set color = 16 / fps in tvserver.ini)"
		if depth == "16-color" {
			hint = "the viewer can press S to lower the speed or sound quality (or lower fps in tvserver.ini)"
		}
		verdict = "BOTTLENECK: this viewer's connection or terminal program can't take this much; " + hint
	case feedFPS > 0 && feedFPS < vfps*0.8 && shownFPS >= arrivedFPS*0.85:
		verdict = fmt.Sprintf("BOTTLENECK: the camera PC only sends %.1f fps (its upload, CPU, or the camera/SplitCam)", feedFPS)
	case syncDrops > int64(secs*2):
		verdict = "picture frames skipped to stay in step with the sound; raise sync_slack_ms if the picture looks jumpy"
	case gaps > 0:
		verdict = "sound gaps: raise audio_prebuffer / audio_max_queued in tvserver.ini"
	case target > 0 && shownFPS < target*0.85:
		verdict = "frames skipped (server busy, or the viewer's terminal is slow to draw)"
	}

	hold := ""
	if hn := st.holdN.Swap(0); hn > 0 {
		hold = fmt.Sprintf(" | picture held %d ms for lip-sync", st.holdMs.Swap(0)/hn)
	}
	return fmt.Sprintf("%s %s %dx%d %s | showing %.1f of %.1f fps%s | sending %.2f Mbit/s (picture %.2f + sound %.2f) | connection %s | sound %s | %s",
		st.id, st.terminal, st.sess.cols.Load(), st.sess.rows.Load(), depth,
		shownFPS, target, hold, picture+sound, picture, sound, conn, soundState, verdict)
}

type statsLogger struct {
	h        *hub
	on       atomic.Bool
	interval atomic.Int64 // seconds
	lastFeed map[*feed][2]int64
	lastAt   time.Time
	maxFPS   float64
}

func newStatsLogger(h *hub, on bool, intervalSecs int, maxFPS float64) *statsLogger {
	l := &statsLogger{h: h, lastFeed: map[*feed][2]int64{}, lastAt: time.Now(), maxFPS: maxFPS}
	l.on.Store(on)
	if intervalSecs < 2 {
		intervalSecs = 10
	}
	l.interval.Store(int64(intervalSecs))
	return l
}

func (l *statsLogger) run() {
	next := time.Now().Add(time.Duration(l.interval.Load()) * time.Second)
	for range time.Tick(time.Second) {
		if !l.on.Load() || time.Now().Before(next) {
			if !l.on.Load() {
				next = time.Now().Add(time.Duration(l.interval.Load()) * time.Second)
			}
			continue
		}
		l.report(true)
		next = time.Now().Add(time.Duration(l.interval.Load()) * time.Second)
	}
}

// report logs the feed and every viewer. With all=false and no viewers it
// still says so (used by the  who  command).
func (l *statsLogger) report(periodic bool) {
	now := time.Now()
	secs := now.Sub(l.lastAt).Seconds()
	if secs < 0.5 {
		secs = 0.5
	}
	l.lastAt = now

	l.h.mu.Lock()
	names := make([]string, 0, len(l.h.feeds))
	for n := range l.h.feeds {
		names = append(names, n)
	}
	l.h.mu.Unlock()
	sort.Strings(names)
	feedFPS := 0.0
	for _, n := range names {
		f := l.h.get(n)
		fr, by := f.framesIn.Load(), f.bytesIn.Load()
		prev := l.lastFeed[f]
		l.lastFeed[f] = [2]int64{fr, by}
		f.mu.Lock()
		live := f.producer != nil
		f.mu.Unlock()
		if !live {
			if periodic {
				log.Printf("stats feed %q: not connected", n)
			}
			continue
		}
		fps := float64(fr-prev[0]) / secs
		if fps > feedFPS {
			feedFPS = fps
		}
		from, _ := f.from.Load().(string)
		log.Printf("stats feed %q from %s: %.1f fps arriving, %.2f Mbit/s", n, from, fps, mbit(by-prev[1], secs))
	}

	l.h.statsMu.Lock()
	list := make([]*viewerStats, 0, len(l.h.stats))
	for st := range l.h.stats {
		list = append(list, st)
	}
	l.h.statsMu.Unlock()
	sort.Slice(list, func(i, j int) bool { return list[i].start.Before(list[j].start) })
	if len(list) == 0 {
		log.Printf("stats: no viewers right now")
		return
	}
	var total float64
	for _, st := range list {
		line := st.report(now, feedFPS)
		log.Printf("stats viewer %s", line)
		if i := strings.Index(line, "sending "); i >= 0 {
			if v, err := strconv.ParseFloat(strings.Fields(line[i+8:])[0], 64); err == nil {
				total += v
			}
		}
	}
	log.Printf("stats total: %d viewer(s), %.2f Mbit/s going out from this server", len(list), total)
}

// commands reads typed commands from the server window.
func (l *statsLogger) commands() {
	sc := bufio.NewScanner(os.Stdin)
	for sc.Scan() {
		f := strings.Fields(strings.ToLower(sc.Text()))
		if len(f) == 0 {
			continue
		}
		switch f[0] {
		case "stats", "stat", "s":
			arg := ""
			if len(f) > 1 {
				arg = f[1]
			}
			switch {
			case arg == "on":
				l.on.Store(true)
			case arg == "off":
				l.on.Store(false)
			case arg == "":
				l.on.Store(!l.on.Load())
			default:
				n, err := strconv.Atoi(arg)
				if err != nil || n < 2 || n > 3600 {
					fmt.Println("  usage: stats | stats on | stats off | stats <seconds between reports, 2-3600>")
					continue
				}
				l.interval.Store(int64(n))
				l.on.Store(true)
			}
			if l.on.Load() {
				log.Printf("stats ON: a report every %d seconds (type  stats  again to turn off)", l.interval.Load())
				l.report(true)
			} else {
				log.Printf("stats OFF")
			}
		case "who", "viewers", "w":
			l.report(false)
		case "help", "?", "h":
			fmt.Println("  Commands (type, then press Enter):")
			fmt.Println("    stats            turn viewer statistics on/off")
			fmt.Println("    stats 5          statistics every 5 seconds")
			fmt.Println("    who              one report right now: the feed and every viewer")
			fmt.Println("    help             this list")
		default:
			fmt.Println("  Unknown command. Type  help  for the list.")
		}
	}
}
