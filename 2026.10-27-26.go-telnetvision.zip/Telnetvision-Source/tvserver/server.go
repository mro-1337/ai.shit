// tvserver: a standalone Telnetvision server. It receives the live feed
// from telnetvision.exe and lets anyone telnet in to watch it as ANSI art.
// No BBS needed (though the classic door can still connect if you want).
package main

import (
	"bufio"
	"crypto/rand"
	"crypto/tls"
	"encoding/hex"
	"flag"
	"fmt"
	"log"
	"net"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync/atomic"
	"time"
)

const serverVersion = "1.1.0"

type serverConfig struct {
	TelnetPort int
	FeedPort   int
	DoorPort   int // 0 = off
	WebPort    int // web viewer; 0 = off
	Listen     string
	Token      string
	TLSCert    string
	TLSKey     string
	MaxCallers int
	Stats      bool
	StatsSecs  int
	View       viewOptions
}

func defaultServerConfig() serverConfig {
	return serverConfig{
		TelnetPort: 2323, FeedPort: 7600, WebPort: 8080, Listen: "0.0.0.0", MaxCallers: 50, StatsSecs: 10,
		View: viewOptions{
			channel: "cam", encoding: "auto", color: "auto", saturation: 1.8,
			dither: true, shade: true, fps: 15, maxFPS: 30, hint: true, captions: true, titleBar: true, menu: true, lipSync: true, maxHold: 300 * time.Millisecond, sixel: true, sixelCols: 64, sixelDetail: sixelMedium, cellW: 8, cellH: 16, banner: "Telnetvision",
			audio: defaultAudioConfig(), webColor: "truecolor",
		},
	}
}

func serverExeDir() string {
	p, err := os.Executable()
	if err != nil {
		return "."
	}
	if r, err := filepath.EvalSymlinks(p); err == nil {
		p = r
	}
	return filepath.Dir(p)
}

func (c *serverConfig) apply(m map[string]string) error {
	_, err := c.applyWarn(m)
	return err
}

var reInlineComment = regexp.MustCompile(`\s+[#;](\s.*)?$`)

// cleanINIValue drops a trailing "  # note" and surrounding quotes, so
// color = "16"   # for slow links  reads as 16.
func cleanINIValue(v string) string {
	v = strings.TrimSpace(reInlineComment.ReplaceAllString(strings.TrimSpace(v), ""))
	if len(v) >= 2 && (v[0] == '"' && v[len(v)-1] == '"' || v[0] == '\'' && v[len(v)-1] == '\'') {
		v = strings.TrimSpace(v[1 : len(v)-1])
	}
	return v
}

func squash(v string) string {
	return strings.NewReplacer(" ", "", "-", "", "_", "", ".", "").Replace(strings.ToLower(v))
}

// normalizeColor maps the many ways to write a colour setting to
// "auto", "16", "256" or "truecolor".
func normalizeColor(v string) (string, bool) {
	switch squash(v) {
	case "", "auto", "detect", "probe":
		return "auto", true
	case "16", "16color", "16colors", "16colour", "16colours", "cga", "ansi", "ansi16", "ega", "basic":
		return "16", true
	case "256", "256color", "256colors", "256colour", "256colours", "xterm256", "8bit":
		return "256", true
	case "truecolor", "truecolour", "24", "24bit", "24bitcolor", "24bitcolour", "true", "rgb", "full", "fullcolor", "millions":
		return "truecolor", true
	}
	return "auto", false
}

func normalizeEncoding(v string) (string, bool) {
	switch squash(v) {
	case "", "auto", "detect":
		return "auto", true
	case "cp437", "437", "ibm", "ibmpc", "dos", "ansi", "bbs":
		return "cp437", true
	case "utf8", "unicode", "utf":
		return "utf8", true
	}
	return "auto", false
}

// applyWarn reads the settings and returns a warning for every value it
// couldn't understand (that setting keeps its default).
func (c *serverConfig) applyWarn(raw map[string]string) ([]string, error) {
	m := make(map[string]string, len(raw))
	for k, v := range raw {
		m[k] = cleanINIValue(v)
	}
	var warns []string
	warn := func(k, v, valid string) {
		warns = append(warns, fmt.Sprintf("%s = %s  isn't a setting I understand (use %s); using the default instead", k, v, valid))
	}
	var err error
	num := func(k string, dst *int) {
		if v, ok := m[k]; ok && err == nil {
			n, e := strconv.Atoi(v)
			if e != nil {
				err = fmt.Errorf("%s = %s  is not a number", k, v)
				return
			}
			*dst = n
		}
	}
	str := func(k string, dst *string) {
		if v, ok := m[k]; ok {
			*dst = v
		}
	}
	boolean := func(k string, dst *bool) {
		if v, ok := m[k]; ok {
			if b, valid := iniBool(v); valid {
				*dst = b
			} else {
				warn(k, v, "on or off")
			}
		}
	}
	num("telnet_port", &c.TelnetPort)
	num("feed_port", &c.FeedPort)
	num("door_port", &c.DoorPort)
	num("web_port", &c.WebPort)
	num("max_callers", &c.MaxCallers)
	num("stats_interval", &c.StatsSecs)
	str("listen", &c.Listen)
	str("token", &c.Token)
	str("tls_cert", &c.TLSCert)
	str("tls_key", &c.TLSKey)
	str("channel", &c.View.channel)
	str("banner", &c.View.banner)
	if v, ok := m["color"]; ok {
		n, valid := normalizeColor(v)
		if !valid {
			warn("color", v, "auto, 16, 256 or truecolor")
		}
		c.View.color = n
	}
	if v, ok := m["web_color"]; ok {
		n, valid := normalizeColor(v)
		if !valid || n == "auto" {
			if !valid {
				warn("web_color", v, "truecolor, 256 or 16")
			}
			n = "truecolor"
		}
		c.View.webColor = n
	}
	if v, ok := m["encoding"]; ok {
		n, valid := normalizeEncoding(v)
		if !valid {
			warn("encoding", v, "auto, cp437 or utf8")
		}
		c.View.encoding = n
	}
	if v, ok := m["fit"]; ok {
		switch squash(v) {
		case "stretch", "fill":
			c.View.stretch = true
		case "letterbox", "fit", "keep", "":
			c.View.stretch = false
		default:
			warn("fit", v, "letterbox or stretch")
		}
	}
	if v, ok := m["saturation"]; ok {
		if f, e := strconv.ParseFloat(v, 64); e == nil && f >= 0 && f <= 5 {
			c.View.saturation = f
		} else {
			warn("saturation", v, "a number like 1.8")
		}
	}
	if v, ok := m["fps"]; ok {
		if f, e := strconv.ParseFloat(v, 64); e == nil && f > 0 && f <= 60 {
			c.View.fps = f
		} else {
			warn("fps", v, "a number from 1 to 60")
		}
	}
	if v, ok := m["max_fps"]; ok {
		if f, e := strconv.ParseFloat(v, 64); e == nil && f > 0 && f <= 60 {
			c.View.maxFPS = f
		} else {
			warn("max_fps", v, "a number from 1 to 60")
		}
	}
	if v, ok := m["audio"]; ok {
		switch squash(v) {
		case "auto", "on", "off":
			m["audio"] = squash(v)
		case "yes", "true", "1":
			m["audio"] = "auto"
		case "no", "false", "0", "none":
			m["audio"] = "off"
		default:
			warn("audio", v, "auto or off")
		}
	}
	boolean("dither", &c.View.dither)
	boolean("shade", &c.View.shade)
	boolean("hint", &c.View.hint)
	boolean("captions", &c.View.captions)
	boolean("title_bar", &c.View.titleBar)
	boolean("stats", &c.Stats)
	boolean("viewer_settings", &c.View.menu)
	boolean("lip_sync", &c.View.lipSync)
	boolean("sixel", &c.View.sixel)
	boolean("sound_debug", &c.View.soundDebug)
	if v, ok := m["sixel_colors"]; ok {
		if n, e := strconv.Atoi(v); e == nil && n >= 2 && n <= 256 {
			c.View.sixelCols = n
		} else {
			warn("sixel_colors", v, "a number from 2 to 256, like 64")
		}
	}
	if v, ok := m["sixel_detail"]; ok {
		d, valid := normalizeSixelDetail(v)
		if !valid {
			warn("sixel_detail", v, "high, medium or low")
		}
		c.View.sixelDetail = d
	}
	if v, ok := m["sixel_cell"]; ok {
		var cw, ch int
		if _, e := fmt.Sscanf(strings.ReplaceAll(squash(v), "*", "x"), "%dx%d", &cw, &ch); e == nil && cw >= 4 && cw <= 32 && ch >= 6 && ch <= 64 {
			c.View.cellW, c.View.cellH = cw, ch
		} else {
			warn("sixel_cell", v, "the size of one character in pixels, like 8x16")
		}
	}
	if v, ok := m["max_sync_delay_ms"]; ok {
		if n, e := strconv.Atoi(v); e == nil && n >= 0 && n <= 5000 {
			c.View.maxHold = time.Duration(n) * time.Millisecond
		} else {
			warn("max_sync_delay_ms", v, "a number of milliseconds, like 300")
		}
	}
	if v, ok := m["sound_compression"]; ok {
		if _, valid := serverSoundCodec(v); !valid {
			warn("sound_compression", v, "auto, adpcm, ulaw or none")
		}
	}
	if v, ok := m["sound_quality"]; ok {
		if _, valid := normalizeQuality(v); !valid {
			warn("sound_quality", v, "best, good, low or off")
		}
	}
	c.View.audio = audioConfigFromINI(m)
	return warns, err
}

func writeDefaultServerINI(path, token string) error {
	return os.WriteFile(path, []byte(serverINITemplate(token)), 0o600)
}

// serverINITemplate is the full, commented tvserver.ini for this version.
func serverINITemplate(token string) string {
	return strings.Join([]string{
		"# Telnetvision server settings. Edit in Notepad, then restart tvserver.exe.",
		"",
		"# Port people telnet to (23 is the standard telnet port).",
		"telnet_port = 2323",
		"",
		"# Port telnetvision.exe sends the feed to (BBS_PORT in telnetvision.ini).",
		"feed_port = 7600",
		"",
		"# Shared password for the feed. Put the same value in telnetvision.ini as TOKEN.",
		"token = " + token,
		"",
		"# The feed port accepts both TLS=1 and TLS=0 from telnetvision.exe.",
		"# Leave these blank to use an automatic self-signed certificate",
		"# (keep INSECURE=1 in telnetvision.ini), or give your own cert files.",
		"tls_cert =",
		"tls_key =",
		"",
		"# Which channel telnet callers watch (CHANNEL in telnetvision.ini).",
		"channel = cam",
		"",
		"# Network address to listen on. 0.0.0.0 = every network card.",
		"listen = 0.0.0.0",
		"",
		"# Most callers allowed at once.",
		"max_callers = 50",
		"",
		"# Title on the 'waiting for the broadcast' screen.",
		"banner = Telnetvision",
		"",
		"# Web viewer: people can watch in their browser at  http://this-pc:8080",
		"# (picture and sound, using fTelnet). 0 = off.",
		"web_port = 8080",
		"# Colors for people watching in a web browser (color below is for telnet).",
		"#   truecolor | 256 | 16   - viewers can change it with S",
		"web_color = truecolor",
		"",
		"# Optional: also serve the classic door.exe for BBS use (e.g. 7601). 0 = off.",
		"door_port = 0",
		"",
		"# How callers see it:",
		"#   encoding: auto | cp437 (BBS terminals like SyncTERM) | utf8 (PuTTY, Linux, Mac)",
		"#   color:    auto | truecolor | 256 | 16   (telnet viewers; browsers use web_color)",
		"#   fit:      letterbox | stretch",
		"encoding = auto",
		"color = auto",
		"fit = letterbox",
		"# Frames a second viewers start at, and the most they can raise it to",
		"# with the + key (- lowers it). Can't be more than the camera PC sends (FPS).",
		"fps = 15",
		"max_fps = 30",
		"saturation = 1.8",
		"shade = true",
		"dither = true",
		"hint = true",
		"# Show subtitles / closed captions (viewers can press C to toggle).",
		"captions = on",
		"# Bar along the bottom with the movie's name (viewers can press T to toggle).",
		"title_bar = on",
		"# Sixel graphics: viewers whose terminal can show them (SyncTERM, IcyTerm, ...)",
		"# can pick \"Sixel\" under Colors in the S menu for real pixels instead of",
		"# characters (about as much data as 24-bit color). sixel_colors: colours per",
		"# picture (more = nicer, more data). sixel_cell: one character's size in pixels.",
		"sixel = on",
		"sixel_colors = 64",
		"# Sixel detail viewers start with (they can change it with S, option 7):",
		"#   high = sharpest, most data   medium = less data (default)   low = least data",
		"sixel_detail = medium",
		"sixel_cell = 8x16",
		"",
		"# Let viewers press S for a settings menu to lower their own colors,",
		"# frame rate and sound quality (handy on slow connections).",
		"viewer_settings = on",
		"",
		"# Viewer statistics in this window and tvserver.log, to find what's",
		"# slowing viewers down. You can also type  stats  in the window.",
		"stats = off",
		"stats_interval = 10",
		"",
		"# Sound for SyncTERM 1.10a+ callers (needs AUDIO=1 in telnetvision.ini).",
		"#   auto = ask each caller's terminal; off = never send sound.",
		"audio = auto",
		"# Starting volume in dB: 0 = full, -6 = half as loud, +6 = twice as loud",
		"# (above 0 the server boosts the sound). Viewers can change it with S.",
		"audio_volume_db = 0",
		"# Sound compression sent to viewers:",
		"#   auto  = adpcm (1/4 the size) for SyncTERM, ulaw for other terminals such",
		"#           as IcyTerm that can't play adpcm (default)",
		"#   adpcm = 1/4 the size (SyncTERM only)   ulaw = 1/2 the size   none = uncompressed",
		"# Viewers can change it with S; their choice is remembered (viewers.json).",
		"sound_compression = auto",
		"# Starting sound quality: best (as broadcast) | good (22 kHz mono) | low (11 kHz mono) | off",
		"sound_quality = best",
		"# Lip-sync: the picture waits for its sound so they play together. This",
		"# delays the picture by the sound's buffer (usually 0.2-0.5 s). off = show",
		"# the picture at once (least delay). Viewers can switch it with S.",
		"lip_sync = on",
		"# The longest a frame may wait for its sound, in milliseconds.",
		"max_sync_delay_ms = 300",
		"# Lip-sync tolerance in milliseconds before a frame is skipped or held.",
		"sync_slack_ms = 120",
		"# Log details of how each caller's terminal answers about sound (\"sound debug\"",
		"# lines). It's done anyway for SyncTERM callers whose sound doesn't come up.",
		"sound_debug = off",
		"# Sound buffer, in 80 ms chunks: collected before playing, and most kept",
		"# queued in SyncTERM. Raise both if sound is choppy (adds delay), lower to cut delay.",
		"audio_prebuffer = 3",
		"audio_max_queued = 6",
		"",
	}, "\r\n")
}

func localIPs() []string {
	var ips []string
	addrs, _ := net.InterfaceAddrs()
	for _, a := range addrs {
		if n, ok := a.(*net.IPNet); ok && n.IP.To4() != nil && !n.IP.IsLoopback() && !n.IP.IsLinkLocalUnicast() {
			ips = append(ips, n.IP.String())
		}
	}
	return ips
}

func serverFatal(pause bool, format string, a ...any) {
	fmt.Fprintf(os.Stderr, "\nERROR: "+format+"\n", a...)
	if pause {
		fmt.Fprint(os.Stderr, "\nPress Enter to close...")
		bufio.NewReader(os.Stdin).ReadString('\n')
	}
	os.Exit(1)
}

func main() {
	pause := serverDoubleClicked()
	cfgPath := flag.String("config", filepath.Join(serverExeDir(), "tvserver.ini"), "settings file")
	telnetPort := flag.Int("telnet-port", 0, "telnet port (overrides tvserver.ini)")
	feedPort := flag.Int("feed-port", 0, "feed port (overrides tvserver.ini)")
	webPort := flag.Int("web-port", -1, "web viewer port, 0 = off (overrides tvserver.ini)")
	token := flag.String("token", "", "feed token (overrides tvserver.ini)")
	statsFlag := flag.Bool("stats", false, "log viewer statistics (same as  stats = on)")
	showVer := flag.Bool("version", false, "print version and exit")
	flag.Parse()
	if *showVer {
		fmt.Println("tvserver", serverVersion)
		return
	}

	cfg := defaultServerConfig()
	created := false
	if _, err := os.Stat(*cfgPath); os.IsNotExist(err) {
		b := make([]byte, 16)
		rand.Read(b)
		if err := writeDefaultServerINI(*cfgPath, hex.EncodeToString(b)); err != nil {
			serverFatal(pause, "creating %s: %v", *cfgPath, err)
		}
		created = true
	}
	var upgradeMsgs []string
	if !created {
		// Add settings introduced since this file was made, at their
		// defaults. The token is never added: it must be the user's own.
		upgradeINI(*cfgPath, serverINITemplate(""), nil, map[string]bool{"token": true}, false,
			"tvserver "+serverVersion, func(f string, a ...any) { upgradeMsgs = append(upgradeMsgs, fmt.Sprintf(f, a...)) })
	}
	iniWarnings, err := cfg.applyWarn(loadINI(*cfgPath))
	if err != nil {
		serverFatal(pause, "%s: %v", *cfgPath, err)
	}
	if *telnetPort > 0 {
		cfg.TelnetPort = *telnetPort
	}
	if *webPort >= 0 {
		cfg.WebPort = *webPort
	}
	if *feedPort > 0 {
		cfg.FeedPort = *feedPort
	}
	if *token != "" {
		cfg.Token = *token
	}
	if *statsFlag {
		cfg.Stats = true
	}
	if cfg.Token == "" {
		serverFatal(pause, "token is empty in %s", *cfgPath)
	}
	for _, p := range []int{cfg.TelnetPort, cfg.FeedPort} {
		if p < 1 || p > 65535 {
			serverFatal(pause, "ports must be 1-65535")
		}
	}
	if cfg.TelnetPort == cfg.FeedPort || (cfg.DoorPort != 0 && (cfg.DoorPort == cfg.TelnetPort || cfg.DoorPort == cfg.FeedPort)) {
		serverFatal(pause, "telnet_port, feed_port and door_port must all be different")
	}

	// The feed port accepts TLS and plaintext alike. Without a configured
	// certificate, a self-signed one is generated at startup.
	customCert := cfg.TLSCert != "" || cfg.TLSKey != ""
	var tlsCfg *tls.Config
	if customCert {
		cert, err := tls.LoadX509KeyPair(cfg.TLSCert, cfg.TLSKey)
		if err != nil {
			serverFatal(pause, "loading TLS certificate: %v", err)
		}
		tlsCfg = &tls.Config{Certificates: []tls.Certificate{cert}}
	} else {
		var err error
		if tlsCfg, err = selfSignedTLS(); err != nil {
			serverFatal(pause, "making a TLS certificate: %v", err)
		}
	}

	addr := func(p int) string { return net.JoinHostPort(cfg.Listen, strconv.Itoa(p)) }
	telnetLn, err := net.Listen("tcp", addr(cfg.TelnetPort))
	if err != nil {
		serverFatal(pause, "can't use telnet port %d: %v\n(is another program using it? change telnet_port in tvserver.ini)", cfg.TelnetPort, err)
	}
	feedLn, err := net.Listen("tcp", addr(cfg.FeedPort))
	if err != nil {
		serverFatal(pause, "can't use feed port %d: %v\n(change feed_port in tvserver.ini)", cfg.FeedPort, err)
	}

	logPath := filepath.Join(serverExeDir(), "tvserver.log")
	if st, err := os.Stat(logPath); err == nil && st.Size() > 1<<20 {
		os.Rename(logPath, logPath+".old")
	}
	logFile, _ := os.OpenFile(logPath, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	log.SetOutput(&lineWriter{file: logFile})
	log.SetFlags(0)

	setServerTitle(fmt.Sprintf("Telnetvision server - telnet port %d", cfg.TelnetPort))
	fmt.Printf("Telnetvision server %s\n\n", serverVersion)
	if created {
		fmt.Printf("  Created %s with a new token.\n\n", *cfgPath)
	}
	for _, w := range iniWarnings {
		fmt.Printf("  WARNING in %s: %s\n\n", filepath.Base(*cfgPath), w)
		log.Printf("warning in %s: %s", filepath.Base(*cfgPath), w)
	}
	for _, m := range upgradeMsgs {
		fmt.Printf("  Note: %s\n\n", m)
		log.Print(m)
	}
	fmt.Printf("  Viewers telnet to : port %d\n", cfg.TelnetPort)
	for _, ip := range localIPs() {
		fmt.Printf("                      telnet %s %d\n", ip, cfg.TelnetPort)
	}
	certNote := "self-signed: keep INSECURE=1"
	if customCert {
		certNote = "your certificate"
	}
	fmt.Printf("  Feed comes in on  : port %d (TLS or plain; %s)\n", cfg.FeedPort, certNote)
	fmt.Printf("  Feed token        : %s\n", cfg.Token)
	fmt.Printf("  Channel           : %s\n", cfg.View.channel)
	colorDesc := map[string]string{
		"auto":      "auto (24-bit for terminals that support it, else 16)",
		"16":        "16 colors for every viewer",
		"256":       "256 colors for every viewer",
		"truecolor": "24-bit for every viewer",
	}[cfg.View.color]
	fmt.Printf("  Viewer colors     : %s (telnet; set by color)\n", colorDesc)
	if cfg.WebPort != 0 {
		fmt.Printf("  Browser colors    : %s (set by web_color)\n", depthName(map[string]string{"truecolor": colorTrue, "256": color256, "16": color16}[cfg.View.webColor]))
	}
	fmt.Println()
	fmt.Println("  In telnetvision.ini on the camera PC, set:")
	fmt.Printf("    BBS_HOST=<this computer's address>  BBS_PORT=%d  TOKEN=%s  CHANNEL=%s\n",
		cfg.FeedPort, cfg.Token, cfg.View.channel)
	fmt.Println()
	fmt.Println("  Type  stats  and press Enter for viewer statistics, or  help  for commands.")
	fmt.Println("  Close this window (or press Ctrl+C) to stop the server.")
	fmt.Println()

	viewerPrefs.load(filepath.Dir(*cfgPath))
	h := newHub()
	go func() {
		for {
			c, err := feedLn.Accept()
			if err != nil {
				log.Printf("feed listener stopped: %v", err)
				return
			}
			go func(c net.Conn) {
				c, _ = sniffTLS(c, tlsCfg)
				h.handleProducer(c, cfg.Token)
			}(c)
		}
	}()

	if cfg.DoorPort != 0 {
		doorLn, err := net.Listen("tcp", net.JoinHostPort("127.0.0.1", strconv.Itoa(cfg.DoorPort)))
		if err != nil {
			serverFatal(pause, "can't use door port %d: %v", cfg.DoorPort, err)
		}
		fmt.Printf("  Classic door.exe can connect on 127.0.0.1:%d\n\n", cfg.DoorPort)
		go func() {
			for {
				c, err := doorLn.Accept()
				if err != nil {
					return
				}
				go h.handleDoor(c)
			}
		}()
	}

	stats := newStatsLogger(h, cfg.Stats, cfg.StatsSecs, cfg.View.fps)
	go stats.run()
	go stats.commands()
	if cfg.Stats {
		log.Printf("stats ON: a report every %d seconds (type  stats  to turn off)", cfg.StatsSecs)
	}

	var active atomic.Int32
	if cfg.WebPort != 0 {
		if _, err := startWebServer(cfg, h, &active); err != nil {
			fmt.Printf("  WARNING: can't use web port %d: %v (web viewer is off)\n\n", cfg.WebPort, err)
			log.Printf("can't use web port %d: %v", cfg.WebPort, err)
		} else {
			fmt.Printf("  Watch in a browser: http://<this computer's address>:%d\n", cfg.WebPort)
			for _, ip := range localIPs() {
				fmt.Printf("                      http://%s:%d\n", ip, cfg.WebPort)
			}
			fmt.Println()
		}
	}
	go func() {
		for range time.Tick(30 * time.Second) {
			live, last, n := h.status(cfg.View.channel)
			state := "no feed"
			if live && time.Since(last) < 5*time.Second {
				state = "feed live"
			} else if live {
				state = "feed connected, no frames"
			}
			log.Printf("status: %s, %d watching", state, n)
		}
	}()

	for {
		c, err := telnetLn.Accept()
		if err != nil {
			if ne, ok := err.(net.Error); ok && ne.Timeout() {
				continue
			}
			log.Printf("telnet accept: %v", err)
			time.Sleep(100 * time.Millisecond)
			continue
		}
		if int(active.Load()) >= cfg.MaxCallers {
			c.Write([]byte("\r\nSorry, the channel is full right now. Try again soon.\r\n"))
			c.Close()
			log.Printf("caller %s turned away: %d callers is the limit", c.RemoteAddr(), cfg.MaxCallers)
			continue
		}
		active.Add(1)
		go serveTelnet(c, h, cfg.View, &active)
	}
}

// lineWriter timestamps log lines to the console and the log file.
type lineWriter struct{ file *os.File }

func (w *lineWriter) Write(p []byte) (int, error) {
	now := time.Now()
	fmt.Printf("%s %s", now.Format("15:04:05"), p)
	if w.file != nil {
		fmt.Fprintf(w.file, "%s %s", now.Format("2006-01-02 15:04:05"), p)
	}
	return len(p), nil
}
