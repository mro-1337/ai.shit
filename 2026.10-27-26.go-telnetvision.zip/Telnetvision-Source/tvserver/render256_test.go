package main

import (
	"bytes"
	"strings"
	"testing"
)

func TestRender256(t *testing.T) {
	if to256(255, 0, 0) != 196 || to256(0, 0, 0) != 16 || to256(255, 255, 255) != 231 || to256(128, 128, 128) != 102 {
		t.Fatalf("palette: red %d black %d white %d gray %d", to256(255, 0, 0), to256(0, 0, 0), to256(255, 255, 255), to256(128, 128, 128))
	}
	cols, rows := 4, 2
	px := make([]byte, 2*rows*cols*3)
	for i := range px {
		px[i] = byte(i * 37)
	}
	var b bytes.Buffer
	prev := render256(&b, px, cols, rows, cols, rows, 0, 0, nil, []byte("#"))
	if strings.Count(b.String(), "#") != cols*rows || !strings.Contains(b.String(), "38;5;") {
		t.Fatalf("output %q", b.String())
	}
	b.Reset()
	render256(&b, px, cols, rows, cols, rows, 0, 0, prev, []byte("#"))
	if b.Len() != 0 {
		t.Fatalf("unchanged frame repainted: %q", b.String())
	}
}

func TestViewerFPSSteps(t *testing.T) {
	v := viewerSettings{fps: 15, maxFPS: 30}
	if !v.stepFPS(+1) || v.fps != 20 {
		t.Fatalf("+ from 15 -> %v", v.fps)
	}
	for v.stepFPS(+1) {
	}
	if v.fps != 30 {
		t.Fatalf("top = %v", v.fps)
	}
	for v.stepFPS(-1) {
	}
	if v.fps != 1 {
		t.Fatalf("bottom = %v", v.fps)
	}
	v = viewerSettings{fps: 7.5, maxFPS: 7.5}
	if v.stepFPS(+1) || !v.stepFPS(-1) || v.fps != 6 {
		t.Fatalf("odd fps: %v", v.fps)
	}
}
