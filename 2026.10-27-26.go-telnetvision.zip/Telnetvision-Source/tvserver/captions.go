package main

import (
	"bytes"
	"fmt"
	"strings"
)

// msgMark starts a caption line that is a message typed in the camera
// window (sent only to servers whose WELCOME offers capMessages). Messages
// show even when a viewer has hidden the subtitles with C.
const msgMark = "\x02"

// onlyMessages keeps just the marked message lines of a caption.
func onlyMessages(caption []byte) []byte {
	var keep []string
	for _, l := range strings.Split(string(caption), "\n") {
		if strings.HasPrefix(l, msgMark) {
			keep = append(keep, l)
		}
	}
	return []byte(strings.Join(keep, "\n"))
}

// captionLines word-wraps a caption into at most three lines of width,
// keeping the newest words when it overflows. Line breaks sent by the
// producer (subtitle lines) are kept.
func captionLines(caption []byte, width int) []string {
	if width < 10 {
		width = 10
	}
	var out []string
	for _, para := range strings.Split(strings.ReplaceAll(string(caption), "\r", ""), "\n") {
		// A message typed in the camera window comes marked (msgMark);
		// every line it wraps onto keeps the mark.
		mark := ""
		if strings.HasPrefix(para, msgMark) {
			mark, para = msgMark, para[len(msgMark):]
		}
		start := len(out)
		words := strings.Fields(para)
		line := ""
		for _, w := range words {
			for len([]rune(w)) > width { // a single huge word
				r := []rune(w)
				if line != "" {
					out = append(out, line)
					line = ""
				}
				out = append(out, string(r[:width]))
				w = string(r[width:])
			}
			switch {
			case line == "":
				line = w
			case len([]rune(line))+1+len([]rune(w)) <= width:
				line += " " + w
			default:
				out = append(out, line)
				line = w
			}
		}
		if line != "" {
			out = append(out, line)
		}
		for i := start; i < len(out); i++ {
			out[i] = mark + out[i]
		}
	}
	if len(out) > 3 {
		out = out[len(out)-3:]
	}
	return out
}

// cp437 maps the accented letters and punctuation subtitles commonly use.
var cp437 = map[rune]byte{
	'Ç': 0x80, 'ü': 0x81, 'é': 0x82, 'â': 0x83, 'ä': 0x84, 'à': 0x85, 'å': 0x86, 'ç': 0x87,
	'ê': 0x88, 'ë': 0x89, 'è': 0x8A, 'ï': 0x8B, 'î': 0x8C, 'ì': 0x8D, 'Ä': 0x8E, 'Å': 0x8F,
	'É': 0x90, 'æ': 0x91, 'Æ': 0x92, 'ô': 0x93, 'ö': 0x94, 'ò': 0x95, 'û': 0x96, 'ù': 0x97,
	'ÿ': 0x98, 'Ö': 0x99, 'Ü': 0x9A, '¢': 0x9B, '£': 0x9C, '¥': 0x9D, 'á': 0xA0, 'í': 0xA1,
	'ó': 0xA2, 'ú': 0xA3, 'ñ': 0xA4, 'Ñ': 0xA5, 'ª': 0xA6, 'º': 0xA7, '¿': 0xA8, '½': 0xAB,
	'¼': 0xAC, '¡': 0xAD, '«': 0xAE, '»': 0xAF, 'ß': 0xE1, '°': 0xF8, '±': 0xF1, '·': 0xFA,
}

var asciiFallback = strings.NewReplacer(
	"‘", "'", "’", "'", "“", `"`, "”", `"`, "–", "-", "—", "-", "…", "...",
	"♪", "#", "♫", "#", " ", " ", "Á", "A", "Í", "I", "Ó", "O", "Ú", "U", "È", "E",
	"Ê", "E", "À", "A", "Â", "A", "Ô", "O", "Œ", "OE", "œ", "oe", "õ", "o", "ã", "a", "Ã", "A", "Õ", "O",
)

func captionText(s string, cp bool) []byte {
	if !cp {
		return []byte(s)
	}
	s = asciiFallback.Replace(s)
	var b []byte
	for _, r := range s {
		switch {
		case r >= 32 && r < 127:
			b = append(b, byte(r))
		case cp437[r] != 0:
			b = append(b, cp437[r])
		default:
			b = append(b, '?')
		}
	}
	return b
}

// renderCaptionBars draws the caption as white-on-blue bars, the last line
// on lastRow and earlier lines above it, each spanning the picture width.
func renderCaptionBars(buf *bytes.Buffer, lines []string, col, lastRow, width int, cp bool) {
	first := lastRow - len(lines) + 1
	if first < 1 {
		first = 1
	}
	for i, l := range lines {
		row := first + i
		color := "\x1b[0;1;37;44m" // subtitles: white on blue
		if strings.HasPrefix(l, msgMark) {
			l, color = l[len(msgMark):], "\x1b[0;1;33;44m" // the sysop's message: yellow
		}
		r := []rune(l)
		pad := (width - len(r)) / 2
		fmt.Fprintf(buf, "\x1b[%d;%dH%s", row, col+1, color)
		buf.WriteString(strings.Repeat(" ", pad))
		buf.Write(captionText(l, cp))
		buf.WriteString(strings.Repeat(" ", width-len(r)-pad))
		buf.WriteString("\x1b[0m")
	}
}
