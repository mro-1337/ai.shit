aibbs 0.1.0 - an AI BBS user for Windows x64
=============================================

QUICK START (no API key, no real BBS)
-------------------------------------
Open a Command Prompt or PowerShell in this folder and run:

    .\aibbs-win64.exe demo

This starts a mock BBS on localhost, registers an account, replies to a
message, downloads a file with ZMODEM, plays a door game and logs off.
Everything it creates goes into the demo-state folder.

CONNECT TO A REAL BBS
---------------------
1. Create a config file:

       .\aibbs-win64.exe init

2. Edit aibbs.json (Notepad is fine). At minimum set:

       "bbs":     { "name": "...", "host": "...", "port": 23 }
       "account": { "handle": "YourHandle" }
       "ai":      { "model": "gpt-4o-mini" }

3. Set an API key and run:

       set OPENAI_API_KEY=sk-...
       .\aibbs-win64.exe run --config aibbs.json --verbose

PowerShell uses:  $env:OPENAI_API_KEY = "sk-..."

CHECK A BOARD FIRST
-------------------
    .\aibbs-win64.exe probe --host vert.synchro.net --port 23

This connects, waits for the screen to settle and prints it, without logging
in. Useful for seeing what the login prompt looks like.

USEFUL OPTIONS
--------------
    --read-only        no posting and no downloads
    --dry-run          navigate and compose, but never actually post
    --brain heuristic  no LLM at all (offline menu heuristics)
    --max-steps N      stop after N actions
    --timeout 10m      overall session deadline
    --verbose          debug logging

LOCAL MODELS
------------
Ollama: set "provider": "ollama" in the ai section. The default base URL
becomes http://127.0.0.1:11434/v1 and you can use a model such as "llama3.1".
LM Studio, vLLM and other OpenAI-compatible servers work with their own
base_url and any dummy api_key.

WHAT IT CAN DO
--------------
- Telnet with ANSI screen emulation (80x24 by default)
- New-user registration or existing-account login
- Read message areas, post new threads, reply to messages
- Download files with ZMODEM (preferred), YMODEM or XMODEM
- Play door games (LORD, TradeWars 2002, Usurper, Barren Realms Elite,
  Global War, Operation Overkill, PimpWars, Phantasia, plus custom profiles)
- Remember each board between visits (account, read messages, posts,
  downloads, notes) in state\<board>\memory.json

BE A GOOD GUEST
---------------
Ask the sysop before running a bot on their board. Many BBSes prohibit bots
or require them to be labelled. The default limits are deliberately
conservative (about one action per second, 3 posts per session, 2 downloads
per session, 20 MB/day). Use --read-only while learning a board's menus, and
respect time limits and sysop requests.

TROUBLESHOOTING
---------------
- Login stuck? Run with --verbose and look at the final screen. You can add
  sign-up answers under registration.answers in aibbs.json.
- Download fails? Make sure the board offers ZMODEM and that "zmodem" is in
  downloads.protocols. Some boards expect a different protocol key; adjust
  downloads.protocol_keys.
- Nothing happens? Increase bbs.idle_millis (e.g. 800) for slow boards.
- Full documentation: see README.md in this archive.

FILES
-----
    aibbs-win64.exe     the program (Windows 10/11 x64, no DLLs needed)
    config.example.json a complete example configuration
    README.md           full documentation
    LICENSE             MIT license
    SHA256SUMS.txt      checksums for the archive contents
