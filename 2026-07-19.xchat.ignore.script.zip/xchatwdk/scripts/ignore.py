__module_name__ = "textblock_ignore"
__module_version__ = "1.0"
__module_description__ = "Suppress messages containing any phrase listed in an external text file"

import hexchat
import os
import time

# Path to the file containing phrases to block (one per line).
# Change this to wherever you want the file to live.
PHRASE_FILE = os.path.join(hexchat.get_info("configdir"), "ignore_phrases.txt")

# How often (seconds) to check whether the file changed on disk, so you can
# edit it live without reloading the script.
RELOAD_INTERVAL = 5

_phrases = []
_last_mtime = 0
_last_check = 0


def load_phrases(force=False):
    global _phrases, _last_mtime, _last_check
    now = time.time()
    if not force and (now - _last_check) < RELOAD_INTERVAL:
        return
    _last_check = now

    if not os.path.isfile(PHRASE_FILE):
        _phrases = []
        return

    mtime = os.path.getmtime(PHRASE_FILE)
    if not force and mtime == _last_mtime:
        return
    _last_mtime = mtime

    with open(PHRASE_FILE, "r", encoding="utf-8", errors="ignore") as f:
        lines = [line.strip() for line in f]

    # Ignore blank lines and lines starting with # (comments)
    _phrases = [line.lower() for line in lines if line and not line.startswith("#")]


def message_contains_blocked_phrase(text):
    load_phrases()
    lowered = text.lower()
    for phrase in _phrases:
        if phrase in lowered:
            return True
    return False


def on_message(word, word_eol, userdata):
    # word[1] is the message text for these print events
    text = word[1]
    if message_contains_blocked_phrase(text):
        return hexchat.EAT_ALL  # suppress the message entirely
    return hexchat.EAT_NONE


def cmd_reload(word, word_eol, userdata):
    load_phrases(force=True)
    hexchat.prnt("textblock_ignore: reloaded %d phrase(s) from %s" % (len(_phrases), PHRASE_FILE))
    return hexchat.EAT_ALL


def cmd_list(word, word_eol, userdata):
    load_phrases(force=True)
    if not _phrases:
        hexchat.prnt("textblock_ignore: no phrases loaded (file: %s)" % PHRASE_FILE)
    else:
        hexchat.prnt("textblock_ignore: %d phrase(s):" % len(_phrases))
        for p in _phrases:
            hexchat.prnt("  - %s" % p)
    return hexchat.EAT_ALL


# Hook the events where blocked text is most likely to appear.
EVENTS = [
    "Channel Message",
    "Channel Msg Hilight",
    "Channel Action",
    "Channel Action Hilight",
    "Private Message",
    "Private Message to Dialog",
    "Private Action",
    "Private Action to Dialog",
    "Notice",
]

for ev in EVENTS:
    hexchat.hook_print(ev, on_message, priority=hexchat.PRI_HIGH)

hexchat.hook_command("TBRELOAD", cmd_reload, help="/TBRELOAD - reload the textblock phrase file")
hexchat.hook_command("TBLIST", cmd_list, help="/TBLIST - list loaded textblock phrases")

load_phrases(force=True)
hexchat.prnt("textblock_ignore loaded. Phrase file: %s (%d phrase(s))" % (PHRASE_FILE, len(_phrases)))
